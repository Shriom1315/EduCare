<?php
session_start();
require_once '../config/database.php';
require_once '../models/Notification.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$database = new Database();
$db = $database->getConnection();
$notification = new Notification($db);

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'get_count':
        $count = $notification->getUnreadCount($_SESSION['user_id']);
        echo json_encode(['count' => $count]);
        break;

    case 'get_notifications':
        $notifications = $notification->getNotifications($_SESSION['user_id']);
        echo json_encode($notifications);
        break;

    case 'mark_read':
        if (isset($_POST['notification_id'])) {
            $success = $notification->markAsRead($_POST['notification_id'], $_SESSION['user_id']);
            echo json_encode(['success' => $success]);
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Notification ID is required']);
        }
        break;

    case 'mark_all_read':
        $success = $notification->markAllAsRead($_SESSION['user_id']);
        echo json_encode(['success' => $success]);
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Invalid action']);
        break;
}
?> 