-- Add class_teacher_id to classes table if not exists
ALTER TABLE classes ADD COLUMN IF NOT EXISTS class_teacher_id INT NULL;
ALTER TABLE classes ADD CONSTRAINT fk_class_teacher FOREIGN KEY (class_teacher_id) REFERENCES users(id) ON DELETE SET NULL;

-- Update marks table to include approval workflow and metadata
ALTER TABLE marks ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'pending';
ALTER TABLE marks ADD COLUMN IF NOT EXISTS entered_by INT NULL;
ALTER TABLE marks ADD COLUMN IF NOT EXISTS entry_date DATETIME NULL;
ALTER TABLE marks ADD COLUMN IF NOT EXISTS approved_by INT NULL;
ALTER TABLE marks ADD COLUMN IF NOT EXISTS approval_date DATETIME NULL;
ALTER TABLE marks ADD COLUMN IF NOT EXISTS rejection_reason TEXT NULL;
ALTER TABLE marks ADD COLUMN IF NOT EXISTS max_marks INT DEFAULT 100;
ALTER TABLE marks ADD COLUMN IF NOT EXISTS exam_id INT NULL;

-- Add foreign key constraints
ALTER TABLE marks ADD CONSTRAINT fk_marks_entered_by FOREIGN KEY (entered_by) REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE marks ADD CONSTRAINT fk_marks_approved_by FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE marks ADD CONSTRAINT fk_marks_exam FOREIGN KEY (exam_id) REFERENCES exams(id) ON DELETE SET NULL; 