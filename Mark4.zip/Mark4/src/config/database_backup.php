<?php
require_once 'database_config.php';

/**
 * Database class for database connection and operations
 */
class Database {
    private $host = DB_HOST;
    private $db_name = DB_NAME;
    private $username = DB_USER;
    private $password = DB_PASS;
    private $charset = DB_CHARSET;
    private $conn;
    
    /**
     * Get database connection
     * @return PDO
     */
    public function getConnection() {
        $this->conn = null;
        
        try {
            $dsn = "mysql:host={$this->host};dbname={$this->db_name};charset={$this->charset}";
            $this->conn = new PDO($dsn, $this->username, $this->password, PDO_OPTIONS);
            error_log("[Database] Connection established successfully");
        } catch(PDOException $e) {
            error_log("[Database] Connection error: " . $e->getMessage());
            throw $e;
        }
        
        return $this->conn;
    }
}
?> 