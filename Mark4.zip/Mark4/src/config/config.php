<?php
// Base URL configuration
define('BASE_URL', '/Mark4');
define('BASE_PATH', $_SERVER['DOCUMENT_ROOT'] . BASE_URL);

// URLs for different sections
define('LOGIN_URL', BASE_URL . '/src/pages/login.php');
define('DASHBOARD_URL', BASE_URL . '/src/pages/dashboard.php');

// Function to get role-specific dashboard URL
function getDashboardUrl($role) {
    $url = BASE_URL . '/src/pages/' . $role . '/dashboard.php';
    error_log("Generated dashboard URL for role '$role': $url");
    return $url;
}

// Function to get any page URL
function getPageUrl($role, $page) {
    $url = BASE_URL . '/src/pages/' . $role . '/' . $page . '.php';
    error_log("Generated page URL for role '$role' and page '$page': $url");
    return $url;
}

// Function to get current page name (without .php extension)
function getCurrentPage() {
    $path = $_SERVER['PHP_SELF'];
    $pathInfo = pathinfo($path);
    $filename = $pathInfo['filename'];
    
    // Also get the directory name to help with matching
    $dirname = dirname($path);
    $parts = explode('/', $dirname);
    $currentDir = end($parts);
    
    error_log("Current path: $path");
    error_log("Current directory: $currentDir");
    error_log("Current filename: $filename");
    
    return $filename;
}

// Function to check if current page matches given page
function isCurrentPage($page) {
    $current = getCurrentPage();
    $matches = $current === $page;
    error_log("Checking if current page '$current' matches '$page': " . ($matches ? 'true' : 'false'));
    return $matches;
}

// Function to get current role from URL
function getCurrentRole() {
    $path = $_SERVER['PHP_SELF'];
    $parts = explode('/', $path);
    foreach ($parts as $i => $part) {
        if ($part === 'pages' && isset($parts[$i + 1])) {
            $role = $parts[$i + 1];
            error_log("Detected role from URL: $role");
            return $role;
        }
    }
    error_log("Could not detect role from URL");
    return null;
}
?> 