<?php
/**
 * Certificate Utilities
 * 
 * Functions for generating and printing certificates
 */

/**
 * Get certificate data for a specific certificate ID
 * 
 * @param PDO $conn Database connection
 * @param int $certificate_id Certificate ID
 * @param array $options Optional parameters including:
 *                      - user_id: ID of the user requesting the certificate
 *                      - role: Role of the user (principal or student)
 *                      - school_id: School ID for principal role validation
 * @return array|bool Certificate data or false if not found/authorized
 */
function getCertificateData($conn, $certificate_id, $options = []) {
    $role = $options['role'] ?? null;
    $user_id = $options['user_id'] ?? null;
    $school_id = $options['school_id'] ?? null;
    
    $base_query = "SELECT c.*, 
                  s.roll_number, 
                  u.username as student_name,
                  s.date_of_birth,
                  s.parent_name,
                  sc.name as school_name,
                  sc.address as school_address,
                  cl.class_name,
                  pu.username as processed_by_name
                  FROM certificates c
                  JOIN students s ON c.student_id = s.id
                  JOIN users u ON s.user_id = u.id
                  JOIN schools sc ON s.school_id = sc.id
                  JOIN classes cl ON s.class_id = cl.id
                  LEFT JOIN users pu ON c.processed_by = pu.id
                  WHERE c.id = ? AND c.status = 'approved'";
    
    $params = [$certificate_id];
    
    // Add role-specific conditions
    if ($role === 'student') {
        $base_query .= " AND s.user_id = ?";
        $params[] = $user_id;
    } elseif ($role === 'principal' && $school_id) {
        $base_query .= " AND c.school_id = ?";
        $params[] = $school_id;
    }
    
    try {
        $stmt = $conn->prepare($base_query);
        $stmt->execute($params);
        $certificate = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$certificate) {
            return false;
        }
        
        // Get student's attendance percentage
        $attendance_query = "SELECT 
                            COALESCE(
                                (SELECT COUNT(*) FROM attendance a 
                                WHERE a.student_id = s.id 
                                AND a.status = 'present') * 100.0 / 
                                NULLIF((SELECT COUNT(*) FROM attendance a 
                                    WHERE a.student_id = s.id), 0),
                                0
                            ) as attendance_percentage
                            FROM students s
                            WHERE s.id = ?";
                            
        $stmt = $conn->prepare($attendance_query);
        $stmt->execute([$certificate['student_id']]);
        $attendance = $stmt->fetch(PDO::FETCH_ASSOC);
        $certificate['attendance_percentage'] = $attendance['attendance_percentage'] ?? 0;
        
        return $certificate;
    } catch (PDOException $e) {
        error_log("Error fetching certificate: " . $e->getMessage());
        return false;
    }
}

/**
 * Generate certificate HTML
 * 
 * @param array $certificate Certificate data
 * @param bool $include_print_button Whether to include the print button
 * @param string $back_url URL to return to after viewing/printing
 * @return string HTML for certificate
 */
function generateCertificateHtml($certificate, $include_print_button = true, $back_url = '') {
    $certificate_html = '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>' . ucfirst(htmlspecialchars($certificate['type'])) . ' Certificate - ' . htmlspecialchars($certificate['student_name']) . '</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600;700&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
    <style>
        @media print {
            body {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            
            .no-print {
                display: none !important;
            }
            
            @page {
                size: A4;
                margin: 0;
            }
        }
        
        body {
            font-family: \'Lato\', sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f0f0f0;
            color: #333;
        }
        
        .header-buttons {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 20px;
            padding: 10px;
        }
        
        .certificate-container {
            width: 210mm;
            height: 297mm;
            margin: 0 auto;
            background: white;
            box-shadow: 0 0 25px rgba(0, 0, 0, 0.1);
            position: relative;
            box-sizing: border-box;
            padding: 30px;
        }
        
        .certificate-border {
            position: absolute;
            top: 20px;
            left: 20px;
            right: 20px;
            bottom: 20px;
            border: 2px solid #c9a65a;
            z-index: 0;
        }
        
        .certificate-content {
            position: relative;
            z-index: 1;
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        
        .certificate-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .school-logo {
            width: 80px;
            height: 80px;
            margin: 0 auto 15px;
            background-color: #f5f5f5;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
            color: #c9a65a;
            font-weight: bold;
            font-family: \'Cormorant Garamond\', serif;
        }
        
        .school-name {
            font-family: \'Cormorant Garamond\', serif;
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #333;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        
        .school-address {
            font-size: 14px;
            color: #666;
            margin-bottom: 15px;
        }
        
        .divider {
            height: 2px;
            width: 100px;
            background: linear-gradient(to right, transparent, #c9a65a, transparent);
            margin: 15px auto;
        }
        
        .certificate-title {
            font-family: \'Cormorant Garamond\', serif;
            font-size: 32px;
            font-weight: 600;
            color: #c9a65a;
            text-align: center;
            margin: 25px 0 40px;
            text-transform: uppercase;
            letter-spacing: 4px;
            position: relative;
        }
        
        .certificate-title::after {
            content: "";
            position: absolute;
            height: 2px;
            width: 180px;
            background: linear-gradient(to right, transparent, #c9a65a, transparent);
            bottom: -12px;
            left: calc(50% - 90px);
        }
        
        .certificate-body {
            flex-grow: 1;
            text-align: center;
            font-size: 16px;
            line-height: 1.7;
            padding: 0 40px;
        }
        
        .student-info {
            margin: 20px 0 30px;
        }
        
        .student-name {
            font-family: \'Cormorant Garamond\', serif;
            font-size: 26px;
            font-weight: 600;
            color: #333;
            margin: 15px 0;
            padding: 5px 0;
            border-bottom: 1px solid #c9a65a;
            display: inline-block;
        }
        
        .student-details {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            max-width: 500px;
            margin: 0 auto;
            text-align: left;
        }
        
        .detail-item {
            margin-bottom: 10px;
        }
        
        .detail-label {
            font-weight: bold;
            color: #666;
            margin-bottom: 5px;
            font-size: 14px;
        }
        
        .detail-value {
            font-size: 16px;
        }
        
        .certificate-text {
            margin: 30px 0;
            font-size: 17px;
            line-height: 1.6;
        }
        
        .remarks-box {
            margin: 20px auto;
            padding: 15px;
            background-color: #f9f9f5;
            border-left: 3px solid #c9a65a;
            font-style: italic;
            max-width: 80%;
            text-align: left;
            color: #666;
        }
        
        .certificate-footer {
            display: flex;
            justify-content: space-between;
            margin-top: auto;
            padding-top: 30px;
            margin-bottom: 20px;
        }
        
        .date-section {
            text-align: left;
        }
        
        .date-label {
            font-size: 14px;
            color: #666;
            margin-bottom: 5px;
        }
        
        .date {
            font-weight: bold;
        }
        
        .signature-section {
            text-align: right;
            min-width: 200px;
        }
        
        .signature-line {
            width: 100%;
            height: 1px;
            background-color: #333;
            margin-bottom: 5px;
        }
        
        .signature-name {
            font-weight: bold;
        }
        
        .signature-title {
            font-size: 14px;
            color: #666;
        }
        
        .certificate-number {
            text-align: center;
            font-size: 12px;
            color: #999;
            margin-top: 20px;
        }
        
        .stamp {
            position: absolute;
            bottom: 80px;
            right: 150px;
            width: 110px;
            height: 110px;
            border: 1px dashed #c9a65a;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #c9a65a;
            font-weight: bold;
            transform: rotate(-15deg);
            opacity: 0.6;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .button {
            background-color: #4a6fb0;
            color: white;
            border: none;
            padding: 10px 15px;
            margin-left: 10px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s;
        }
        
        .button:hover {
            background-color: #3a5b98;
        }
        
        .print-button {
            background-color: #28a745;
        }
        
        .print-button:hover {
            background-color: #218838;
        }
        
        .back-button {
            background-color: #6c757d;
        }
        
        .back-button:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>';

    // Add header buttons if needed
    if ($include_print_button) {
        $certificate_html .= '
    <div class="header-buttons no-print">';
        
        if (!empty($back_url)) {
            $certificate_html .= '
        <button onclick="window.location.href=\'' . $back_url . '\'" class="button back-button">
            <i class="fas fa-arrow-left"></i> Back
        </button>';
        }
        
        $certificate_html .= '
        <button onclick="window.print()" class="button print-button">
            <i class="fas fa-print"></i> Print Certificate
        </button>
    </div>';
    }

    // Add certificate content
    $certificate_html .= '
    <div class="certificate-container">
        <div class="certificate-border"></div>
        <div class="certificate-content">
            <div class="certificate-header">
                <div class="school-logo">' . substr(htmlspecialchars($certificate['school_name']), 0, 1) . '</div>
                <h1 class="school-name">' . htmlspecialchars($certificate['school_name']) . '</h1>
                <p class="school-address">' . htmlspecialchars($certificate['school_address']) . '</p>
                <div class="divider"></div>
            </div>
            
            <h2 class="certificate-title">' . ucfirst(htmlspecialchars($certificate['type'])) . ' Certificate</h2>
            
            <div class="certificate-body">
                <p>This is to certify that</p>
                
                <div class="student-info">
                    <div class="student-name">' . htmlspecialchars($certificate['student_name']) . '</div>
                    
                    <div class="student-details">
                        <div class="detail-item">
                            <div class="detail-label">Roll Number</div>
                            <div class="detail-value">' . htmlspecialchars($certificate['roll_number']) . '</div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Class</div>
                            <div class="detail-value">' . htmlspecialchars($certificate['class_name']) . '</div>
                        </div>';
                        
    if (!empty($certificate['date_of_birth'])) {
        $certificate_html .= '
                        <div class="detail-item">
                            <div class="detail-label">Date of Birth</div>
                            <div class="detail-value">' . date('F j, Y', strtotime($certificate['date_of_birth'])) . '</div>
                        </div>';
    }
    
    if (!empty($certificate['parent_name'])) {
        $certificate_html .= '
                        <div class="detail-item">
                            <div class="detail-label">Parent Name</div>
                            <div class="detail-value">' . htmlspecialchars($certificate['parent_name']) . '</div>
                        </div>';
    }
    
    if ($certificate['type'] === 'bonafide') {
        $certificate_html .= '
                        <div class="detail-item">
                            <div class="detail-label">Attendance</div>
                            <div class="detail-value">' . number_format($certificate['attendance_percentage'], 1) . '%</div>
                        </div>';
    }
    
    $certificate_html .= '
                    </div>
                </div>
                
                <div class="certificate-text">';
                
    if ($certificate['type'] === 'bonafide') {
        $certificate_html .= 'is a bonafide student of this institution studying in 
                        <strong>' . htmlspecialchars($certificate['class_name']) . '</strong> 
                        for the academic year ' . (date('Y') - 1) . '-' . date('Y') . '.';
    } else {
        $certificate_html .= 'has successfully completed their education up to 
                        <strong>' . htmlspecialchars($certificate['class_name']) . '</strong> 
                        in our institution for the academic year ' . (date('Y') - 1) . '-' . date('Y') . '.';
    }
    
    $certificate_html .= '
                </div>';
                
    if (!empty($certificate['remarks'])) {
        $certificate_html .= '
                <div class="remarks-box">
                    ' . htmlspecialchars($certificate['remarks']) . '
                </div>';
    }
    
    $certificate_html .= '
            </div>
            
            <div class="stamp">Official Seal</div>
            
            <div class="certificate-footer">
                <div class="date-section">
                    <div class="date-label">Date of Issue</div>
                    <div class="date">' . date('F j, Y', strtotime($certificate['processed_at'])) . '</div>
                </div>
                
                <div class="signature-section">
                    <div class="signature-line"></div>
                    <div class="signature-name">' . htmlspecialchars($certificate['processed_by_name']) . '</div>
                    <div class="signature-title">Principal</div>
                </div>
            </div>
            
            <div class="certificate-number">Certificate No: ' . str_pad($certificate['id'], 6, "0", STR_PAD_LEFT) . '</div>
        </div>
    </div>
    
    <script>
        // Auto-print dialog on "p" key press
        document.addEventListener("keydown", function(e) {
            if (e.key === "p" && (e.ctrlKey || e.metaKey)) {
                e.preventDefault();
                window.print();
            }
        });
    </script>
</body>
</html>';

    return $certificate_html;
}

/**
 * Render a certificate directly
 * 
 * @param array $certificate Certificate data
 * @param bool $include_print_button Whether to include the print button
 * @param string $back_url URL to return to after viewing/printing
 */
function renderCertificate($certificate, $include_print_button = true, $back_url = '') {
    echo generateCertificateHtml($certificate, $include_print_button, $back_url);
    exit();
} 