<?php
/**
 * Notification Utilities
 * Functions for sending notifications to users
 */
require_once __DIR__ . '/../models/Notification.php';
require_once __DIR__ . '/../config/database.php';

/**
 * Send a notification about a certificate request to the principal
 * 
 * @param int $student_id The student's ID 
 * @param int $school_id The school ID
 * @param string $certificate_type The type of certificate requested
 * @param PDO $conn Database connection (or null to create a new one)
 * @return bool True if successful, false otherwise
 */
function notifyCertificateRequest($student_id, $school_id, $certificate_type, $conn = null) {
    try {
        // Create database connection if not provided
        $db_connection = $conn ?? (new Database())->getConnection();
        
        // Create notification model
        $notification = new Notification($db_connection);
        
        // Get student information
        $student_query = "SELECT u.username, s.roll_number, c.class_name
                         FROM students s
                         JOIN users u ON s.user_id = u.id
                         JOIN classes c ON s.class_id = c.id
                         WHERE s.id = ?";
        $stmt = $db_connection->prepare($student_query);
        $stmt->execute([$student_id]);
        $student = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$student) {
            error_log("Could not find student with ID: " . $student_id);
            return false;
        }
        
        // Get principal user_id for this school
        $principal_query = "SELECT u.id FROM users u
                           JOIN schools s ON s.principal_id = u.id
                           WHERE s.id = ?";
        $stmt = $db_connection->prepare($principal_query);
        $stmt->execute([$school_id]);
        $principal = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // No principal found directly, try through teachers table
        if (!$principal) {
            $teacher_principal_query = "SELECT u.id FROM users u
                                      JOIN teachers t ON t.user_id = u.id
                                      WHERE t.school_id = ? AND u.role = 'principal'";
            $stmt = $db_connection->prepare($teacher_principal_query);
            $stmt->execute([$school_id]);
            $principal = $stmt->fetch(PDO::FETCH_ASSOC);
        }
        
        if (!$principal) {
            error_log("Could not find principal for school ID: " . $school_id);
            return false;
        }
        
        // Create notification for the principal
        $title = "New Certificate Request";
        $message = "Student " . $student['username'] . " (Roll: " . $student['roll_number'] . 
                  ", Class: " . $student['class_name'] . ") has requested a " . 
                  ucfirst($certificate_type) . " certificate.";
                  
        return $notification->create($principal['id'], $title, $message);
        
    } catch (Exception $e) {
        error_log("Error sending certificate request notification: " . $e->getMessage());
        return false;
    }
}

/**
 * Notify a student about their certificate request status update
 * 
 * @param int $certificate_id The certificate ID
 * @param string $status The new status (approved/rejected)
 * @param string $remarks Any remarks from the principal
 * @param PDO $conn Database connection (or null to create a new one)
 * @return bool True if successful, false otherwise
 */
function notifyCertificateStatusUpdate($certificate_id, $status, $remarks = '', $conn = null) {
    try {
        // Create database connection if not provided
        $db_connection = $conn ?? (new Database())->getConnection();
        
        // Create notification model
        $notification = new Notification($db_connection);
        
        // Get certificate and student information
        $query = "SELECT c.type, s.user_id, u.username as processed_by
                 FROM certificates c
                 JOIN students st ON c.student_id = st.id
                 LEFT JOIN users u ON c.processed_by = u.id
                 WHERE c.id = ?";
        $stmt = $db_connection->prepare($query);
        $stmt->execute([$certificate_id]);
        $certificate = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$certificate) {
            error_log("Could not find certificate with ID: " . $certificate_id);
            return false;
        }
        
        // Create notification for the student
        $title = "Certificate Request " . ucfirst($status);
        $message = "Your " . ucfirst($certificate['type']) . " certificate request has been " . 
                  $status . " by " . ($certificate['processed_by'] ?? 'the principal');
                  
        if (!empty($remarks)) {
            $message .= ". Remarks: " . $remarks;
        }
        
        return $notification->create($certificate['user_id'], $title, $message);
        
    } catch (Exception $e) {
        error_log("Error sending certificate status notification: " . $e->getMessage());
        return false;
    }
}

/**
 * Notify a student about attendance updates
 * 
 * @param int $student_id The student's ID
 * @param string $status The attendance status (present/absent/late)
 * @param string $date The date of attendance
 * @param string $teacher_name The name of the teacher who marked attendance
 * @param PDO $conn Database connection (or null to create a new one)
 * @return bool True if successful, false otherwise
 */
function notifyAttendanceUpdate($student_id, $status, $date, $teacher_name, $conn = null) {
    try {
        // Create database connection if not provided
        $db_connection = $conn ?? (new Database())->getConnection();
        
        // Create notification model
        $notification = new Notification($db_connection);
        
        // Get student user_id
        $query = "SELECT user_id FROM students WHERE id = ?";
        $stmt = $db_connection->prepare($query);
        $stmt->execute([$student_id]);
        $student = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$student) {
            error_log("Could not find student with ID: " . $student_id);
            return false;
        }
        
        // Format date
        $formatted_date = date('F j, Y', strtotime($date));
        
        // Create notification for the student
        $title = "Attendance Marked: " . ucfirst($status);
        $message = "Your attendance for " . $formatted_date . " has been marked as " . 
                   ucfirst($status) . " by " . $teacher_name . ".";
        
        if ($status === 'absent') {
            $message .= " Please provide a reason for your absence.";
        }
        
        return $notification->create($student['user_id'], $title, $message);
        
    } catch (Exception $e) {
        error_log("Error sending attendance notification: " . $e->getMessage());
        return false;
    }
}

/**
 * Notify a parent about their child's attendance
 * 
 * @param int $student_id The student's ID
 * @param string $status The attendance status (present/absent/late)
 * @param string $date The date of attendance
 * @param PDO $conn Database connection (or null to create a new one)
 * @return bool True if successful, false otherwise
 */
function notifyParentAttendance($student_id, $status, $date, $conn = null) {
    try {
        // Create database connection if not provided
        $db_connection = $conn ?? (new Database())->getConnection();
        
        // Create notification model
        $notification = new Notification($db_connection);
        
        // In a future update, this would send notifications to the parent's account
        // For now, we're just logging that this function was called
        error_log("Parent notification for student ID: " . $student_id . " would be sent if parent accounts existed.");
        
        return true;
        
    } catch (Exception $e) {
        error_log("Error sending parent attendance notification: " . $e->getMessage());
        return false;
    }
}

/**
 * Notify a teacher about a student's attendance response
 * 
 * @param int $attendance_id The attendance record ID
 * @param string $reason The reason provided by the student
 * @param PDO $conn Database connection (or null to create a new one)
 * @return bool True if successful, false otherwise
 */
function notifyAttendanceResponse($attendance_id, $reason, $conn = null) {
    try {
        // Create database connection if not provided
        $db_connection = $conn ?? (new Database())->getConnection();
        
        // Create notification model
        $notification = new Notification($db_connection);
        
        // Get attendance details including teacher and student info
        $query = "SELECT a.marked_by, s.user_id as student_user_id, u.username as student_name
                 FROM attendance a
                 JOIN students s ON a.student_id = s.id
                 JOIN users u ON s.user_id = u.id
                 WHERE a.id = ?";
        $stmt = $db_connection->prepare($query);
        $stmt->execute([$attendance_id]);
        $attendance = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$attendance) {
            error_log("Could not find attendance record with ID: " . $attendance_id);
            return false;
        }
        
        // Create notification for the teacher
        $title = "Attendance Response";
        $message = "Student " . $attendance['student_name'] . " has provided a reason for their absence: " . $reason;
        
        return $notification->create($attendance['marked_by'], $title, $message);
        
    } catch (Exception $e) {
        error_log("Error sending attendance response notification: " . $e->getMessage());
        return false;
    }
}
?> 