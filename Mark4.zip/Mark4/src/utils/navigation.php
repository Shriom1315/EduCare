function getPageUrl($role, $page) {
    switch ($role) {
        case 'super_admin':
            switch ($page) {
                case 'dashboard':
                    return '/Mark4/src/pages/super_admin/dashboard.php';
                case 'schools':
                    return '/Mark4/src/pages/super_admin/schools.php';
                case 'users':
                    return '/Mark4/src/pages/super_admin/users.php';
                case 'school_images':
                    return '/Mark4/src/pages/super_admin/school_images.php';
                // Other super admin pages...
            }
            break;
        case 'principal':
            switch ($page) {
                // ... existing cases ...
                case 'class_teachers':
                    return '/Mark4/src/pages/principal/class_teachers.php';
                // ... existing cases ...
            }
            break;
        case 'teacher':
            switch ($page) {
                // ... existing cases ...
                case 'marks_approval':
                    return '/Mark4/src/pages/teacher/marks.php?approve=true';
                // ... existing cases ...
            }
            break;
        // ... existing code ...
    }
} 