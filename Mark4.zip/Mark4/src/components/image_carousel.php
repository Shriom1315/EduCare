<?php
// Function to get school images
function getSchoolImages($db, $school_id) {
    $query = "SELECT * FROM school_images 
              WHERE school_id = :school_id 
              AND status = 'active' 
              ORDER BY display_order, created_at DESC";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':school_id', $school_id);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!-- Image Carousel Component -->
<div class="relative w-full h-64 mb-8 bg-gray-100 rounded-lg overflow-hidden">
    <?php
    $images = getSchoolImages($db, $school['id']);
    if (empty($images)): ?>
        <div class="flex items-center justify-center h-full">
            <p class="text-gray-500">No images available</p>
        </div>
    <?php else: ?>
        <!-- Carousel Container -->
        <div id="imageCarousel" class="relative w-full h-full">
            <?php foreach ($images as $index => $image): ?>
                <div class="carousel-slide absolute w-full h-full transition-opacity duration-500 ease-in-out <?php echo $index === 0 ? 'opacity-100' : 'opacity-0'; ?>">
                    <img src="/Mark4<?php echo htmlspecialchars($image['image_path']); ?>" 
                         alt="School Image" 
                         class="w-full h-full object-cover">
                    <?php if ($image['caption']): ?>
                        <div class="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white p-4">
                            <p class="text-sm"><?php echo htmlspecialchars($image['caption']); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Navigation Buttons -->
        <button onclick="moveSlide(-1)" class="absolute left-0 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 text-white p-2 hover:bg-opacity-75">
            <i class="fas fa-chevron-left"></i>
        </button>
        <button onclick="moveSlide(1)" class="absolute right-0 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 text-white p-2 hover:bg-opacity-75">
            <i class="fas fa-chevron-right"></i>
        </button>

        <!-- Dots Navigation -->
        <div class="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
            <?php foreach ($images as $index => $image): ?>
                <button onclick="showSlide(<?php echo $index; ?>)" 
                        class="w-2 h-2 rounded-full bg-white opacity-50 hover:opacity-100 transition-opacity duration-200">
                </button>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Carousel JavaScript -->
<script>
let currentSlide = 0;
const slides = document.querySelectorAll('.carousel-slide');
const totalSlides = slides.length;

// Auto-advance slides every 5 seconds
let slideInterval = setInterval(() => moveSlide(1), 5000);

function moveSlide(direction) {
    // Reset the interval
    clearInterval(slideInterval);
    slideInterval = setInterval(() => moveSlide(1), 5000);

    // Hide current slide
    slides[currentSlide].classList.remove('opacity-100');
    slides[currentSlide].classList.add('opacity-0');

    // Calculate next slide index
    currentSlide = (currentSlide + direction + totalSlides) % totalSlides;

    // Show new slide
    slides[currentSlide].classList.remove('opacity-0');
    slides[currentSlide].classList.add('opacity-100');

    // Update dots
    updateDots();
}

function showSlide(index) {
    if (index !== currentSlide) {
        slides[currentSlide].classList.remove('opacity-100');
        slides[currentSlide].classList.add('opacity-0');
        slides[index].classList.remove('opacity-0');
        slides[index].classList.add('opacity-100');
        currentSlide = index;
        updateDots();
    }
}

function updateDots() {
    const dots = document.querySelectorAll('.carousel-dot');
    dots.forEach((dot, index) => {
        if (index === currentSlide) {
            dot.classList.add('opacity-100');
            dot.classList.remove('opacity-50');
        } else {
            dot.classList.add('opacity-50');
            dot.classList.remove('opacity-100');
        }
    });
}

// Pause auto-advance on hover
const carousel = document.getElementById('imageCarousel');
if (carousel) {
    carousel.addEventListener('mouseenter', () => clearInterval(slideInterval));
    carousel.addEventListener('mouseleave', () => {
        slideInterval = setInterval(() => moveSlide(1), 5000);
    });
}
</script> 