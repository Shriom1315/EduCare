<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/Notification.php';

// Debug session and request information
error_log("=== Header Component Debug ===");
error_log("Session ID: " . session_id());
error_log("User ID: " . ($_SESSION['user_id'] ?? 'not set'));
error_log("Role: " . ($_SESSION['role'] ?? 'not set'));
error_log("Current URL: " . $_SERVER['REQUEST_URI']);

// Debug session variables
echo "<!-- Header Debug Info:
Session ID: " . session_id() . "
User ID: " . ($_SESSION['user_id'] ?? 'not set') . "
Role: " . ($_SESSION['role'] ?? 'not set') . "
Current URL: " . $_SERVER['REQUEST_URI'] . "
Current Page: " . getCurrentPage() . "
-->";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    error_log("Header: No user_id in session, redirecting to login");
    header('Location: ' . LOGIN_URL);
    exit();
}

$user_role = $_SESSION['role'];
$username = $_SESSION['username'];

// Menu items with active state tracking
$current_page = getCurrentPage();
error_log("Current page name: " . $current_page);

$menu_items = [
    'dashboard' => ['Dashboard', 'fas fa-home'],
    'profile' => ['Profile', 'fas fa-user']
];

// Add role-specific menu items
switch ($user_role) {
    case 'super_admin':
        $admin_submenu = [
            'schools' => ['Schools', 'fas fa-school'],
            'users' => ['Users', 'fas fa-users'],
            'school_images' => ['School Images', 'fas fa-images']
        ];
        break;
    case 'principal':
        $admin_submenu = [
            'teachers' => ['Teachers', 'fas fa-chalkboard-teacher'],
            'students' => ['Students', 'fas fa-user-graduate'],
            'classes' => ['Classes', 'fas fa-chalkboard'],
            'class_teachers' => ['Class Teachers', 'fas fa-user-tie'],
            'teacher_subjects' => ['Teacher Subjects', 'fas fa-book-reader'],
            'exams' => ['Exams', 'fas fa-file-alt'],
            'subjects' => ['Subjects', 'fas fa-book'],
            'timetable' => ['Timetable', 'fas fa-calendar-alt'],
            'certificates' => ['Certificates', 'fas fa-certificate']
        ];
        error_log("Principal menu items loaded");
        break;
    case 'teacher':
        // Get class teacher status
        $is_class_teacher = false;
        $database = new Database();
        $db = $database->getConnection();
        try {
            $query = "SELECT COUNT(*) FROM classes WHERE class_teacher_id = :teacher_id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':teacher_id', $_SESSION['user_id']);
            $stmt->execute();
            $is_class_teacher = ($stmt->fetchColumn() > 0);
        } catch (PDOException $e) {
            error_log("Error checking class teacher status: " . $e->getMessage());
        }
        
        $admin_submenu = [
            'attendance' => ['Attendance', 'fas fa-calendar-check'],
            'marks' => ['Marks', 'fas fa-star']
        ];
        
        // Add special menu option for class teachers
        if ($is_class_teacher) {
            $admin_submenu['marks_approval'] = ['Approve Marks', 'fas fa-check-circle'];
        }
        
        $admin_submenu += [
            'classes' => ['My Classes', 'fas fa-chalkboard'],
            'timetable' => ['My Timetable', 'fas fa-calendar-alt']
        ];
        break;
    case 'student':
        $admin_submenu = [
            'attendance' => ['My Attendance', 'fas fa-calendar-check'],
            'results' => ['My Results', 'fas fa-star'],
            'timetable' => ['My Timetable', 'fas fa-calendar-alt'],
            'certificates' => ['Certificates', 'fas fa-certificate']
        ];
        break;
}

// Log the generated URLs for debugging
foreach ($admin_submenu as $key => $value) {
    $url = getPageUrl($user_role, $key);
    error_log("Generated URL for '$key': $url");
}

// Common additional items
$communication_submenu = [
    'notices' => ['Notices', 'fas fa-bullhorn'],
    'notifications' => ['Notifications', 'fas fa-bell']
];

// Get unread notifications count if user is logged in
$unread_notifications = 0;
if (isset($_SESSION['user_id'])) {
    $database = new Database();
    $db = $database->getConnection();
    $notification = new Notification($db);
    $unread_notifications = $notification->getUnreadCount($_SESSION['user_id']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9fafb;
        }
        
        /* Modern header styles */
        .main-header {
            background-color: #fff;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        /* Dropdown menu styles */
        .nav-dropdown {
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.2s ease;
            position: absolute;
            top: 100%;
            left: 0;
            background-color: #fff;
            border-radius: 0.5rem;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            width: 220px;
            z-index: 50;
        }
        
        .nav-item:hover .nav-dropdown {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
        
        .nav-dropdown-item {
            padding: 0.75rem 1rem;
            display: flex;
            align-items: center;
            color: #374151;
            transition: all 0.2s ease;
        }
        
        .nav-dropdown-item:hover {
            background-color: #f3f4f6;
            color: #3b82f6;
        }
        
        /* Mobile menu */
        .mobile-menu {
            position: fixed;
            top: 0;
            right: 0;
            height: 100vh;
            width: 280px;
            background-color: #fff;
            box-shadow: -5px 0 25px rgba(0,0,0,0.1);
            transform: translateX(100%);
            transition: transform 0.3s ease;
            overflow-y: auto;
            z-index: 200;
        }
        
        .mobile-menu.active {
            transform: translateX(0);
        }
        
        .mobile-menu-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
            z-index: 190;
        }
        
        .mobile-menu-overlay.active {
            opacity: 1;
            visibility: visible;
        }
        
        /* User menu dropdown */
        .user-menu-dropdown {
            transition: all 0.2s ease;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
        }
        
        .user-menu-dropdown.active {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
        
        /* Notification badge */
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: #ef4444;
            color: white;
            border-radius: 50%;
            padding: 0.25rem 0.5rem;
            font-size: 0.75rem;
        }
        
        /* Dark mode styles */
        html.dark body {
            background-color: #111827; /* Darker background */
            color: #F9FAFB; /* Lighter text */
        }
        
        html.dark .main-header {
            background-color: #1F2937; /* Slightly lighter than body for contrast */
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        }
        
        html.dark .nav-dropdown,
        html.dark .mobile-menu {
            background-color: #1F2937;
            border: 1px solid #4B5563;
        }
        
        html.dark .nav-dropdown-item {
            color: #F3F4F6; /* Lighter text */
            border-color: #4B5563;
        }
        
        html.dark .nav-dropdown-item:hover {
            background-color: #374151;
            color: #93C5FD; /* Lighter blue */
        }
        
        html.dark .nav-item > a,
        html.dark .nav-item > button {
            color: #F3F4F6; /* Lighter text */
        }
        
        html.dark .mobile-menu-header {
            border-color: #4B5563;
        }
        
        html.dark .user-menu-dropdown {
            background-color: #1F2937;
            border: 1px solid #4B5563;
        }
        
        html.dark .user-menu-dropdown a {
            color: #F3F4F6;
        }
        
        html.dark .user-menu-dropdown a:hover {
            background-color: #374151;
        }
        
        html.dark .user-menu button span {
            color: #F9FAFB;
        }
        
        html.dark .bg-white {
            background-color: #1F2937;
        }
        
        html.dark .text-gray-800 {
            color: #F9FAFB; /* Bright white */
        }
        
        html.dark .text-gray-700 {
            color: #F3F4F6; /* Very light gray */
        }
        
        html.dark .text-gray-600 {
            color: #E5E7EB; /* Light gray */
        }
        
        html.dark .text-gray-500 {
            color: #D1D5DB; /* Medium gray */
        }
        
        html.dark .border-gray-200 {
            border-color: #4B5563;
        }
        
        html.dark .shadow-lg, 
        html.dark .shadow-md, 
        html.dark .shadow-sm {
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.4), 0 4px 6px -2px rgba(0, 0, 0, 0.3);
        }
        
        /* Fix for the stat cards with colored backgrounds */
        html.dark .bg-blue-50, 
        html.dark .bg-green-50, 
        html.dark .bg-purple-50,
        html.dark .bg-indigo-50,
        html.dark .bg-yellow-50,
        html.dark .bg-red-50 {
            background-color: #374151;
        }
        
        /* Fix for the colored icon containers */
        html.dark .bg-blue-100 {
            background-color: #1E40AF; /* Darker blue */
        }
        
        html.dark .bg-green-100 {
            background-color: #065F46; /* Darker green */
        }
        
        html.dark .bg-purple-100 {
            background-color: #5B21B6; /* Darker purple */
        }
        
        html.dark .bg-indigo-100 {
            background-color: #3730A3; /* Darker indigo */
        }
        
        html.dark .bg-yellow-100 {
            background-color: #92400E; /* Darker yellow/amber */
        }
        
        /* Fix for the icons inside colored containers */
        html.dark .text-blue-600,
        html.dark .text-green-600,
        html.dark .text-purple-600,
        html.dark .text-indigo-600,
        html.dark .text-yellow-600 {
            color: #F3F4F6; /* White text on dark backgrounds */
        }
        
        /* Fix for the hover states on quick action buttons */
        html.dark .hover\:bg-blue-100:hover,
        html.dark .hover\:bg-green-100:hover,
        html.dark .hover\:bg-purple-100:hover,
        html.dark .hover\:bg-indigo-100:hover,
        html.dark .hover\:bg-yellow-100:hover {
            background-color: #4B5563; /* Lighter on hover */
        }
        
        /* Fix for background states */
        html.dark .bg-gray-50 {
            background-color: #2D3748; /* Slightly lighter than card backgrounds */
        }
        
        html.dark .bg-gray-100 {
            background-color: #374151; /* For selected menu items, etc. */
        }
        
        /* Common form elements in dark mode */
        html.dark input[type="text"],
        html.dark input[type="email"],
        html.dark input[type="password"],
        html.dark input[type="number"],
        html.dark input[type="tel"],
        html.dark input[type="date"],
        html.dark input[type="time"],
        html.dark select,
        html.dark textarea {
            background-color: #374151;
            border-color: #4B5563;
            color: #F3F4F6;
        }
        
        html.dark input::placeholder,
        html.dark textarea::placeholder {
            color: #9CA3AF;
        }
        
        /* Improve alert/notification styles */
        html.dark .bg-red-50 {
            background-color: rgba(185, 28, 28, 0.2);
        }
        
        html.dark .bg-green-50 {
            background-color: rgba(6, 95, 70, 0.2);
        }
        
        html.dark .bg-yellow-50 {
            background-color: rgba(146, 64, 14, 0.2);
        }
        
        html.dark .bg-blue-50 {
            background-color: rgba(30, 64, 175, 0.2);
        }
        
        /* Fix for text colors in notification messages */
        html.dark .text-red-700 {
            color: #FCA5A5;
        }
        
        html.dark .text-green-700 {
            color: #6EE7B7;
        }
        
        html.dark .text-yellow-700 {
            color: #FCD34D;
        }
        
        html.dark .text-blue-700 {
            color: #93C5FD;
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- Main Header with Navigation -->
    <header class="main-header">
        <div class="container mx-auto">
            <!-- Desktop Navigation -->
            <div class="hidden md:flex items-center justify-between py-3 px-4">
                <!-- Logo -->
                <a href="<?php echo getDashboardUrl($user_role); ?>" class="text-xl font-bold text-gray-800">
                    School Management System
                </a>
                
                <!-- Navigation Items -->
                <nav class="flex items-center space-x-1">
                    <?php
                    // Regular Menu Items
                    foreach ($menu_items as $key => $value): ?>
                        <a href="<?php echo getPageUrl($user_role, $key); ?>" 
                           class="px-3 py-2 rounded-md text-gray-700 font-medium hover:bg-gray-100 hover:text-blue-600 transition duration-200 <?php echo isCurrentPage($key) ? 'bg-gray-100 text-blue-600' : ''; ?>">
                            <i class="<?php echo $value[1]; ?> mr-2"></i>
                            <?php echo $value[0]; ?>
                        </a>
                    <?php endforeach; ?>
                    
                    <!-- Administration Dropdown -->
                    <div class="nav-item relative">
                        <button class="px-3 py-2 rounded-md text-gray-700 font-medium hover:bg-gray-100 hover:text-blue-600 transition duration-200 flex items-center">
                            <i class="fas fa-cog mr-2"></i>
                            <span>Administration</span>
                            <i class="fas fa-chevron-down ml-2 text-xs"></i>
                        </button>
                        
                        <div class="nav-dropdown py-2">
                            <?php foreach ($admin_submenu as $key => $value): 
                                $menuUrl = getPageUrl($user_role, $key);
                                $isActive = isCurrentPage($key);
                                ?>
                                <a href="<?php echo $menuUrl; ?>" 
                                   class="nav-dropdown-item <?php echo $isActive ? 'bg-gray-100 text-blue-600' : ''; ?>">
                                    <i class="<?php echo $value[1]; ?> mr-3 w-5 text-center"></i>
                                    <span><?php echo $value[0]; ?></span>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <!-- Communication Dropdown -->
                    <div class="nav-item relative">
                        <button class="px-3 py-2 rounded-md text-gray-700 font-medium hover:bg-gray-100 hover:text-blue-600 transition duration-200 flex items-center">
                            <i class="fas fa-comments mr-2"></i>
                            <span>Communication</span>
                            <i class="fas fa-chevron-down ml-2 text-xs"></i>
                        </button>
                        
                        <div class="nav-dropdown py-2">
                            <?php foreach ($communication_submenu as $key => $value): ?>
                                <a href="<?php echo getPageUrl($user_role, $key); ?>" class="nav-dropdown-item">
                                    <i class="<?php echo $value[1]; ?> mr-3 w-5 text-center"></i>
                                    <span><?php echo $value[0]; ?></span>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Right Menu Items -->
                    <div class="flex items-center ml-4 space-x-4">
                        <!-- Theme Toggle -->
                        <button id="themeToggle" class="p-2 rounded-full hover:bg-gray-100 transition duration-200">
                            <i class="fas fa-moon text-gray-600"></i>
                        </button>

                        <!-- Notifications -->
                        <div class="relative">
                            <button id="notificationBtn" class="p-2 rounded-full hover:bg-gray-100 transition duration-200">
                                <i class="fas fa-bell text-gray-600"></i>
                                <?php if ($unread_notifications > 0): ?>
                                    <span id="notificationCount" class="notification-badge"><?php echo $unread_notifications; ?></span>
                                <?php endif; ?>
                            </button>
                            
                            <!-- Notification Dropdown -->
                            <div id="notificationDropdown" class="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg py-2 z-20 hidden">
                                <div class="px-4 py-2 border-b border-gray-200 flex justify-between items-center">
                                    <h3 class="text-lg font-semibold">Notifications</h3>
                                    <button id="markAllRead" class="text-sm text-blue-600 hover:text-blue-800">Mark all as read</button>
                                </div>
                                <div id="notificationList" class="max-h-96 overflow-y-auto">
                                    <!-- Notifications will be loaded here -->
                                </div>
                                <div id="noNotifications" class="px-4 py-2 text-center text-gray-500 hidden">
                                    No notifications
                                </div>
                            </div>
                        </div>

                        <!-- User Menu -->
                        <div class="relative user-menu">
                            <button class="flex items-center space-x-2 focus:outline-none">
                                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($username); ?>&background=0D9488&color=fff" 
                                    alt="User avatar" 
                                    class="w-8 h-8 rounded-full border-2 border-blue-100">
                                <span class="text-gray-700 font-medium"><?php echo htmlspecialchars($username); ?></span>
                                <i class="fas fa-chevron-down text-gray-500 text-xs"></i>
                            </button>
                            
                            <!-- Dropdown Menu -->
                            <div class="user-menu-dropdown absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 z-20">
                                <a href="<?php echo getPageUrl($user_role, 'profile'); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 transition duration-200">
                                    <i class="fas fa-user-cog mr-2"></i> Profile Settings
                                </a>
                                <a href="<?php echo BASE_URL; ?>/src/pages/logout.php" class="block px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition duration-200">
                                    <i class="fas fa-sign-out-alt mr-2"></i> Logout
                                </a>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
            
            <!-- Mobile Navigation -->
            <div class="flex md:hidden items-center justify-between p-4">
                <a href="<?php echo getDashboardUrl($user_role); ?>" class="text-xl font-bold text-gray-800">
                    SMS
                </a>
                
                <div class="flex items-center space-x-3">
                    <!-- Notifications -->
                    <div class="relative">
                        <button id="mobileNotificationBtn" class="p-2 text-gray-600">
                            <i class="fas fa-bell"></i>
                            <?php if ($unread_notifications > 0): ?>
                                <span class="notification-badge"><?php echo $unread_notifications; ?></span>
                            <?php endif; ?>
                        </button>
                    </div>
                    
                    <!-- Mobile Menu Toggle -->
                    <button id="mobileMenuToggle" class="p-2 text-gray-600">
                        <i class="fas fa-bars"></i>
                    </button>
                </div>
            </div>
        </div>
    </header>
    
    <!-- Mobile Menu -->
    <div class="mobile-menu-overlay"></div>
    <div class="mobile-menu">
        <div class="mobile-menu-header flex items-center justify-between p-4 border-b border-gray-200">
            <div class="flex items-center">
                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($username); ?>&background=0D9488&color=fff" 
                     alt="User avatar" 
                     class="w-10 h-10 rounded-full border-2 border-blue-100">
                <div class="ml-3">
                    <p class="font-medium text-gray-800"><?php echo htmlspecialchars($username); ?></p>
                    <p class="text-sm text-gray-500"><?php echo ucfirst($user_role); ?></p>
                </div>
            </div>
            <button id="closeMobileMenu" class="text-gray-600">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <div class="flex flex-col h-[calc(100vh-80px)] overflow-y-auto">
            <nav class="flex-1 p-4">
                <!-- Regular Menu Items -->
                <?php foreach ($menu_items as $key => $value): ?>
                    <a href="<?php echo getPageUrl($user_role, $key); ?>" 
                       class="flex items-center py-3 px-4 text-gray-700 hover:bg-gray-100 hover:text-blue-600 rounded-md transition duration-200 <?php echo isCurrentPage($key) ? 'bg-gray-100 text-blue-600' : ''; ?>">
                        <i class="<?php echo $value[1]; ?> w-6 text-center"></i>
                        <span class="ml-3"><?php echo $value[0]; ?></span>
                    </a>
                <?php endforeach; ?>
                
                <!-- Admin Section -->
                <div class="mt-4 pt-4 border-t border-gray-200">
                    <p class="px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Administration</p>
                    <?php foreach ($admin_submenu as $key => $value): 
                        $menuUrl = getPageUrl($user_role, $key);
                        $isActive = isCurrentPage($key);
                        ?>
                        <a href="<?php echo $menuUrl; ?>" 
                           class="flex items-center py-3 px-4 text-gray-700 hover:bg-gray-100 hover:text-blue-600 rounded-md transition duration-200 <?php echo $isActive ? 'bg-gray-100 text-blue-600' : ''; ?>">
                            <i class="<?php echo $value[1]; ?> w-6 text-center"></i>
                            <span class="ml-3"><?php echo $value[0]; ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
                
                <!-- Communication Section -->
                <div class="mt-4 pt-4 border-t border-gray-200">
                    <p class="px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Communication</p>
                    <?php foreach ($communication_submenu as $key => $value): ?>
                        <a href="<?php echo getPageUrl($user_role, $key); ?>" 
                           class="flex items-center py-3 px-4 text-gray-700 hover:bg-gray-100 hover:text-blue-600 rounded-md transition duration-200">
                            <i class="<?php echo $value[1]; ?> w-6 text-center"></i>
                            <span class="ml-3"><?php echo $value[0]; ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            </nav>
            
            <!-- Bottom Actions -->
            <div class="p-4 border-t border-gray-200 bg-white">
                <!-- Theme Toggle -->
                <button id="mobileThemeToggle" class="flex items-center py-3 px-4 text-gray-700 hover:bg-gray-100 hover:text-blue-600 rounded-md transition duration-200 w-full">
                    <i class="fas fa-moon w-6 text-center"></i>
                    <span class="ml-3">Dark Mode</span>
                </button>
                
                <!-- Mobile Menu Logout -->
                <a href="<?php echo BASE_URL; ?>/src/pages/logout.php" class="flex items-center py-3 px-4 text-red-600 hover:bg-red-50 rounded-md transition duration-200 w-full mt-2">
                    <i class="fas fa-sign-out-alt w-6 text-center"></i>
                    <span class="ml-3">Logout</span>
                </a>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container mx-auto pt-4">
        <!-- Page Content -->
        <main class="p-4">
        </main>
    </div>

    <!-- Add this before the closing </body> tag -->
    <script>
    // User menu functionality
    const userMenuBtn = document.querySelector('.user-menu button');
    const userMenuDropdown = document.querySelector('.user-menu-dropdown');
    
    if (userMenuBtn && userMenuDropdown) {
        userMenuBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            userMenuDropdown.classList.toggle('active');
        });
        
        document.addEventListener('click', (e) => {
            if (!userMenuBtn.contains(e.target) && !userMenuDropdown.contains(e.target)) {
                userMenuDropdown.classList.remove('active');
            }
        });
    }
    
    // Mobile menu functionality
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const closeMobileMenu = document.getElementById('closeMobileMenu');
    const mobileMenu = document.querySelector('.mobile-menu');
    const mobileMenuOverlay = document.querySelector('.mobile-menu-overlay');
    
    if (mobileMenuToggle && mobileMenu) {
        mobileMenuToggle.addEventListener('click', () => {
            mobileMenu.classList.add('active');
            mobileMenuOverlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        });
    }
    
    if (closeMobileMenu && mobileMenu) {
        closeMobileMenu.addEventListener('click', () => {
            mobileMenu.classList.remove('active');
            mobileMenuOverlay.classList.remove('active');
            document.body.style.overflow = '';
        });
        
        mobileMenuOverlay.addEventListener('click', () => {
            mobileMenu.classList.remove('active');
            mobileMenuOverlay.classList.remove('active');
            document.body.style.overflow = '';
        });
    }
    
    // Notification functionality
    document.addEventListener('DOMContentLoaded', function() {
        const notificationBtn = document.getElementById('notificationBtn');
        const mobileNotificationBtn = document.getElementById('mobileNotificationBtn');
        const notificationDropdown = document.getElementById('notificationDropdown');
        const notificationList = document.getElementById('notificationList');
        const noNotifications = document.getElementById('noNotifications');
        const markAllRead = document.getElementById('markAllRead');
        
        // Function to toggle notification dropdown visibility
        function toggleNotificationDropdown(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const isDesktop = window.innerWidth >= 768;
            
            // If on mobile, close mobile menu first
            if (!isDesktop) {
                const mobileMenu = document.querySelector('.mobile-menu');
                const mobileMenuOverlay = document.querySelector('.mobile-menu-overlay');
                if (mobileMenu && mobileMenuOverlay) {
                    mobileMenu.classList.remove('active');
                    mobileMenuOverlay.classList.remove('active');
                }
                
                // Position dropdown for mobile
                notificationDropdown.style.position = 'fixed';
                notificationDropdown.style.top = '60px';
                notificationDropdown.style.right = '10px';
                notificationDropdown.style.left = '10px';
                notificationDropdown.style.width = 'calc(100% - 20px)';
                notificationDropdown.style.zIndex = '300';
            } else {
                // Reset to default for desktop
                notificationDropdown.style.position = 'absolute';
                notificationDropdown.style.top = '100%';
                notificationDropdown.style.right = '0';
                notificationDropdown.style.left = 'auto';
                notificationDropdown.style.width = '320px';
                notificationDropdown.style.zIndex = '20';
            }
            
            notificationDropdown.classList.toggle('hidden');
            
            if (!notificationDropdown.classList.contains('hidden')) {
                loadNotifications();
            }
        }
        
        // Add event listeners for notification buttons
        if (notificationBtn) {
            notificationBtn.addEventListener('click', toggleNotificationDropdown);
            console.log('Desktop notification button listener added');
        }
        
        if (mobileNotificationBtn) {
            mobileNotificationBtn.addEventListener('click', toggleNotificationDropdown);
            console.log('Mobile notification button listener added');
        }
        
        // Close dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (notificationDropdown && 
                !notificationDropdown.classList.contains('hidden') && 
                !(notificationBtn && notificationBtn.contains(e.target)) && 
                !(mobileNotificationBtn && mobileNotificationBtn.contains(e.target)) && 
                !notificationDropdown.contains(e.target)) {
                notificationDropdown.classList.add('hidden');
            }
        });
        
        // Load notifications
        function loadNotifications() {
            if (!notificationList) return;
            
            notificationList.innerHTML = '<div class="px-4 py-2 text-center">Loading...</div>';
            
            fetch('/Mark4/src/api/notifications.php?action=get_notifications')
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(notifications => {
                    notificationList.innerHTML = '';
                    if (!notifications || notifications.length === 0) {
                        if (noNotifications) noNotifications.classList.remove('hidden');
                    } else {
                        if (noNotifications) noNotifications.classList.add('hidden');
                        notifications.forEach(notification => {
                            const notificationElement = createNotificationElement(notification);
                            notificationList.appendChild(notificationElement);
                        });
                    }
                })
                .catch(error => {
                    console.error('Error loading notifications:', error);
                    notificationList.innerHTML = '<div class="px-4 py-2 text-center text-red-500">Error loading notifications</div>';
                });
        }
        
        // Create notification element
        function createNotificationElement(notification) {
            const div = document.createElement('div');
            div.className = `px-4 py-2 border-b border-gray-200 ${parseInt(notification.is_read) === 0 ? 'bg-white' : 'bg-gray-50'}`;
            
            const timeAgo = new Date(notification.created_at).toLocaleString();
            
            div.innerHTML = `
                <div class="flex items-start">
                    <div class="flex-1">
                        <h4 class="font-medium">${notification.title || 'Notification'}</h4>
                        <p class="text-sm text-gray-600">${notification.message || ''}</p>
                        <p class="text-xs text-gray-500 mt-1">${timeAgo}</p>
                    </div>
                    ${parseInt(notification.is_read) === 0 ? `
                        <button class="mark-read-btn text-xs text-blue-600 hover:text-blue-800" data-id="${notification.id}">
                            Mark as read
                        </button>
                    ` : ''}
                </div>
            `;
            
            // Add event listener to the mark as read button
            const markReadBtn = div.querySelector('.mark-read-btn');
            if (markReadBtn) {
                markReadBtn.addEventListener('click', function() {
                    const notificationId = this.getAttribute('data-id');
                    markAsRead(notificationId);
                });
            }
            
            return div;
        }
        
        // Mark notification as read
        function markAsRead(notificationId) {
            fetch('/Mark4/src/api/notifications.php?action=mark_read', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `notification_id=${notificationId}`
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    loadNotifications();
                    updateNotificationCount();
                }
            })
            .catch(error => console.error('Error marking notification as read:', error));
        }
        
        // Mark all notifications as read
        if (markAllRead) {
            markAllRead.addEventListener('click', () => {
                fetch('/Mark4/src/api/notifications.php?action=mark_all_read')
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.success) {
                            loadNotifications();
                            updateNotificationCount();
                        }
                    })
                    .catch(error => console.error('Error marking all notifications as read:', error));
            });
        }
        
        // Update notification count
        function updateNotificationCount() {
            const badges = document.querySelectorAll('.notification-badge');
            if (!badges.length) return;
            
            fetch('/Mark4/src/api/notifications.php?action=get_count')
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    // Update both desktop and mobile notification counts
                    badges.forEach(badge => {
                        badge.textContent = data.count;
                        if (data.count > 0) {
                            badge.classList.remove('hidden');
                        } else {
                            badge.classList.add('hidden');
                        }
                    });
                })
                .catch(error => console.error('Error updating notification count:', error));
        }
        
        // Initial load of notification count
        updateNotificationCount();
        
        // Update notification count every 30 seconds
        setInterval(updateNotificationCount, 30000);
    });

    // Theme toggle functionality
    const themeToggle = document.getElementById('themeToggle');
    const mobileThemeToggle = document.getElementById('mobileThemeToggle');
    const themeIcon = themeToggle?.querySelector('i');
    const mobileThemeIcon = mobileThemeToggle?.querySelector('i');
    const mobileThemeText = mobileThemeToggle?.querySelector('span');
    
    function toggleDarkMode() {
        document.documentElement.classList.toggle('dark');
        
        if (document.documentElement.classList.contains('dark')) {
            localStorage.setItem('theme', 'dark');
            if (themeIcon) themeIcon.className = 'fas fa-sun text-yellow-400';
            if (mobileThemeIcon) mobileThemeIcon.className = 'fas fa-sun text-yellow-400 w-6 text-center';
            if (mobileThemeText) mobileThemeText.textContent = 'Light Mode';
        } else {
            localStorage.setItem('theme', 'light');
            if (themeIcon) themeIcon.className = 'fas fa-moon text-gray-600';
            if (mobileThemeIcon) mobileThemeIcon.className = 'fas fa-moon w-6 text-center';
            if (mobileThemeText) mobileThemeText.textContent = 'Dark Mode';
        }
    }
    
    // Check user preference
    if (localStorage.getItem('theme') === 'dark' || 
        (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        document.documentElement.classList.add('dark');
        if (themeIcon) themeIcon.className = 'fas fa-sun text-yellow-400';
        if (mobileThemeIcon) mobileThemeIcon.className = 'fas fa-sun text-yellow-400 w-6 text-center';
        if (mobileThemeText) mobileThemeText.textContent = 'Light Mode';
    }
    
    // Add event listeners
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleDarkMode);
    }
    
    if (mobileThemeToggle) {
        mobileThemeToggle.addEventListener('click', toggleDarkMode);
    }
    </script>
</body>
</html> 