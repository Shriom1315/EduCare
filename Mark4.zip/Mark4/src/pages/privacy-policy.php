<?php
require_once '../config/database.php';
require_once '../components/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-8" style="background: white; border-radius: 0.5rem; padding: 2rem; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
        <h1 class="text-3xl font-bold text-gray-800 mb-6">Privacy Policy</h1>
        
        <div class="prose max-w-none">
            <p class="text-gray-600 mb-4">Last Updated: <?php echo date('F d, Y'); ?></p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">1. Introduction</h2>
            <p class="mb-4">
                Welcome to the School Management System. We respect your privacy and are committed to protecting your personal data. 
                This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our system.
            </p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">2. Information We Collect</h2>
            <p class="mb-3">We collect several types of information from and about users of our system, including:</p>
            <ul class="list-disc pl-6 mb-4" style="list-style-type: disc; padding-left: 1.5rem;">
                <li class="mb-2">Personal identifiers (name, email address, phone number, etc.)</li>
                <li class="mb-2">Student records (attendance, grades, behavior reports)</li>
                <li class="mb-2">Employment information for staff</li>
                <li class="mb-2">Technical data (IP address, browser type, cookies, device information)</li>
                <li class="mb-2">Usage data (pages visited, features used, time spent)</li>
            </ul>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">3. How We Use Your Information</h2>
            <p class="mb-3">We use the information we collect for various purposes, including:</p>
            <ul class="list-disc pl-6 mb-4" style="list-style-type: disc; padding-left: 1.5rem;">
                <li class="mb-2">Providing and maintaining our services</li>
                <li class="mb-2">Managing student records and academic progress</li>
                <li class="mb-2">Facilitating communication between school, teachers, students, and parents</li>
                <li class="mb-2">Improving and personalizing our system</li>
                <li class="mb-2">Complying with legal obligations</li>
            </ul>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">4. Data Security</h2>
            <p class="mb-4">
                We implement appropriate security measures to protect your personal information. 
                However, no method of transmission over the internet or electronic storage is 100% secure, 
                and we cannot guarantee absolute security.
            </p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">5. Data Retention</h2>
            <p class="mb-4">
                We retain personal information for as long as necessary to fulfill the purposes for which we collected it, 
                including for legal, accounting, or reporting requirements. Student records may be kept for longer periods 
                in accordance with educational regulations.
            </p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">6. Disclosure of Your Information</h2>
            <p class="mb-3">We may disclose your personal information to:</p>
            <ul class="list-disc pl-6 mb-4" style="list-style-type: disc; padding-left: 1.5rem;">
                <li class="mb-2">School administrators and authorized staff</li>
                <li class="mb-2">Service providers who perform services for us</li>
                <li class="mb-2">Regulatory authorities, when required by law</li>
                <li class="mb-2">Parents or guardians (for student information)</li>
            </ul>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">7. Your Privacy Rights</h2>
            <p class="mb-4">
                Depending on your location, you may have certain rights regarding your personal information, 
                including the right to access, correct, delete, or restrict the use of your data. 
                To exercise these rights, please contact us using the details provided below.
            </p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">8. Children's Privacy</h2>
            <p class="mb-4">
                Our system may collect information from children under the age of 13 with parental consent, 
                in compliance with applicable laws such as the Children's Online Privacy Protection Act (COPPA). 
                We take special care to protect the privacy of children.
            </p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">9. Changes to Our Privacy Policy</h2>
            <p class="mb-4">
                We may update our Privacy Policy from time to time. The date at the top of this policy indicates 
                when it was last revised. We will notify users of any material changes through a notice on our system.
            </p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">10. Contact Us</h2>
            <p class="mb-4">
                If you have questions or concerns about this Privacy Policy or our data practices, 
                please contact us at:
            </p>
            <div class="pl-6 mb-6">
                <p class="mb-1">Email: privacy@schoolmanagementsystem.com</p>
                <p class="mb-1">Phone: +1-234-567-8900</p>
                <p>Address: 123 Education Street, Learning City, 54321</p>
            </div>
        </div>
    </div>
</div>

<?php require_once '../components/footer.php'; ?> 