<?php
session_start();
require_once '../config/config.php';

// Store the message before destroying the session
$_SESSION['info_message'] = "You have been successfully logged out.";

// Clear all session variables
$_SESSION = array();

// Destroy the session cookie
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time() - 3600, '/');
}

// Destroy the session
session_destroy();

// Start a new session for the message
session_start();
$_SESSION['info_message'] = "You have been successfully logged out.";

// Redirect to login page with absolute path
header('Location: ' . BASE_URL . '/src/pages/login.php');
exit();
?> 