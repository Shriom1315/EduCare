<?php
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is teacher
if ($_SESSION['role'] !== 'teacher') {
    header('Location: /src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get teacher information
$query = "SELECT t.*, s.name as school_name, s.id as school_id 
          FROM teachers t 
          JOIN schools s ON t.school_id = s.id 
          WHERE t.user_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$teacher = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$teacher) {
    header('Location: /src/pages/login.php');
    exit();
}

// Fetch assigned classes
$query = "SELECT c.* FROM classes c 
          JOIN teacher_class_assignments tca ON c.id = tca.class_id 
          WHERE tca.teacher_id = :user_id 
          ORDER BY c.class_name";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get total student count
$total_students = 0;
if (!empty($classes)) {
    $class_ids = array_column($classes, 'id');
    $placeholders = str_repeat('?,', count($class_ids) - 1) . '?';
    
    $query = "SELECT COUNT(*) as count FROM students WHERE class_id IN ($placeholders)";
    $stmt = $db->prepare($query);
    foreach ($class_ids as $i => $id) {
        $stmt->bindValue($i + 1, $id);
    }
    $stmt->execute();
    $total_students = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
}

// Get recent notices
$query = "SELECT n.*, u.username as created_by_name 
          FROM notices n 
          JOIN users u ON n.created_by = u.id 
          WHERE n.school_id = :school_id 
          AND (n.target_audience = 'all' OR n.target_audience = 'teachers') 
          ORDER BY n.created_at DESC LIMIT 5";
$stmt = $db->prepare($query);
$stmt->bindParam(':school_id', $teacher['school_id']);
$stmt->execute();
$recent_notices = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get upcoming exams
try {
    // First check if the exams table exists
    $check_table = "SHOW TABLES LIKE 'exams'";
    $table_exists = $db->query($check_table)->rowCount() > 0;
    
    if ($table_exists) {
        $query = "SELECT e.* FROM exams e 
                  WHERE e.school_id = :school_id 
                  AND e.start_date >= CURDATE() 
                  AND (e.class_id IS NULL OR e.class_id IN (
                      SELECT class_id FROM teacher_class_assignments WHERE teacher_id = :teacher_id
                  )) 
                  ORDER BY e.start_date ASC LIMIT 5";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':teacher_id', $_SESSION['user_id']);
        $stmt->bindParam(':school_id', $teacher['school_id']);
        $stmt->execute();
        $upcoming_exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $upcoming_exams = [];
    }
} catch (PDOException $e) {
    // If there's an error, set empty array for upcoming exams
    $upcoming_exams = [];
}
?>

<!-- Dashboard Content -->
<div class="container mx-auto px-4">
    <!-- Welcome Section -->
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-800">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
        <p class="text-gray-600">Teacher at <?php echo htmlspecialchars($teacher['school_name']); ?></p>
        <div class="mt-2 flex flex-wrap">
            <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800 mr-2 mb-2">
                <i class="fas fa-graduation-cap mr-1"></i> <?php echo htmlspecialchars($teacher['qualification']); ?>
            </span>
            <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800 mr-2 mb-2">
                <i class="fas fa-book mr-1"></i> <?php echo htmlspecialchars($teacher['specialization']); ?>
            </span>
            <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-purple-100 text-purple-800 mb-2">
                <i class="fas fa-calendar-alt mr-1"></i> Joined <?php echo date('M Y', strtotime($teacher['joining_date'])); ?>
            </span>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <!-- Classes Card -->
        <div class="bg-white rounded-lg shadow-md p-6 transform hover:scale-105 transition-transform duration-200">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-blue-100 text-blue-600">
                    <i class="fas fa-chalkboard text-2xl"></i>
                </div>
                <div class="ml-4">
                    <h2 class="text-gray-600 text-sm">My Classes</h2>
                    <p class="text-2xl font-semibold text-gray-800"><?php echo count($classes); ?></p>
                </div>
            </div>
        </div>

        <!-- Students Card -->
        <div class="bg-white rounded-lg shadow-md p-6 transform hover:scale-105 transition-transform duration-200">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-green-100 text-green-600">
                    <i class="fas fa-user-graduate text-2xl"></i>
                </div>
                <div class="ml-4">
                    <h2 class="text-gray-600 text-sm">Total Students</h2>
                    <p class="text-2xl font-semibold text-gray-800"><?php echo $total_students; ?></p>
                </div>
            </div>
        </div>

        <!-- Upcoming Exams Card -->
        <div class="bg-white rounded-lg shadow-md p-6 transform hover:scale-105 transition-transform duration-200">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-red-100 text-red-600">
                    <i class="fas fa-file-alt text-2xl"></i>
                </div>
                <div class="ml-4">
                    <h2 class="text-gray-600 text-sm">Upcoming Exams</h2>
                    <p class="text-2xl font-semibold text-gray-800"><?php echo count($upcoming_exams); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- My Classes Section -->
    <div class="mb-8">
        <h2 class="text-xl font-semibold text-gray-800 mb-4">My Classes</h2>
        <?php if (empty($classes)): ?>
            <div class="bg-white rounded-lg shadow-md p-6 text-center text-gray-500">
                You haven't been assigned to any classes yet.
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <?php foreach ($classes as $class): ?>
                    <div class="bg-white rounded-lg shadow-md overflow-hidden">
                        <div class="bg-gray-50 px-4 py-3 border-b">
                            <h3 class="text-lg font-medium text-gray-900"><?php echo htmlspecialchars($class['class_name']); ?></h3>
                        </div>
                        <div class="p-4">
                            <div class="flex items-center mb-2">
                                <i class="fas fa-door-open text-gray-500 mr-2"></i>
                                <span class="text-sm text-gray-700">Room: <?php echo htmlspecialchars($class['room_number'] ?? 'N/A'); ?></span>
                            </div>
                            <div class="flex items-center mb-2">
                                <i class="fas fa-users text-gray-500 mr-2"></i>
                                <span class="text-sm text-gray-700">
                                    <?php
                                        $query = "SELECT COUNT(*) as count FROM students WHERE class_id = :class_id";
                                        $stmt = $db->prepare($query);
                                        $stmt->bindParam(':class_id', $class['id']);
                                        $stmt->execute();
                                        $student_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
                                        echo "Students: $student_count";
                                        if (!empty($class['capacity'])) {
                                            echo " / " . $class['capacity'];
                                        }
                                    ?>
                                </span>
                            </div>
                        </div>
                        <div class="bg-gray-50 px-4 py-3 border-t">
                            <a href="class_details.php?id=<?php echo $class['id']; ?>" class="text-blue-600 hover:text-blue-800 text-sm">
                                View Details <i class="fas fa-arrow-right ml-1"></i>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Recent Notices and Upcoming Exams -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Recent Notices -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">Recent Notices</h2>
            <div class="space-y-4">
                <?php if (empty($recent_notices)): ?>
                    <p class="text-gray-500">No recent notices available.</p>
                <?php else: ?>
                    <?php foreach ($recent_notices as $notice): ?>
                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div>
                                <h3 class="font-medium text-gray-800"><?php echo htmlspecialchars($notice['title']); ?></h3>
                                <p class="text-sm text-gray-600">Posted by <?php echo htmlspecialchars($notice['created_by_name']); ?></p>
                                <p class="text-sm text-gray-500"><?php echo date('M d, Y', strtotime($notice['created_at'])); ?></p>
                            </div>
                            <a href="notices.php?id=<?php echo $notice['id']; ?>" class="text-blue-600 hover:text-blue-800">
                                <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Upcoming Exams -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">Upcoming Exams</h2>
            <div class="space-y-4">
                <?php if (empty($upcoming_exams)): ?>
                    <p class="text-gray-500">No upcoming exams scheduled.</p>
                <?php else: ?>
                    <?php foreach ($upcoming_exams as $exam): ?>
                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div>
                                <h3 class="font-medium text-gray-800"><?php echo htmlspecialchars($exam['name']); ?></h3>
                                <p class="text-sm text-gray-600">
                                    <?php echo date('M d, Y', strtotime($exam['start_date'])); ?> - 
                                    <?php echo date('M d, Y', strtotime($exam['end_date'])); ?>
                                </p>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                    <?php echo ucfirst($exam['status']); ?>
                                </span>
                            </div>
                            <a href="exams.php?id=<?php echo $exam['id']; ?>" class="text-blue-600 hover:text-blue-800">
                                <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="mt-8">
        <h2 class="text-xl font-semibold text-gray-800 mb-4">Quick Actions</h2>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
            <a href="attendance.php" class="flex items-center p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors duration-200">
                <i class="fas fa-clipboard-check text-blue-600 text-xl mr-3"></i>
                <span class="text-gray-700">Take Attendance</span>
            </a>
            <a href="assignments.php" class="flex items-center p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors duration-200">
                <i class="fas fa-tasks text-green-600 text-xl mr-3"></i>
                <span class="text-gray-700">Assignments</span>
            </a>
            <a href="grades.php" class="flex items-center p-4 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors duration-200">
                <i class="fas fa-chart-line text-purple-600 text-xl mr-3"></i>
                <span class="text-gray-700">Enter Grades</span>
            </a>
            <a href="messages.php" class="flex items-center p-4 bg-yellow-50 rounded-lg hover:bg-yellow-100 transition-colors duration-200">
                <i class="fas fa-envelope text-yellow-600 text-xl mr-3"></i>
                <span class="text-gray-700">Messages</span>
            </a>
        </div>
    </div>
</div>

<?php require_once '../../components/footer.php'; ?> 