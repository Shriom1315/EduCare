<?php
require_once '../../config/database.php';
require_once '../../components/header.php';
require_once '../../utils/notification_utils.php';

// Check if user is logged in and is a teacher
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header('Location: /src/pages/login.php');
    exit();
}

$db = new Database();
$conn = $db->getConnection();
$teacher_id = $_SESSION['user_id'];
$teacher_name = $_SESSION['username'];

// Get current date
$today = date('Y-m-d');
$current_month = date('m');
$current_year = date('Y');

// Get teacher's ID from teachers table
$teacher_query = "SELECT id, school_id FROM teachers WHERE user_id = ?";
$stmt = $conn->prepare($teacher_query);
$stmt->execute([$teacher_id]);
$teacher = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$teacher) {
    header('Location: /src/pages/login.php');
    exit();
}

// Fetch assigned classes
$query = "SELECT c.* FROM classes c 
          WHERE c.class_teacher_id = ? 
          ORDER BY c.class_name";
$stmt = $conn->prepare($query);
$stmt->execute([$teacher_id]);
$classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle attendance submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $conn->beginTransaction();
        
        $class_id = $_POST['class_id'];
        $date = $_POST['date'];
        $students = $_POST['students'];
        
        // Delete existing attendance for this class and date
        $delete_query = "DELETE FROM attendance WHERE class_id = ? AND date = ?";
        $stmt = $conn->prepare($delete_query);
        $stmt->execute([$class_id, $date]);
        
        // Insert new attendance records
        $insert_query = "INSERT INTO attendance (student_id, class_id, date, status, marked_by) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insert_query);
        
        foreach ($students as $student_id => $status) {
            $stmt->execute([$student_id, $class_id, $date, $status, $teacher_id]);
            
            // Send notification to student if absent or late
            if ($status === 'absent' || $status === 'late') {
                notifyAttendanceUpdate(
                    $student_id, 
                    $status, 
                    $date, 
                    $teacher_name,
                    $conn
                );
                
                // Send notification to parents (future feature)
                notifyParentAttendance(
                    $student_id, 
                    $status, 
                    $date,
                    $conn
                );
            }
        }
        
        $conn->commit();
        echo "<script>showToast('Attendance recorded successfully', 'success');</script>";
    } catch (Exception $e) {
        $conn->rollBack();
        echo "<script>showToast('Error recording attendance: " . $e->getMessage() . "', 'error');</script>";
    }
}

// Get students and attendance for selected class
$students = [];
$attendance = [];
$attendance_stats = [
    'present' => 0,
    'absent' => 0,
    'late' => 0,
    'total' => 0
];

if (isset($_GET['class_id']) && isset($_GET['date'])) {
    $class_id = $_GET['class_id'];
    $date = $_GET['date'];
    
    // Get students in the class
    $students_query = "SELECT s.id, u.username as name FROM students s 
                      JOIN users u ON s.user_id = u.id 
                      WHERE s.class_id = ?";
    $stmt = $conn->prepare($students_query);
    $stmt->execute([$class_id]);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get existing attendance
    $attendance_query = "SELECT student_id, status FROM attendance 
                        WHERE class_id = ? AND date = ?";
    $stmt = $conn->prepare($attendance_query);
    $stmt->execute([$class_id, $date]);
    $attendance = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    
    // Calculate attendance statistics
    $attendance_stats['total'] = count($students);
    foreach ($attendance as $status) {
        $attendance_stats[$status]++;
    }
    
    // Get monthly attendance statistics
    $month_start = date('Y-m-01');
    $month_end = date('Y-m-t');
    
    $monthly_stats_query = "SELECT status, COUNT(*) as count FROM attendance 
                           WHERE class_id = ? AND date BETWEEN ? AND ? 
                           GROUP BY status";
    $stmt = $conn->prepare($monthly_stats_query);
    $stmt->execute([$class_id, $month_start, $month_end]);
    $monthly_stats = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
}

// Get attendance history for the selected class (last 7 days)
$attendance_history = [];
if (isset($_GET['class_id'])) {
    $class_id = $_GET['class_id'];
    $seven_days_ago = date('Y-m-d', strtotime('-7 days'));
    
    $history_query = "SELECT date, 
                      SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present_count,
                      SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent_count,
                      SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) as late_count,
                      COUNT(*) as total_count
                      FROM attendance 
                      WHERE class_id = ? AND date BETWEEN ? AND ?
                      GROUP BY date
                      ORDER BY date DESC";
    $stmt = $conn->prepare($history_query);
    $stmt->execute([$class_id, $seven_days_ago, $today]);
    $attendance_history = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<div class="container mx-auto px-4 py-6">
    <div class="bg-white rounded-lg shadow-lg p-6">
        <h2 class="text-2xl font-bold mb-6">Attendance Management</h2>
        
        <!-- Class and Date Selection Form -->
        <form method="GET" class="mb-8 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Select Class</label>
                <select name="class_id" class="form-select w-full rounded-md border-gray-300" required>
                    <option value="">Select a class</option>
                    <?php foreach ($classes as $class): ?>
                        <option value="<?php echo $class['id']; ?>" 
                                <?php echo (isset($_GET['class_id']) && $_GET['class_id'] == $class['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($class['class_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Select Date</label>
                <input type="date" name="date" 
                       value="<?php echo isset($_GET['date']) ? $_GET['date'] : date('Y-m-d'); ?>" 
                       class="form-input w-full rounded-md border-gray-300" 
                       required>
            </div>
            
            <div class="flex items-end">
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
                    Load Students
                </button>
            </div>
        </form>
        
        <?php if (!empty($students)): ?>
            
            <!-- Attendance Statistics -->
            <div class="mb-6 grid grid-cols-1 md:grid-cols-4 gap-4">
                <div class="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <h3 class="text-lg font-semibold text-blue-800 mb-2">Today's Summary</h3>
                    <div class="grid grid-cols-2 gap-2">
                        <div>
                            <p class="text-sm text-gray-500">Present:</p>
                            <p class="text-lg font-bold"><?php echo $attendance_stats['present']; ?></p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Absent:</p>
                            <p class="text-lg font-bold text-red-600"><?php echo $attendance_stats['absent']; ?></p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Late:</p>
                            <p class="text-lg font-bold text-yellow-600"><?php echo $attendance_stats['late']; ?></p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Total:</p>
                            <p class="text-lg font-bold"><?php echo $attendance_stats['total']; ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-green-50 p-4 rounded-lg border border-green-200 md:col-span-3">
                    <h3 class="text-lg font-semibold text-green-800 mb-2">Recent Attendance History</h3>
                    <?php if (!empty($attendance_history)): ?>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200 text-sm">
                                <thead>
                                    <tr>
                                        <th class="px-3 py-1 text-left">Date</th>
                                        <th class="px-3 py-1 text-left">Present</th>
                                        <th class="px-3 py-1 text-left">Absent</th>
                                        <th class="px-3 py-1 text-left">Late</th>
                                        <th class="px-3 py-1 text-left">Attendance %</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($attendance_history as $day): ?>
                                    <tr>
                                        <td class="px-3 py-1"><?php echo date('M d, Y', strtotime($day['date'])); ?></td>
                                        <td class="px-3 py-1"><?php echo $day['present_count']; ?></td>
                                        <td class="px-3 py-1"><?php echo $day['absent_count']; ?></td>
                                        <td class="px-3 py-1"><?php echo $day['late_count']; ?></td>
                                        <td class="px-3 py-1">
                                            <?php 
                                            $attendance_percent = ($day['present_count'] + ($day['late_count'] * 0.5)) / $day['total_count'] * 100;
                                            echo round($attendance_percent, 1) . '%';
                                            ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-gray-500">No recent attendance records found.</p>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="flex justify-between items-center mb-4">
                <div class="flex space-x-2">
                    <button type="button" class="bg-gray-100 text-gray-700 px-3 py-1 rounded hover:bg-gray-200 text-sm"
                            onclick="markAllAs('present')">
                        Mark All Present
                    </button>
                    <button type="button" class="bg-gray-100 text-gray-700 px-3 py-1 rounded hover:bg-gray-200 text-sm"
                            onclick="markAllAs('absent')">
                        Mark All Absent
                    </button>
                </div>
                
                <div class="relative">
                    <input type="text" id="studentSearch" placeholder="Search students..." 
                           class="form-input rounded-md border-gray-300 pl-8 text-sm">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 absolute left-2 top-2.5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                </div>
            </div>
            
            <!-- Attendance Form -->
            <form method="POST" class="space-y-6" id="attendanceForm">
                <input type="hidden" name="class_id" value="<?php echo $_GET['class_id']; ?>">
                <input type="hidden" name="date" value="<?php echo $_GET['date']; ?>">
                
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200" id="studentsTable">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Student Name
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Status
                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($students as $student): ?>
                                <tr class="student-row">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php echo htmlspecialchars($student['name']); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <select name="students[<?php echo $student['id']; ?>]" 
                                                class="form-select rounded-md border-gray-300 attendance-select">
                                            <option value="present" <?php echo (isset($attendance[$student['id']]) && $attendance[$student['id']] === 'present') ? 'selected' : ''; ?>>
                                                Present
                                            </option>
                                            <option value="absent" <?php echo (isset($attendance[$student['id']]) && $attendance[$student['id']] === 'absent') ? 'selected' : ''; ?>>
                                                Absent
                                            </option>
                                            <option value="late" <?php echo (isset($attendance[$student['id']]) && $attendance[$student['id']] === 'late') ? 'selected' : ''; ?>>
                                                Late
                                            </option>
                                        </select>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="flex justify-end mt-6">
                    <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700">
                        Save Attendance
                    </button>
                </div>
            </form>
        <?php endif; ?>
    </div>
    
    <!-- Attendance Reports Section -->
    <?php if (isset($_GET['class_id'])): ?>
    <div class="bg-white rounded-lg shadow-lg p-6 mt-6">
        <h2 class="text-xl font-bold mb-4">Attendance Reports</h2>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <h3 class="text-lg font-semibold mb-2">Monthly Report</h3>
                <form method="GET" class="mb-4 flex space-x-4">
                    <input type="hidden" name="class_id" value="<?php echo $_GET['class_id']; ?>">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Month</label>
                        <select name="month" class="form-select rounded-md border-gray-300">
                            <?php for ($i = 1; $i <= 12; $i++): ?>
                                <option value="<?php echo $i; ?>" <?php echo $i == $current_month ? 'selected' : ''; ?>>
                                    <?php echo date('F', mktime(0, 0, 0, $i, 1)); ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Year</label>
                        <select name="year" class="form-select rounded-md border-gray-300">
                            <?php for ($i = $current_year - 2; $i <= $current_year; $i++): ?>
                                <option value="<?php echo $i; ?>" <?php echo $i == $current_year ? 'selected' : ''; ?>>
                                    <?php echo $i; ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="flex items-end">
                        <button type="submit" name="report" value="monthly" class="bg-blue-600 text-white px-3 py-1 rounded-md hover:bg-blue-700 text-sm">
                            Generate
                        </button>
                    </div>
                </form>
            </div>
            
            <div>
                <h3 class="text-lg font-semibold mb-2">Date Range Report</h3>
                <form method="GET" class="mb-4 flex space-x-4">
                    <input type="hidden" name="class_id" value="<?php echo $_GET['class_id']; ?>">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
                        <input type="date" name="start_date" class="form-input rounded-md border-gray-300">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">End Date</label>
                        <input type="date" name="end_date" value="<?php echo date('Y-m-d'); ?>" class="form-input rounded-md border-gray-300">
                    </div>
                    <div class="flex items-end">
                        <button type="submit" name="report" value="range" class="bg-blue-600 text-white px-3 py-1 rounded-md hover:bg-blue-700 text-sm">
                            Generate
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="flex justify-end mt-2">
            <a href="#" class="text-blue-600 hover:text-blue-800 text-sm flex items-center" onclick="return false;">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
                Export to Excel
            </a>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
// Function to mark all students as present or absent
function markAllAs(status) {
    const selects = document.querySelectorAll('.attendance-select');
    selects.forEach(select => {
        select.value = status;
    });
}

// Student search functionality
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('studentSearch');
    if (searchInput) {
        searchInput.addEventListener('keyup', function() {
            const searchTerm = this.value.toLowerCase();
            const rows = document.querySelectorAll('.student-row');
            
            rows.forEach(row => {
                const studentName = row.querySelector('td:first-child').textContent.toLowerCase();
                if (studentName.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }
});
</script>

<?php require_once '../../components/footer.php'; ?> 