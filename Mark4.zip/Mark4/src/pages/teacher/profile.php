<?php
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is teacher
if ($_SESSION['role'] !== 'teacher') {
    header('Location: /Mark4/src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Check if phone and address columns exist in teachers table
try {
    $checkColumnsQuery = "SHOW COLUMNS FROM teachers LIKE 'phone'";
    $stmt = $db->query($checkColumnsQuery);
    $phoneColumnExists = $stmt->rowCount() > 0;
    
    $checkColumnsQuery = "SHOW COLUMNS FROM teachers LIKE 'address'";
    $stmt = $db->query($checkColumnsQuery);
    $addressColumnExists = $stmt->rowCount() > 0;
    
    // Add columns if they don't exist
    if (!$phoneColumnExists) {
        $alterQuery = "ALTER TABLE teachers ADD COLUMN phone VARCHAR(20) NULL";
        $db->exec($alterQuery);
    }
    
    if (!$addressColumnExists) {
        $alterQuery = "ALTER TABLE teachers ADD COLUMN address TEXT NULL";
        $db->exec($alterQuery);
    }
} catch (Exception $e) {
    // Just log the error, we'll continue with profile update anyway
    error_log("Error checking or adding columns: " . $e->getMessage());
}

// Get teacher information
$query = "SELECT t.*, u.username, u.email, s.name as school_name 
          FROM teachers t 
          JOIN users u ON t.user_id = u.id 
          JOIN schools s ON t.school_id = s.id 
          WHERE t.user_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$teacher = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$teacher) {
    header('Location: /Mark4/src/pages/login.php');
    exit();
}

// Get teacher's assigned classes and subjects
$query = "SELECT c.class_name, s.name as subject_name 
          FROM teacher_class_assignments tca
          JOIN classes c ON tca.class_id = c.id
          JOIN class_subjects cs ON c.id = cs.class_id
          JOIN subjects s ON cs.subject_id = s.id
          WHERE tca.teacher_id = :teacher_id
          ORDER BY c.class_name, s.name";
$stmt = $db->prepare($query);
$stmt->bindParam(':teacher_id', $_SESSION['user_id']);
$stmt->execute();
$assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $address = $_POST['address'] ?? '';
    $qualification = $_POST['qualification'] ?? '';
    $specialization = $_POST['specialization'] ?? '';

    $errors = [];

    // Validate email
    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }

    // Handle password change
    if (!empty($current_password)) {
        // Verify current password
        $query = "SELECT password FROM users WHERE id = :user_id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':user_id', $_SESSION['user_id']);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!password_verify($current_password, $user['password'])) {
            $errors[] = "Current password is incorrect";
        } elseif (empty($new_password) || empty($confirm_password)) {
            $errors[] = "New password and confirmation are required";
        } elseif ($new_password !== $confirm_password) {
            $errors[] = "New passwords do not match";
        } elseif (strlen($new_password) < 8) {
            $errors[] = "New password must be at least 8 characters long";
        }
    }

    if (empty($errors)) {
        try {
            $db->beginTransaction();

            // Update user email if changed
            if (!empty($email) && $email !== $teacher['email']) {
                $query = "UPDATE users SET email = :email WHERE id = :user_id";
                $stmt = $db->prepare($query);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':user_id', $_SESSION['user_id']);
                $stmt->execute();
            }

            // Update password if requested
            if (!empty($new_password)) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $query = "UPDATE users SET password = :password WHERE id = :user_id";
                $stmt = $db->prepare($query);
                $stmt->bindParam(':password', $hashed_password);
                $stmt->bindParam(':user_id', $_SESSION['user_id']);
                $stmt->execute();
            }

            // Update teacher details
            $query = "UPDATE teachers SET 
                     qualification = :qualification,
                     specialization = :specialization";

            // Add phone and address to query if columns exist
            if (isset($phoneColumnExists) && $phoneColumnExists) {
                $query .= ", phone = :phone";
            }
            if (isset($addressColumnExists) && $addressColumnExists) {
                $query .= ", address = :address";
            }

            $query .= " WHERE user_id = :user_id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':qualification', $qualification);
            $stmt->bindParam(':specialization', $specialization);

            // Bind phone and address if columns exist
            if (isset($phoneColumnExists) && $phoneColumnExists) {
                $stmt->bindParam(':phone', $phone);
            }
            if (isset($addressColumnExists) && $addressColumnExists) {
                $stmt->bindParam(':address', $address);
            }

            $stmt->bindParam(':user_id', $_SESSION['user_id']);
            $stmt->execute();

            $db->commit();
            $success_message = "Profile updated successfully!";
            
            // Refresh teacher data with correct query
            $query = "SELECT t.*, u.username, u.email, s.name as school_name 
                      FROM teachers t 
                      JOIN users u ON t.user_id = u.id 
                      JOIN schools s ON t.school_id = s.id 
                      WHERE t.user_id = :user_id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':user_id', $_SESSION['user_id']);
            $stmt->execute();
            $teacher = $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            // Only roll back if a transaction is active
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            $error_message = "Error updating profile: " . $e->getMessage();
        }
    } else {
        $error_message = implode("<br>", $errors);
    }
}
?>

<!-- Page Content -->
<div class="container mx-auto px-4 py-6">
    <div class="max-w-4xl mx-auto">
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div class="p-6">
                <h2 class="text-2xl font-bold text-gray-900 mb-6">My Profile</h2>

                <?php if (isset($success_message)): ?>
                    <div class="bg-green-50 border-l-4 border-green-500 p-4 mb-6">
                        <div class="flex">
                            <div class="flex-shrink-0">
                                <i class="fas fa-check-circle text-green-500"></i>
                            </div>
                            <div class="ml-3">
                                <p class="text-sm text-green-700"><?php echo $success_message; ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (isset($error_message)): ?>
                    <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
                        <div class="flex">
                            <div class="flex-shrink-0">
                                <i class="fas fa-exclamation-circle text-red-500"></i>
                            </div>
                            <div class="ml-3">
                                <p class="text-sm text-red-700"><?php echo $error_message; ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Basic Information -->
                <div class="bg-gray-50 rounded-lg p-6 mb-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Basic Information</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <p class="text-sm font-medium text-gray-500">Username</p>
                            <p class="mt-1 text-sm text-gray-900"><?php echo htmlspecialchars($teacher['username']); ?></p>
                        </div>
                        <div>
                            <p class="text-sm font-medium text-gray-500">School</p>
                            <p class="mt-1 text-sm text-gray-900"><?php echo htmlspecialchars($teacher['school_name']); ?></p>
                        </div>
                    </div>
                </div>

                <!-- Class Assignments -->
                <div class="bg-gray-50 rounded-lg p-6 mb-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Class Assignments</h3>
                    <?php if (empty($assignments)): ?>
                        <p class="text-sm text-gray-500">No classes assigned yet.</p>
                    <?php else: ?>
                        <div class="grid grid-cols-1 gap-4">
                            <?php foreach ($assignments as $assignment): ?>
                                <div class="flex items-center justify-between p-3 bg-white rounded-lg shadow-sm">
                                    <div>
                                        <p class="text-sm font-medium text-gray-900">
                                            <?php echo htmlspecialchars($assignment['class_name']); ?>
                                        </p>
                                        <p class="text-sm text-gray-500">
                                            <?php echo htmlspecialchars($assignment['subject_name']); ?>
                                        </p>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Profile Update Form -->
                <form method="POST" class="space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="email" class="block text-sm font-medium text-gray-700">Email</label>
                            <input type="email" name="email" id="email" 
                                value="<?php echo htmlspecialchars($teacher['email']); ?>"
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                        </div>
                        <div>
                            <label for="phone" class="block text-sm font-medium text-gray-700">Phone Number</label>
                            <input type="tel" name="phone" id="phone" 
                                value="<?php echo htmlspecialchars($teacher['phone'] ?? ''); ?>"
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                        </div>
                        <div class="md:col-span-2">
                            <label for="address" class="block text-sm font-medium text-gray-700">Address</label>
                            <textarea name="address" id="address" rows="3" 
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                            ><?php echo htmlspecialchars($teacher['address'] ?? ''); ?></textarea>
                        </div>
                        <div>
                            <label for="qualification" class="block text-sm font-medium text-gray-700">Qualification</label>
                            <input type="text" name="qualification" id="qualification" 
                                value="<?php echo htmlspecialchars($teacher['qualification'] ?? ''); ?>"
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                        </div>
                        <div>
                            <label for="specialization" class="block text-sm font-medium text-gray-700">Specialization</label>
                            <input type="text" name="specialization" id="specialization" 
                                value="<?php echo htmlspecialchars($teacher['specialization'] ?? ''); ?>"
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                        </div>
                    </div>

                    <!-- Password Change Section -->
                    <div class="border-t border-gray-200 pt-6">
                        <h3 class="text-lg font-medium text-gray-900 mb-4">Change Password</h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label for="current_password" class="block text-sm font-medium text-gray-700">Current Password</label>
                                <input type="password" name="current_password" id="current_password" 
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            </div>
                            <div>
                                <label for="new_password" class="block text-sm font-medium text-gray-700">New Password</label>
                                <input type="password" name="new_password" id="new_password" 
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            </div>
                            <div>
                                <label for="confirm_password" class="block text-sm font-medium text-gray-700">Confirm New Password</label>
                                <input type="password" name="confirm_password" id="confirm_password" 
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            </div>
                        </div>
                    </div>

                    <div class="flex justify-end">
                        <button type="submit" 
                            class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                            <i class="fas fa-save mr-2"></i>
                            Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../components/footer.php'; ?> 