<?php
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is teacher
if ($_SESSION['role'] !== 'teacher') {
    header('Location: /Mark4/src/pages/login.php');
    exit();
}

// Check if class ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: classes.php');
    exit();
}

$class_id = $_GET['id'];
$user_id = $_SESSION['user_id'];
$database = new Database();
$db = $database->getConnection();

// First check if the teacher is assigned to this class
$query = "SELECT COUNT(*) FROM teacher_class_assignments 
          WHERE teacher_id = :teacher_id AND class_id = :class_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':teacher_id', $user_id);
$stmt->bindParam(':class_id', $class_id);
$stmt->execute();

if ($stmt->fetchColumn() == 0) {
    // Teacher is not assigned to this class
    $_SESSION['error_message'] = "You are not authorized to view this class.";
    header('Location: classes.php');
    exit();
}

// Get class details
$query = "SELECT c.*, s.name AS school_name, u.username AS class_teacher_name
          FROM classes c
          LEFT JOIN schools s ON c.school_id = s.id
          LEFT JOIN users u ON c.class_teacher_id = u.id
          WHERE c.id = :class_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':class_id', $class_id);
$stmt->execute();
$class = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$class) {
    header('Location: classes.php');
    exit();
}

// Get students in this class
$query = "SELECT s.id, s.roll_number, u.username AS name, u.email
          FROM students s 
          JOIN users u ON s.user_id = u.id
          WHERE s.class_id = :class_id
          ORDER BY s.roll_number";
$stmt = $db->prepare($query);
$stmt->bindParam(':class_id', $class_id);
$stmt->execute();
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get subjects taught in this class
$query = "SELECT s.id, s.name, s.code
          FROM subjects s
          JOIN class_subjects cs ON s.id = cs.subject_id
          WHERE cs.class_id = :class_id
          ORDER BY s.name";
$stmt = $db->prepare($query);
$stmt->bindParam(':class_id', $class_id);
$stmt->execute();
$subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get timetable for this class
$query = "SELECT t.*, s.name AS subject_name, u.username AS teacher_name
          FROM timetables t
          JOIN subjects s ON t.subject_id = s.id
          JOIN users u ON t.teacher_id = u.id
          WHERE t.class_id = :class_id
          ORDER BY FIELD(t.day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'), t.start_time";
$stmt = $db->prepare($query);
$stmt->bindParam(':class_id', $class_id);
$stmt->execute();
$timetable = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get exams for this class using multiple approaches to deal with different schema possibilities
try {
    // Get the school_id for this class first
    $query = "SELECT school_id FROM classes WHERE id = :class_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':class_id', $class_id);
    $stmt->execute();
    $school_data = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($school_data && isset($school_data['school_id'])) {
        $school_id = $school_data['school_id'];
        
        // Get exams by school_id
        $query = "SELECT e.id, e.name, e.start_date, e.end_date, e.status
                 FROM exams e
                 WHERE e.school_id = :school_id
                 ORDER BY e.start_date DESC";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':school_id', $school_id);
        $stmt->execute();
        $exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        // Fallback approach through joins if we can't get school_id directly
        $query = "SELECT DISTINCT e.id, e.name, e.start_date, e.end_date, e.status
                 FROM exams e
                 JOIN schools s ON e.school_id = s.id
                 JOIN classes c ON s.id = c.school_id
                 WHERE c.id = :class_id
                 ORDER BY e.start_date DESC";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':class_id', $class_id);
        $stmt->execute();
        $exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    // Log error but continue with empty exams array
    error_log("Error fetching exams: " . $e->getMessage());
    $exams = [];
}
?>

<!-- Page Content -->
<div class="container mx-auto px-4 py-6">
    <div class="mb-6 flex items-center justify-between">
        <div>
            <h1 class="text-2xl font-bold text-gray-900"><?php echo htmlspecialchars($class['class_name']); ?> Details</h1>
            <p class="text-sm text-gray-600">School: <?php echo htmlspecialchars($class['school_name']); ?></p>
        </div>
        <a href="classes.php" class="inline-flex items-center px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-md transition-colors">
            <i class="fas fa-arrow-left mr-2"></i> Back to Classes
        </a>
    </div>

    <!-- Class Information -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden mb-6">
        <div class="px-6 py-4 bg-gray-50 border-b border-gray-200">
            <h2 class="text-lg font-semibold text-gray-900">Class Information</h2>
        </div>
        <div class="p-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <p class="text-sm font-medium text-gray-500">Class Name</p>
                    <p class="mt-1 text-sm text-gray-900"><?php echo htmlspecialchars($class['class_name']); ?></p>
                </div>
                <?php if (isset($class['section']) && !empty($class['section'])): ?>
                <div>
                    <p class="text-sm font-medium text-gray-500">Section</p>
                    <p class="mt-1 text-sm text-gray-900"><?php echo htmlspecialchars($class['section']); ?></p>
                </div>
                <?php endif; ?>
                <div>
                    <p class="text-sm font-medium text-gray-500">Class Teacher</p>
                    <p class="mt-1 text-sm text-gray-900">
                        <?php echo isset($class['class_teacher_name']) ? htmlspecialchars($class['class_teacher_name']) : 'Not assigned'; ?>
                    </p>
                </div>
                <div>
                    <p class="text-sm font-medium text-gray-500">Number of Students</p>
                    <p class="mt-1 text-sm text-gray-900"><?php echo count($students); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Students List -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden mb-6">
        <div class="px-6 py-4 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
            <h2 class="text-lg font-semibold text-gray-900">Students</h2>
            <div class="flex items-center">
                <a href="attendance.php?class_id=<?php echo $class_id; ?>" class="inline-flex items-center px-3 py-1.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors text-sm ml-2">
                    <i class="fas fa-calendar-check mr-1"></i> Attendance
                </a>
                <a href="marks.php?class_id=<?php echo $class_id; ?>" class="inline-flex items-center px-3 py-1.5 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors text-sm ml-2">
                    <i class="fas fa-star mr-1"></i> Marks
                </a>
            </div>
        </div>
        <div class="overflow-x-auto">
            <?php if (empty($students)): ?>
                <div class="p-6 text-center text-gray-500">No students in this class yet.</div>
            <?php else: ?>
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Roll No.</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($students as $student): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($student['roll_number']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo htmlspecialchars($student['name']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo htmlspecialchars($student['email']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <!-- Subjects List -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden mb-6">
        <div class="px-6 py-4 bg-gray-50 border-b border-gray-200">
            <h2 class="text-lg font-semibold text-gray-900">Subjects</h2>
        </div>
        <div class="overflow-x-auto">
            <?php if (empty($subjects)): ?>
                <div class="p-6 text-center text-gray-500">No subjects assigned to this class yet.</div>
            <?php else: ?>
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject Code</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($subjects as $subject): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($subject['code']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo htmlspecialchars($subject['name']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <!-- Timetable -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden mb-6">
        <div class="px-6 py-4 bg-gray-50 border-b border-gray-200">
            <h2 class="text-lg font-semibold text-gray-900">Class Timetable</h2>
        </div>
        <div class="overflow-x-auto">
            <?php if (empty($timetable)): ?>
                <div class="p-6 text-center text-gray-500">No timetable has been created for this class yet.</div>
            <?php else: ?>
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Day</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Time</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Teacher</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($timetable as $entry): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($entry['day_of_week']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    <?php 
                                    echo date('h:i A', strtotime($entry['start_time'])) . ' - ' . 
                                         date('h:i A', strtotime($entry['end_time'])); 
                                    ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo htmlspecialchars($entry['subject_name']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($entry['teacher_name']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <!-- Exams -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="px-6 py-4 bg-gray-50 border-b border-gray-200">
            <h2 class="text-lg font-semibold text-gray-900">Exams</h2>
        </div>
        <div class="overflow-x-auto">
            <?php if (empty($exams)): ?>
                <div class="p-6 text-center text-gray-500">No exams have been scheduled for this class yet.</div>
            <?php else: ?>
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Exam Name</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Duration</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($exams as $exam): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo htmlspecialchars($exam['name']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    <?php 
                                    echo date('M d, Y', strtotime($exam['start_date'])) . ' - ' . 
                                         date('M d, Y', strtotime($exam['end_date'])); 
                                    ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php 
                                    $status_colors = [
                                        'scheduled' => 'bg-yellow-100 text-yellow-800',
                                        'ongoing' => 'bg-blue-100 text-blue-800',
                                        'completed' => 'bg-green-100 text-green-800',
                                        'cancelled' => 'bg-red-100 text-red-800'
                                    ];
                                    $color = $status_colors[$exam['status']] ?? 'bg-gray-100 text-gray-800';
                                    ?>
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $color; ?>">
                                        <?php echo ucfirst(htmlspecialchars($exam['status'])); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm">
                                    <a href="marks.php?exam_id=<?php echo $exam['id']; ?>&class_id=<?php echo $class_id; ?>" 
                                       class="text-indigo-600 hover:text-indigo-900">Enter Marks</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../../components/footer.php'; ?> 