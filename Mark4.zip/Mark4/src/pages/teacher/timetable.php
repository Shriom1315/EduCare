<?php
ob_start();
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is teacher
if ($_SESSION['role'] !== 'teacher') {
    header('Location: /src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get teacher information
$query = "SELECT t.*, s.id as school_id FROM teachers t 
          JOIN schools s ON t.school_id = s.id 
          WHERE t.user_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$teacher = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$teacher) {
    header('Location: /src/pages/login.php');
    exit();
}

// Fetch timetable entries for the teacher
try {
    $query = "SELECT t.*, c.class_name, s.name as subject_name 
              FROM timetables t 
              JOIN classes c ON t.class_id = c.id 
              JOIN subjects s ON t.subject_id = s.id 
              WHERE t.teacher_id = :teacher_id 
              ORDER BY t.day_of_week, t.start_time";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':teacher_id', $_SESSION['user_id']);
    $stmt->execute();
    $timetable_entries = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $timetable_entries = [];
    $_SESSION['error_message'] = "Error loading timetable entries: " . $e->getMessage();
}

// Group timetable entries by day
$timetable_by_day = [];
foreach ($timetable_entries as $entry) {
    if (!isset($timetable_by_day[$entry['day_of_week']])) {
        $timetable_by_day[$entry['day_of_week']] = [];
    }
    $timetable_by_day[$entry['day_of_week']][] = $entry;
}
?>

<!-- Page Content -->
<div class="container mx-auto px-4 py-6">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">My Timetable</h1>
    </div>
    
    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
            <p><?php echo $_SESSION['error_message']; ?></p>
        </div>
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>
    
    <!-- Timetable Display -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Time</th>
                        <?php
                        $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                        foreach ($days as $day):
                        ?>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo $day; ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php
                    $time_slots = [];
                    foreach ($timetable_entries as $entry) {
                        $time_slots[$entry['start_time']] = true;
                    }
                    ksort($time_slots);
                    
                    foreach ($time_slots as $time => $dummy):
                        $start_time = date('h:i A', strtotime($time));
                        $end_time = date('h:i A', strtotime($time) + 3600); // Assuming 1-hour slots
                    ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <?php echo $start_time . ' - ' . $end_time; ?>
                            </td>
                            <?php foreach ($days as $day): ?>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php
                                    if (isset($timetable_by_day[$day])) {
                                        foreach ($timetable_by_day[$day] as $entry) {
                                            if ($entry['start_time'] === $time) {
                                                echo '<div class="text-sm">';
                                                echo '<div class="font-medium text-gray-900">' . htmlspecialchars($entry['subject_name']) . '</div>';
                                                echo '<div class="text-gray-500">' . htmlspecialchars($entry['class_name']) . '</div>';
                                                echo '</div>';
                                            }
                                        }
                                    }
                                    ?>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../../components/footer.php'; ?>

<?php ob_end_flush(); ?> 