<?php
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is logged in and is a teacher
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header('Location: /src/pages/login.php');
    exit();
}

$db = new Database();
$conn = $db->getConnection();
$teacher_id = $_SESSION['user_id'];

// Get teacher's classes with subjects
$classes_query = "SELECT c.*, GROUP_CONCAT(DISTINCT s.name) as subjects,
                 (SELECT COUNT(*) FROM students st WHERE st.class_id = c.id) as student_count
                 FROM classes c 
                 INNER JOIN teacher_class_assignments tca ON c.id = tca.class_id 
                 LEFT JOIN class_subjects cs ON c.id = cs.class_id
                 LEFT JOIN subjects s ON cs.subject_id = s.id
                 WHERE tca.teacher_id = ?
                 GROUP BY c.id";
$stmt = $conn->prepare($classes_query);
$stmt->execute([$teacher_id]);
$classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get class details if class_id is provided
$selected_class = null;
$students = [];
$subjects = [];
if (isset($_GET['class_id'])) {
    $class_id = $_GET['class_id'];
    
    // Get class details
    $class_query = "SELECT c.*, GROUP_CONCAT(DISTINCT s.name) as subjects
                   FROM classes c 
                   LEFT JOIN class_subjects cs ON c.id = cs.class_id
                   LEFT JOIN subjects s ON cs.subject_id = s.id
                   WHERE c.id = ?
                   GROUP BY c.id";
    $stmt = $conn->prepare($class_query);
    $stmt->execute([$class_id]);
    $selected_class = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Get students in the class
    $students_query = "SELECT u.id, u.username as name, u.email 
                      FROM users u 
                      JOIN students s ON u.id = s.user_id 
                      WHERE s.class_id = ?";
    $stmt = $conn->prepare($students_query);
    $stmt->execute([$class_id]);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get subjects taught in the class
    $subjects_query = "SELECT s.* FROM subjects s 
                      INNER JOIN class_subjects cs ON s.id = cs.subject_id 
                      WHERE cs.class_id = ?";
    $stmt = $conn->prepare($subjects_query);
    $stmt->execute([$class_id]);
    $subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get student count for each class
$student_counts = [];
$count_query = "SELECT class_id, COUNT(*) as count FROM students GROUP BY class_id";
$stmt = $conn->prepare($count_query);
$stmt->execute();
$counts = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach ($counts as $count) {
    $student_counts[$count['class_id']] = $count['count'];
}
?>

<div class="container mx-auto px-4 py-6">
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- Classes List -->
        <div class="md:col-span-1">
            <div class="bg-white rounded-lg shadow-lg p-6">
                <h2 class="text-xl font-bold mb-4">My Classes</h2>
                <div class="space-y-4">
                    <?php foreach ($classes as $class): ?>
                        <a href="?class_id=<?php echo $class['id']; ?>" 
                           class="block p-4 rounded-lg border <?php echo (isset($_GET['class_id']) && $_GET['class_id'] == $class['id']) ? 'bg-blue-50 border-blue-500' : 'border-gray-200 hover:bg-gray-50'; ?>">
                            <h3 class="font-semibold text-lg"><?php echo htmlspecialchars($class['class_name']); ?></h3>
                            <p class="text-sm text-gray-600 mt-1">
                                <?php echo $student_counts[$class['id']]; ?> Students
                            </p>
                            <p class="text-sm text-gray-600 mt-1">
                                Subjects: <?php echo htmlspecialchars($class['subjects']); ?>
                            </p>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        
        <!-- Class Details -->
        <div class="md:col-span-2">
            <?php if ($selected_class): ?>
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <h2 class="text-2xl font-bold mb-6"><?php echo htmlspecialchars($selected_class['class_name']); ?></h2>
                    
                    <!-- Class Information -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                        <div>
                            <h3 class="text-lg font-semibold mb-2">Class Information</h3>
                            <div class="space-y-2">
                                <p><span class="font-medium">Class Name:</span> <?php echo htmlspecialchars($selected_class['class_name']); ?></p>
                                <p><span class="font-medium">Number of Students:</span> <?php echo $student_counts[$selected_class['id']]; ?></p>
                            </div>
                        </div>
                        
                        <div>
                            <h3 class="text-lg font-semibold mb-2">Subjects</h3>
                            <div class="flex flex-wrap gap-2">
                                <?php foreach ($subjects as $subject): ?>
                                    <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                                        <?php echo htmlspecialchars($subject['name']); ?>
                                    </span>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Students List -->
                    <div>
                        <h3 class="text-lg font-semibold mb-4">Students (<?php echo count($students); ?>)</h3>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Name
                                        </th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Email
                                        </th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Actions
                                        </th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php foreach ($students as $student): ?>
                                        <tr>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <?php echo htmlspecialchars($student['name']); ?>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <?php echo htmlspecialchars($student['email']); ?>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="flex space-x-2">
                                                    <a href="marks.php?student_id=<?php echo $student['id']; ?>&class_id=<?php echo $_GET['class_id']; ?>" 
                                                       class="text-blue-600 hover:text-blue-800">
                                                        View Marks
                                                    </a>
                                                    <a href="attendance.php?student_id=<?php echo $student['id']; ?>&class_id=<?php echo $_GET['class_id']; ?>" 
                                                       class="text-green-600 hover:text-green-800">
                                                        View Attendance
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="bg-white rounded-lg shadow-lg p-6 text-center">
                    <p class="text-gray-600">Select a class to view details</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../../components/footer.php'; ?> 