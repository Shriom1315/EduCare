<?php
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is teacher
if ($_SESSION['role'] !== 'teacher') {
    header('Location: /Mark4/src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get teacher information
$query = "SELECT t.*, s.id as school_id FROM teachers t 
          JOIN schools s ON t.school_id = s.id 
          WHERE t.user_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$teacher = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$teacher) {
    header('Location: /Mark4/src/pages/login.php');
    exit();
}

// Get upcoming exams
$query = "SELECT e.*, es.*, s.name as subject_name, c.class_name 
          FROM exams e 
          JOIN exam_subjects es ON e.id = es.exam_id 
          JOIN subjects s ON es.subject_id = s.id 
          JOIN class_subjects cs ON s.id = cs.subject_id
          JOIN classes c ON cs.class_id = c.id 
          WHERE es.teacher_id = :teacher_id 
          AND e.status = 'active'
          AND es.exam_date >= CURDATE() 
          ORDER BY es.exam_date, es.start_time";
$stmt = $db->prepare($query);
$stmt->bindParam(':teacher_id', $teacher['user_id']);
$stmt->execute();
$upcoming_exams = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get past exams
$query = "SELECT e.*, es.*, s.name as subject_name, c.class_name 
          FROM exams e 
          JOIN exam_subjects es ON e.id = es.exam_id 
          JOIN subjects s ON es.subject_id = s.id 
          JOIN class_subjects cs ON s.id = cs.subject_id
          JOIN classes c ON cs.class_id = c.id 
          WHERE es.teacher_id = :teacher_id 
          AND (e.status = 'completed' OR es.exam_date < CURDATE()) 
          ORDER BY es.exam_date DESC";
$stmt = $db->prepare($query);
$stmt->bindParam(':teacher_id', $teacher['user_id']);
$stmt->execute();
$past_exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- Page Content -->
<div class="container mx-auto px-4 py-6">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">My Exams</h1>
        <div class="text-sm text-gray-600">
            Teacher: <?php echo htmlspecialchars($teacher['name']); ?>
        </div>
    </div>
    
    <!-- Upcoming Exams -->
    <div class="mb-8">
        <h2 class="text-xl font-bold text-gray-800 mb-4">Upcoming Exams</h2>
        <?php if (empty($upcoming_exams)): ?>
            <p class="text-gray-500 text-center py-4">No upcoming exams.</p>
        <?php else: ?>
            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Exam</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Class</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date & Time</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Marks</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($upcoming_exams as $exam): ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($exam['name']); ?></div>
                                        <?php if (!empty($exam['description'])): ?>
                                            <div class="text-sm text-gray-500"><?php echo htmlspecialchars($exam['description']); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-500"><?php echo htmlspecialchars($exam['subject_name']); ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-500"><?php echo htmlspecialchars($exam['class_name']); ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-500">
                                            <?php echo date('F j, Y', strtotime($exam['exam_date'])); ?><br>
                                            <?php echo date('h:i A', strtotime($exam['start_time'])); ?> - 
                                            <?php echo date('h:i A', strtotime($exam['end_time'])); ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-500">
                                            Max: <?php echo $exam['max_marks']; ?><br>
                                            Pass: <?php echo $exam['pass_marks']; ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                            <?php echo ucfirst($exam['status']); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                        <a href="marks.php?exam_id=<?php echo $exam['exam_id']; ?>&subject_id=<?php echo $exam['subject_id']; ?>" 
                                           class="text-blue-600 hover:text-blue-900">
                                            <i class="fas fa-edit"></i> Enter Marks
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Past Exams -->
    <div>
        <h2 class="text-xl font-bold text-gray-800 mb-4">Past Exams</h2>
        <?php if (empty($past_exams)): ?>
            <p class="text-gray-500 text-center py-4">No past exams found.</p>
        <?php else: ?>
            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Exam</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Class</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date & Time</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Marks</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($past_exams as $exam): ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($exam['name']); ?></div>
                                        <?php if (!empty($exam['description'])): ?>
                                            <div class="text-sm text-gray-500"><?php echo htmlspecialchars($exam['description']); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-500"><?php echo htmlspecialchars($exam['subject_name']); ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-500"><?php echo htmlspecialchars($exam['class_name']); ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-500">
                                            <?php echo date('F j, Y', strtotime($exam['exam_date'])); ?><br>
                                            <?php echo date('h:i A', strtotime($exam['start_time'])); ?> - 
                                            <?php echo date('h:i A', strtotime($exam['end_time'])); ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-500">
                                            Max: <?php echo $exam['max_marks']; ?><br>
                                            Pass: <?php echo $exam['pass_marks']; ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                            <?php echo ucfirst($exam['status']); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                        <a href="marks.php?exam_id=<?php echo $exam['exam_id']; ?>&subject_id=<?php echo $exam['subject_id']; ?>" 
                                           class="text-blue-600 hover:text-blue-900">
                                            <i class="fas fa-edit"></i> Enter/View Marks
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../../components/footer.php'; ?> 