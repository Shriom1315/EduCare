<?php
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is logged in and is a teacher
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header('Location: /src/pages/login.php');
    exit();
}

$db = new Database();
$conn = $db->getConnection();
$teacher_id = $_SESSION['user_id'];

// Check if user is a class teacher for any classes
$class_teacher_query = "SELECT c.id, c.class_name 
                       FROM classes c 
                       WHERE c.class_teacher_id = ?";
$stmt = $conn->prepare($class_teacher_query);
$stmt->execute([$teacher_id]);
$class_teacher_classes = $stmt->fetchAll(PDO::FETCH_ASSOC);
$is_class_teacher = !empty($class_teacher_classes);

// Get teacher's classes
$classes_query = "SELECT c.* FROM classes c 
                 INNER JOIN teacher_class_assignments tca ON c.id = tca.class_id 
                 WHERE tca.teacher_id = ?";
$stmt = $conn->prepare($classes_query);
$stmt->execute([$teacher_id]);
$classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get subjects taught by the teacher
$subjects_query = "SELECT DISTINCT s.* FROM subjects s 
                  INNER JOIN class_subjects cs ON s.id = cs.subject_id 
                  INNER JOIN teacher_class_assignments tca ON cs.class_id = tca.class_id 
                  WHERE tca.teacher_id = ?";
$stmt = $conn->prepare($subjects_query);
$stmt->execute([$teacher_id]);
$subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle marks submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $conn->beginTransaction();
        
        if (isset($_POST['enter_marks'])) {
            $class_id = $_POST['class_id'];
            $subject_id = $_POST['subject_id'];
            $exam_id = $_POST['exam_id'] ?? null;
            $exam_type = $_POST['exam_type'];
            $marks = $_POST['marks'];
            
            // Check if this teacher is authorized to enter marks for this subject
            $auth_query = "SELECT COUNT(*) FROM teacher_subjects 
                          WHERE teacher_id = ? AND subject_id = ?";
            $stmt = $conn->prepare($auth_query);
            $stmt->execute([$teacher_id, $subject_id]);
            $is_authorized = $stmt->fetchColumn() > 0;
            
            if (!$is_authorized) {
                throw new Exception("You are not authorized to enter marks for this subject.");
            }
            
            // Delete existing marks for this class, subject and exam type
            $delete_query = "DELETE FROM marks WHERE class_id = ? AND subject_id = ? AND exam_type = ?";
            if ($exam_id) {
                $delete_query .= " AND exam_id = ?";
                $delete_params = [$class_id, $subject_id, $exam_type, $exam_id];
            } else {
                $delete_params = [$class_id, $subject_id, $exam_type];
            }
            $stmt = $conn->prepare($delete_query);
            $stmt->execute($delete_params);
            
            // Insert new marks
            $insert_query = "INSERT INTO marks (student_id, class_id, subject_id, exam_id, exam_type, marks, max_marks, remarks, status, entered_by, entry_date) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, NOW())";
            $stmt = $conn->prepare($insert_query);
            
            foreach ($marks as $student_id => $data) {
                $stmt->execute([
                    $student_id, 
                    $class_id, 
                    $subject_id,
                    $exam_id,
                    $exam_type, 
                    $data['marks'], 
                    $data['max_marks'] ?? 100,
                    $data['remarks'] ?? '',
                    $teacher_id
                ]);
            }
            
            $conn->commit();
            echo "<script>showToast('Marks recorded successfully and sent for approval.', 'success');</script>";
        } elseif (isset($_POST['approve_marks'])) {
            // Only class teachers can approve marks
            if (!$is_class_teacher) {
                throw new Exception("You must be a class teacher to approve marks.");
            }
            
            $mark_ids = $_POST['mark_ids'] ?? [];
            
            if (empty($mark_ids)) {
                throw new Exception("No marks selected for approval.");
            }
            
            // Update marks status
            $update_query = "UPDATE marks SET status = 'pending_principal', approved_by = ?, approval_date = NOW() 
                           WHERE id IN (" . implode(',', array_fill(0, count($mark_ids), '?')) . ")";
            $stmt = $conn->prepare($update_query);
            $params = array_merge([$teacher_id], $mark_ids);
            $stmt->execute($params);
            
            $conn->commit();
            echo "<script>showToast('Marks approved and sent to principal for final approval.', 'success');</script>";
        }
    } catch (Exception $e) {
        $conn->rollBack();
        echo "<script>showToast('Error: " . addslashes($e->getMessage()) . "', 'error');</script>";
    }
}

// Get students and marks for selected class and subject
$students = [];
$marks = [];
if (isset($_GET['class_id']) && isset($_GET['subject_id']) && isset($_GET['exam_type'])) {
    $class_id = $_GET['class_id'];
    $subject_id = $_GET['subject_id'];
    $exam_type = $_GET['exam_type'];
    
    // Get students in the class
    $students_query = "SELECT id, first_name, last_name FROM users 
                      WHERE role = 'student' AND id IN 
                      (SELECT student_id FROM class_students WHERE class_id = ?)";
    $stmt = $conn->prepare($students_query);
    $stmt->execute([$class_id]);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get existing marks
    $marks_query = "SELECT student_id, marks, remarks FROM marks 
                   WHERE class_id = ? AND subject_id = ? AND exam_type = ?";
    $stmt = $conn->prepare($marks_query);
    $stmt->execute([$class_id, $subject_id, $exam_type]);
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $marks[$row['student_id']] = [
            'marks' => $row['marks'],
            'remarks' => $row['remarks']
        ];
    }
}

// Check if we're in mark approval mode
$approval_mode = isset($_GET['approve']) && $_GET['approve'] === 'true' && $is_class_teacher;

// If in approval mode, get pending marks for class teacher
$pending_marks = [];
$pending_classes = [];
if ($approval_mode) {
    try {
        // Get classes where user is class teacher
        $class_ids = array_column($class_teacher_classes, 'id');
        
        if (!empty($class_ids)) {
            $placeholders = implode(',', array_fill(0, count($class_ids), '?'));
            
            // Get pending marks across all subjects for these classes
            $pending_query = "SELECT m.*, c.class_name, s.name as subject_name, 
                             st.roll_number, u.username as student_name,
                             u2.username as entered_by_name
                             FROM marks m
                             JOIN classes c ON m.class_id = c.id
                             JOIN subjects s ON m.subject_id = s.id
                             JOIN students st ON m.student_id = st.id
                             JOIN users u ON st.user_id = u.id
                             JOIN users u2 ON m.entered_by = u2.id
                             WHERE m.class_id IN ($placeholders)
                             AND m.status = 'pending'
                             ORDER BY c.class_name, s.name, st.roll_number";
            
            $stmt = $conn->prepare($pending_query);
            $stmt->execute($class_ids);
            $pending_marks = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Group by class and subject
            foreach ($pending_marks as $mark) {
                if (!isset($pending_classes[$mark['class_id']])) {
                    $pending_classes[$mark['class_id']] = [
                        'name' => $mark['class_name'],
                        'subjects' => []
                    ];
                }
                if (!isset($pending_classes[$mark['class_id']]['subjects'][$mark['subject_id']])) {
                    $pending_classes[$mark['class_id']]['subjects'][$mark['subject_id']] = [
                        'name' => $mark['subject_name'],
                        'marks' => []
                    ];
                }
                $pending_classes[$mark['class_id']]['subjects'][$mark['subject_id']]['marks'][] = $mark;
            }
        }
    } catch (Exception $e) {
        echo "<script>showToast('Error loading pending marks: " . addslashes($e->getMessage()) . "', 'error');</script>";
    }
}
?>

<div class="container mx-auto px-4 py-6">
    <div class="bg-white rounded-lg shadow-lg p-6">
        <h2 class="text-2xl font-bold mb-6">Marks Management</h2>
        
        <?php if ($is_class_teacher): ?>
        <!-- Tabs for class teacher -->
        <div class="mb-6 border-b border-gray-200">
            <ul class="flex flex-wrap -mb-px">
                <li class="mr-2">
                    <a href="marks.php" class="inline-block p-4 <?php echo !$approval_mode ? 'border-b-2 border-blue-600 text-blue-600' : 'border-b-2 border-transparent hover:border-gray-300 text-gray-500 hover:text-gray-700'; ?>">
                        Enter Marks
                    </a>
                </li>
                <li class="mr-2">
                    <a href="marks.php?approve=true" class="inline-block p-4 <?php echo $approval_mode ? 'border-b-2 border-blue-600 text-blue-600' : 'border-b-2 border-transparent hover:border-gray-300 text-gray-500 hover:text-gray-700'; ?>">
                        Approve Marks
                        <?php 
                        if (!empty($pending_marks)) {
                            echo '<span class="ml-2 bg-red-500 text-white text-xs px-2 py-1 rounded-full">' . count($pending_marks) . '</span>';
                        }
                        ?>
                    </a>
                </li>
            </ul>
        </div>
        <?php endif; ?>
        
        <?php if ($approval_mode): ?>
        <!-- Approval Interface for Class Teacher -->
        <div class="space-y-8">
            <?php if (empty($pending_classes)): ?>
                <div class="text-center py-8 text-gray-500">
                    <p>No pending marks require your approval.</p>
                </div>
            <?php else: ?>
                <?php foreach ($pending_classes as $class_id => $class_data): ?>
                    <div class="bg-gray-50 rounded-lg p-4">
                        <h3 class="text-lg font-semibold mb-4"><?php echo htmlspecialchars($class_data['name']); ?></h3>
                        
                        <?php foreach ($class_data['subjects'] as $subject_id => $subject_data): ?>
                            <div class="mb-6">
                                <h4 class="text-md font-medium mb-3"><?php echo htmlspecialchars($subject_data['name']); ?></h4>
                                
                                <form method="POST" class="space-y-4">
                                    <div class="overflow-x-auto">
                                        <table class="min-w-full divide-y divide-gray-200">
                                            <thead class="bg-gray-50">
                                                <tr>
                                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                        <input type="checkbox" id="select-all-<?php echo $subject_id; ?>" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded" onclick="toggleAllMarks(this, '<?php echo $subject_id; ?>')">
                                                    </th>
                                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                        Roll No.
                                                    </th>
                                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                        Student Name
                                                    </th>
                                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                        Marks
                                                    </th>
                                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                        Entered By
                                                    </th>
                                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                        Remarks
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody class="bg-white divide-y divide-gray-200">
                                                <?php foreach ($subject_data['marks'] as $mark): ?>
                                                    <tr>
                                                        <td class="px-6 py-4 whitespace-nowrap">
                                                            <input type="checkbox" name="mark_ids[]" value="<?php echo $mark['id']; ?>" class="mark-checkbox-<?php echo $subject_id; ?> h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                                                        </td>
                                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                            <?php echo htmlspecialchars($mark['roll_number']); ?>
                                                        </td>
                                                        <td class="px-6 py-4 whitespace-nowrap">
                                                            <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($mark['student_name']); ?></div>
                                                        </td>
                                                        <td class="px-6 py-4 whitespace-nowrap">
                                                            <div class="text-sm text-gray-900"><?php echo $mark['marks']; ?> / <?php echo $mark['max_marks']; ?></div>
                                                            <div class="text-xs text-gray-500">
                                                                <?php echo round(($mark['marks'] / $mark['max_marks']) * 100, 1); ?>%
                                                            </div>
                                                        </td>
                                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                            <?php echo htmlspecialchars($mark['entered_by_name']); ?>
                                                        </td>
                                                        <td class="px-6 py-4 text-sm text-gray-500">
                                                            <?php echo htmlspecialchars($mark['remarks']); ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    
                                    <div class="flex justify-end">
                                        <button type="submit" name="approve_marks" class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition-colors">
                                            Approve Selected Marks
                                        </button>
                                    </div>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <?php else: ?>
        <!-- Normal Marks Entry Interface -->
        <!-- Selection Form -->
        <form method="GET" class="mb-8 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Select Class</label>
                <select name="class_id" class="form-select w-full rounded-md border-gray-300" required>
                    <option value="">Select a class</option>
                    <?php foreach ($classes as $class): ?>
                        <option value="<?php echo $class['id']; ?>" 
                                <?php echo (isset($_GET['class_id']) && $_GET['class_id'] == $class['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($class['class_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Select Subject</label>
                <select name="subject_id" class="form-select w-full rounded-md border-gray-300" required>
                    <option value="">Select a subject</option>
                    <?php foreach ($subjects as $subject): ?>
                        <option value="<?php echo $subject['id']; ?>" 
                                <?php echo (isset($_GET['subject_id']) && $_GET['subject_id'] == $subject['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($subject['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Exam Type</label>
                <select name="exam_type" class="form-select w-full rounded-md border-gray-300" required>
                    <option value="">Select exam type</option>
                    <option value="midterm" <?php echo (isset($_GET['exam_type']) && $_GET['exam_type'] === 'midterm') ? 'selected' : ''; ?>>
                        Midterm
                    </option>
                    <option value="final" <?php echo (isset($_GET['exam_type']) && $_GET['exam_type'] === 'final') ? 'selected' : ''; ?>>
                        Final
                    </option>
                    <option value="assignment" <?php echo (isset($_GET['exam_type']) && $_GET['exam_type'] === 'assignment') ? 'selected' : ''; ?>>
                        Assignment
                    </option>
                </select>
            </div>
            
            <div class="flex items-end">
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
                    Load Students
                </button>
            </div>
        </form>
        
        <?php if (!empty($students)): ?>
            <!-- Marks Form -->
            <form method="POST" class="space-y-6">
                <input type="hidden" name="class_id" value="<?php echo $_GET['class_id']; ?>">
                <input type="hidden" name="subject_id" value="<?php echo $_GET['subject_id']; ?>">
                <input type="hidden" name="exam_type" value="<?php echo $_GET['exam_type']; ?>">
                <?php if (isset($_GET['exam_id'])): ?>
                <input type="hidden" name="exam_id" value="<?php echo $_GET['exam_id']; ?>">
                <?php endif; ?>
                
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Student Name
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Marks
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Max Marks
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Remarks
                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($students as $student): ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <input type="number" 
                                               name="marks[<?php echo $student['id']; ?>][marks]" 
                                               value="<?php echo isset($marks[$student['id']]) ? $marks[$student['id']]['marks'] : ''; ?>" 
                                               class="form-input rounded-md border-gray-300 w-24" 
                                               min="0" 
                                               max="100" 
                                               step="0.01" 
                                               required>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <input type="number" 
                                               name="marks[<?php echo $student['id']; ?>][max_marks]" 
                                               value="<?php echo isset($marks[$student['id']]) ? $marks[$student['id']]['max_marks'] : '100'; ?>" 
                                               class="form-input rounded-md border-gray-300 w-24" 
                                               min="1" 
                                               max="1000" 
                                               step="1" 
                                               required>
                                    </td>
                                    <td class="px-6 py-4">
                                        <input type="text" 
                                               name="marks[<?php echo $student['id']; ?>][remarks]" 
                                               value="<?php echo isset($marks[$student['id']]) ? $marks[$student['id']]['remarks'] : ''; ?>" 
                                               class="form-input rounded-md border-gray-300 w-full" 
                                               placeholder="Optional remarks">
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="flex justify-end mt-6">
                    <button type="submit" name="enter_marks" class="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700">
                        Save Marks
                    </button>
                </div>
            </form>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<script>
function toggleAllMarks(checkbox, subjectId) {
    const checkboxes = document.getElementsByClassName('mark-checkbox-' + subjectId);
    for (let i = 0; i < checkboxes.length; i++) {
        checkboxes[i].checked = checkbox.checked;
    }
}
</script>

<?php require_once '../../components/footer.php'; ?> 