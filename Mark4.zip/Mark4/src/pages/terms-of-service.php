<?php
require_once '../config/database.php';
require_once '../components/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-8" style="background: white; border-radius: 0.5rem; padding: 2rem; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
        <h1 class="text-3xl font-bold text-gray-800 mb-6">Terms of Service</h1>
        
        <div class="prose max-w-none">
            <p class="text-gray-600 mb-4">Last Updated: <?php echo date('F d, Y'); ?></p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">1. Acceptance of Terms</h2>
            <p class="mb-4">
                By accessing or using the School Management System, you agree to be bound by these Terms of Service. 
                If you do not agree to these terms, please do not use our system.
            </p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">2. Description of Service</h2>
            <p class="mb-4">
                The School Management System is a platform designed to facilitate educational administration, 
                communication, and learning management. It provides tools for managing student records, curriculum, 
                attendance, grades, and communication between school administration, teachers, students, and parents.
            </p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">3. User Accounts</h2>
            <p class="mb-3">
                To use certain features of our system, you may need to create an account. You agree to:
            </p>
            <ul class="list-disc pl-6 mb-4" style="list-style-type: disc; padding-left: 1.5rem;">
                <li class="mb-2">Provide accurate, current, and complete information</li>
                <li class="mb-2">Maintain and promptly update your account information</li>
                <li class="mb-2">Keep your password secure and confidential</li>
                <li class="mb-2">Notify us immediately of any unauthorized use of your account</li>
                <li class="mb-2">Accept responsibility for all activities that occur under your account</li>
            </ul>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">4. User Conduct</h2>
            <p class="mb-3">
                When using our system, you agree not to:
            </p>
            <ul class="list-disc pl-6 mb-4" style="list-style-type: disc; padding-left: 1.5rem;">
                <li class="mb-2">Violate any applicable laws or regulations</li>
                <li class="mb-2">Impersonate any person or entity</li>
                <li class="mb-2">Upload or transmit viruses or malicious code</li>
                <li class="mb-2">Attempt to gain unauthorized access to the system</li>
                <li class="mb-2">Interfere with or disrupt the system's functionality</li>
                <li class="mb-2">Harass, bully, or intimidate other users</li>
                <li class="mb-2">Share offensive, inappropriate, or sensitive content</li>
            </ul>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">5. Intellectual Property</h2>
            <p class="mb-4">
                The School Management System, including its content, features, and functionality, is owned by us and is protected by 
                intellectual property laws. You may not reproduce, distribute, modify, create derivative works of, 
                publicly display, or exploit any content from our system without our permission.
            </p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">6. Privacy</h2>
            <p class="mb-4">
                Your use of our system is also governed by our Privacy Policy, which can be found 
                <a href="privacy-policy.php" class="text-blue-600 hover:underline" style="color: #2563eb; text-decoration: none;">here</a>.
            </p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">7. Disclaimer of Warranties</h2>
            <p class="mb-4" style="text-transform: uppercase;">
                The School Management System is provided "as is" without warranties of any kind, 
                either express or implied. We disclaim all warranties, including implied warranties 
                of merchantability, fitness for a particular purpose, and non-infringement.
            </p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">8. Limitation of Liability</h2>
            <p class="mb-4" style="text-transform: uppercase;">
                To the maximum extent permitted by law, we shall not be liable for any indirect, 
                incidental, special, consequential, or punitive damages, including loss of profits, 
                data, or goodwill, arising from your use of or inability to use our system.
            </p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">9. Term and Termination</h2>
            <p class="mb-4">
                We may suspend or terminate your access to the School Management System at any time, 
                without notice, for conduct that we believe violates these Terms of Service or is 
                harmful to other users, us, or third parties, or for any other reason.
            </p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">10. Changes to Terms</h2>
            <p class="mb-4">
                We may modify these Terms of Service at any time. It is your responsibility to review 
                these terms periodically. Your continued use of our system after any changes indicates 
                your acceptance of the modified terms.
            </p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">11. Governing Law</h2>
            <p class="mb-4">
                These Terms of Service shall be governed by and construed in accordance with the laws 
                of the jurisdiction in which we operate, without regard to its conflict of law provisions.
            </p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-6 mb-3">12. Contact Us</h2>
            <p class="mb-4">
                If you have any questions about these Terms of Service, please contact us at:
            </p>
            <div class="pl-6 mb-6">
                <p class="mb-1">Email: legal@schoolmanagementsystem.com</p>
                <p class="mb-1">Phone: +1-234-567-8900</p>
                <p>Address: 123 Education Street, Learning City, 54321</p>
            </div>
        </div>
    </div>
</div>

<?php require_once '../components/footer.php'; ?> 