<?php
require_once '../../config/database.php';
require_once '../../components/header.php';
require_once '../../utils/notification_utils.php';

// Check if user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('Location: /src/pages/login.php');
    exit();
}

$db = new Database();
$conn = $db->getConnection();
$student_id = $_SESSION['user_id'];

// Get student's ID from students table
$student_query = "SELECT id, class_id FROM students WHERE user_id = ?";
$stmt = $conn->prepare($student_query);
$stmt->execute([$student_id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    header('Location: /src/pages/login.php');
    exit();
}

// Handle absence reason submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['attendance_id'], $_POST['reason'])) {
    try {
        $attendance_id = $_POST['attendance_id'];
        $reason = $_POST['reason'];
        
        // Verify this attendance record belongs to the student
        $verify_query = "SELECT id FROM attendance WHERE id = ? AND student_id = ?";
        $stmt = $conn->prepare($verify_query);
        $stmt->execute([$attendance_id, $student['id']]);
        
        if ($stmt->fetch()) {
            // Update the attendance record with the reason
            $update_query = "UPDATE attendance SET absence_reason = ? WHERE id = ?";
            $stmt = $conn->prepare($update_query);
            $stmt->execute([$reason, $attendance_id]);
            
            // Send notification to the teacher
            notifyAttendanceResponse(
                $attendance_id, 
                $reason,
                $conn
            );
            
            $_SESSION['success_message'] = "Your absence explanation has been submitted successfully.";
        } else {
            $_SESSION['error_message'] = "Invalid attendance record.";
        }
    } catch (PDOException $e) {
        $_SESSION['error_message'] = "Error submitting explanation: " . $e->getMessage();
    }
}

// Get student's class
$class_query = "SELECT c.* FROM classes c 
                WHERE c.id = ?";
$stmt = $conn->prepare($class_query);
$stmt->execute([$student['class_id']]);
$class = $stmt->fetch(PDO::FETCH_ASSOC);

// Get attendance records
$attendance_query = "SELECT a.* FROM attendance a 
                    WHERE a.student_id = ? 
                    ORDER BY a.date DESC";
$stmt = $conn->prepare($attendance_query);
$stmt->execute([$student['id']]);
$attendance_records = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all classes for the student's school
$classes_query = "SELECT c.* FROM classes c 
                  JOIN students s ON c.id = s.class_id 
                  WHERE s.user_id = ? 
                  ORDER BY c.class_name";
$stmt = $conn->prepare($classes_query);
$stmt->execute([$student_id]);
$classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get attendance records for selected class or default to first class
$selected_class_id = isset($_GET['class_id']) ? $_GET['class_id'] : ($class['id'] ?? null);
$selected_month = isset($_GET['month']) ? $_GET['month'] : date('m');
$selected_year = isset($_GET['year']) ? $_GET['year'] : date('Y');

$attendance_summary = [
    'present' => 0,
    'absent' => 0,
    'late' => 0,
    'total_days' => 0
];

if ($selected_class_id) {
    // Get attendance records for the selected month
    $attendance_query = "SELECT date, status FROM attendance 
                        WHERE student_id = ? AND class_id = ? 
                        AND MONTH(date) = ? AND YEAR(date) = ?
                        ORDER BY date DESC";
    $stmt = $conn->prepare($attendance_query);
    $stmt->execute([$student['id'], $selected_class_id, $selected_month, $selected_year]);
    $attendance_records = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Calculate attendance summary
    foreach ($attendance_records as $record) {
        $attendance_summary[$record['status']]++;
        $attendance_summary['total_days']++;
    }
}

// Get class name
$selected_class_name = '';
if ($selected_class_id) {
    $class_query = "SELECT class_name FROM classes WHERE id = ?";
    $stmt = $conn->prepare($class_query);
    $stmt->execute([$selected_class_id]);
    $selected_class_name = $stmt->fetchColumn();
}
?>

<div class="container mx-auto px-4 py-6">
    <div class="bg-white rounded-lg shadow-lg p-6">
        <h2 class="text-2xl font-bold mb-6">My Attendance</h2>
        
        <!-- Filters -->
        <form method="GET" class="mb-8 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Select Class</label>
                <select name="class_id" class="form-select w-full rounded-md border-gray-300">
                    <?php foreach ($classes as $class): ?>
                        <option value="<?php echo $class['id']; ?>" 
                                <?php echo $selected_class_id == $class['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($class['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Month</label>
                <select name="month" class="form-select w-full rounded-md border-gray-300">
                    <?php for ($i = 1; $i <= 12; $i++): ?>
                        <option value="<?php echo sprintf('%02d', $i); ?>" 
                                <?php echo $selected_month == sprintf('%02d', $i) ? 'selected' : ''; ?>>
                            <?php echo date('F', mktime(0, 0, 0, $i, 1)); ?>
                        </option>
                    <?php endfor; ?>
                </select>
            </div>
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Year</label>
                <select name="year" class="form-select w-full rounded-md border-gray-300">
                    <?php for ($i = date('Y'); $i >= date('Y') - 2; $i--): ?>
                        <option value="<?php echo $i; ?>" 
                                <?php echo $selected_year == $i ? 'selected' : ''; ?>>
                            <?php echo $i; ?>
                        </option>
                    <?php endfor; ?>
                </select>
            </div>
            
            <div class="flex items-end">
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
                    Filter
                </button>
            </div>
        </form>
        
        <?php if ($selected_class_id): ?>
            <!-- Attendance Summary -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                <div class="bg-green-50 rounded-lg p-4 border border-green-200">
                    <h4 class="text-green-800 font-medium">Present</h4>
                    <p class="text-2xl font-bold text-green-600">
                        <?php echo $attendance_summary['present']; ?>
                        <span class="text-sm font-normal text-green-700">
                            (<?php echo $attendance_summary['total_days'] ? round(($attendance_summary['present'] / $attendance_summary['total_days']) * 100) : 0; ?>%)
                        </span>
                    </p>
                </div>
                
                <div class="bg-red-50 rounded-lg p-4 border border-red-200">
                    <h4 class="text-red-800 font-medium">Absent</h4>
                    <p class="text-2xl font-bold text-red-600">
                        <?php echo $attendance_summary['absent']; ?>
                        <span class="text-sm font-normal text-red-700">
                            (<?php echo $attendance_summary['total_days'] ? round(($attendance_summary['absent'] / $attendance_summary['total_days']) * 100) : 0; ?>%)
                        </span>
                    </p>
                </div>
                
                <div class="bg-yellow-50 rounded-lg p-4 border border-yellow-200">
                    <h4 class="text-yellow-800 font-medium">Late</h4>
                    <p class="text-2xl font-bold text-yellow-600">
                        <?php echo $attendance_summary['late']; ?>
                        <span class="text-sm font-normal text-yellow-700">
                            (<?php echo $attendance_summary['total_days'] ? round(($attendance_summary['late'] / $attendance_summary['total_days']) * 100) : 0; ?>%)
                        </span>
                    </p>
                </div>
                
                <div class="bg-blue-50 rounded-lg p-4 border border-blue-200">
                    <h4 class="text-blue-800 font-medium">Total Days</h4>
                    <p class="text-2xl font-bold text-blue-600">
                        <?php echo $attendance_summary['total_days']; ?>
                    </p>
                </div>
            </div>
            
            <!-- Attendance Records -->
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Date
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Status
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php if (empty($attendance_records)): ?>
                            <tr>
                                <td colspan="2" class="px-6 py-4 text-center text-gray-500">
                                    No attendance records found for this period
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($attendance_records as $record): ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php echo date('F j, Y', strtotime($record['date'])); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                            <?php
                                            switch ($record['status']) {
                                                case 'present':
                                                    echo 'bg-green-100 text-green-800';
                                                    break;
                                                case 'absent':
                                                    echo 'bg-red-100 text-red-800';
                                                    break;
                                                case 'late':
                                                    echo 'bg-yellow-100 text-yellow-800';
                                                    break;
                                            }
                                            ?>">
                                            <?php echo ucfirst($record['status']); ?>
                                        </span>
                                        
                                        <?php if ($record['status'] === 'absent' && empty($record['absence_reason'])): ?>
                                            <button type="button" 
                                                onclick="showAbsenceModal(<?php echo $record['id']; ?>, '<?php echo date('F j, Y', strtotime($record['date'])); ?>')" 
                                                class="ml-2 text-xs text-red-600 hover:text-red-800">
                                                Explain absence
                                            </button>
                                        <?php elseif (!empty($record['absence_reason'])): ?>
                                            <span class="ml-2 text-xs text-gray-500">
                                                <i class="fas fa-check"></i> Explanation provided
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="text-center text-gray-500">
                No classes found
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Absence Explanation Modal -->
<div id="absenceModal" class="fixed inset-0 flex items-center justify-center z-50 hidden">
    <div class="fixed inset-0 bg-black opacity-50" onclick="closeAbsenceModal()"></div>
    <div class="bg-white rounded-lg p-6 w-full max-w-md relative z-10">
        <h3 class="text-lg font-medium text-gray-900 mb-4">Explain Absence</h3>
        <p class="text-sm text-gray-500 mb-4" id="absenceDate"></p>
        
        <form method="POST" action="">
            <input type="hidden" id="attendanceIdInput" name="attendance_id" value="">
            
            <div class="mb-4">
                <label for="reason" class="block text-sm font-medium text-gray-700 mb-2">Reason for absence</label>
                <textarea name="reason" id="reason" rows="4" class="w-full border-gray-300 rounded-md" required></textarea>
            </div>
            
            <div class="flex justify-end">
                <button type="button" onclick="closeAbsenceModal()" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-md mr-2">
                    Cancel
                </button>
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-md">
                    Submit
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function showAbsenceModal(attendanceId, date) {
        document.getElementById('attendanceIdInput').value = attendanceId;
        document.getElementById('absenceDate').textContent = 'Date: ' + date;
        document.getElementById('absenceModal').classList.remove('hidden');
    }
    
    function closeAbsenceModal() {
        document.getElementById('absenceModal').classList.add('hidden');
    }
</script>

<?php require_once '../../components/footer.php'; ?> 