<?php
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('Location: /Mark4/src/pages/login.php');
    exit();
}

// Get database connection
$db = new Database();
$conn = $db->getConnection();

// Enable for debugging
$debug_mode = isset($_GET['debug']);

// Get student information
$student_id = $_SESSION['user_id'];
try {
    $stmt = $conn->prepare("SELECT s.id, s.school_id, s.class_id, u.username as name, c.class_name, sc.name as school_name 
                         FROM students s
                         LEFT JOIN classes c ON s.class_id = c.id
                         LEFT JOIN schools sc ON s.school_id = sc.id
                         LEFT JOIN users u ON s.user_id = u.id
                         WHERE s.user_id = ?");
    $stmt->execute([$student_id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
        throw new Exception("Student information not found for user ID: $student_id");
    }
} catch (Exception $e) {
    $error_message = "Error retrieving student information: " . $e->getMessage();
    if ($debug_mode) {
        $error_message .= "<br>Error details: " . print_r($e, true);
    }
    echo "<div class='container mx-auto px-4 py-8'><div class='bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4'>$error_message</div></div>";
    require_once '../../components/footer.php';
    exit();
}

// Fetch all exams from the database
try {
    // Verify student has a valid school_id
    if (empty($student['school_id'])) {
        throw new Exception("Student doesn't have an assigned school (school_id is empty)");
    }
    
    // First get total number of exams in database (for debugging)
    $stmt = $conn->query("SELECT COUNT(*) FROM exams");
    $exam_count = $stmt->fetchColumn();
    
    if ($debug_mode) {
        // Check database schema if in debug mode
        $stmt = $conn->query("DESCRIBE exams");
        $exam_table_schema = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Get all exams for the student's school
    $stmt = $conn->prepare("SELECT e.* 
          FROM exams e 
                           WHERE e.school_id = ?
                           ORDER BY e.start_date DESC");
    $stmt->execute([$student['school_id']]);
    $exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Add subject information if possible
    if (!empty($exams)) {
        try {
            // Check if exam_subjects table exists
            $tableCheck = $conn->query("SHOW TABLES LIKE 'exam_subjects'");
            if ($tableCheck->rowCount() > 0) {
                foreach ($exams as $key => $exam) {
                    // Try to get subject information through exam_subjects table
                    $subjectStmt = $conn->prepare("
                        SELECT s.name as subject_name 
                        FROM exam_subjects es
          JOIN subjects s ON es.subject_id = s.id 
                        WHERE es.exam_id = ?
                        LIMIT 1
                    ");
                    $subjectStmt->execute([$exam['id']]);
                    $subject = $subjectStmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($subject) {
                        $exams[$key]['subject_name'] = $subject['subject_name'];
                    } else {
                        $exams[$key]['subject_name'] = 'General';
                    }
                }
            } else {
                // No exam_subjects table, set default subject name
                foreach ($exams as $key => $exam) {
                    $exams[$key]['subject_name'] = 'General';
                }
            }
        } catch (PDOException $ex) {
            // If we can't get subject information, just set default
            foreach ($exams as $key => $exam) {
                $exams[$key]['subject_name'] = 'General';
            }
            if ($debug_mode) {
                echo "<div class='bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-4'>
                        Warning: Could not fetch subject information: " . $ex->getMessage() . "
                      </div>";
            }
        }
    }
    
    if (empty($exams)) {
        // Try a direct query to see if there are any exams at all
        $stmt = $conn->query("SELECT * FROM exams LIMIT 5");
        $all_exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (empty($all_exams) && $debug_mode) {
            echo "<div class='bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-4'>
                    No exams found in the database. Please add some exams first.
                  </div>";
        } elseif (!empty($all_exams) && $debug_mode) {
            echo "<div class='bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-4'>
                    Exams exist in the database, but none are assigned to school ID {$student['school_id']}.
                  </div>";
        }
    }
} catch (PDOException $e) {
    $error = "Database error while fetching exams: " . $e->getMessage();
    if ($debug_mode) {
        $error .= "<br>Error details: " . print_r($e, true);
    }
    $exams = [];
} catch (Exception $e) {
    $error = $e->getMessage();
    $exams = [];
}

// Categorize exams
$today = date('Y-m-d');
$past_exams = [];
$ongoing_exams = [];
$upcoming_exams = [];

foreach ($exams as $exam) {
    $start_date = $exam['start_date'];
    $end_date = !empty($exam['end_date']) ? $exam['end_date'] : $start_date;
    
    if ($end_date < $today) {
        $past_exams[] = $exam;
    } elseif ($start_date <= $today && $end_date >= $today) {
        $ongoing_exams[] = $exam;
    } else {
        $upcoming_exams[] = $exam;
    }
}
?>

<div class="container mx-auto px-4 py-6">
    <div class="mb-6 flex justify-between items-center">
        <h1 class="text-2xl font-bold text-gray-800">My Exams</h1>
        <div class="text-sm text-gray-600">
            Student: <?php echo htmlspecialchars($student['name']); ?> | 
            Class: <?php echo htmlspecialchars($student['class_name'] ?? 'Not Assigned'); ?>
        </div>
    </div>
    
    <?php if (isset($error)): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4">
            <?php echo $error; ?>
        </div>
    <?php endif; ?>
    
    <!-- Debug info -->
    <?php if ($debug_mode): ?>
        <div class="bg-gray-100 border border-gray-300 p-4 mb-4 rounded">
            <h3 class="font-bold text-lg mb-2">Debug Information</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <h4 class="font-semibold">Student Information:</h4>
                    <ul class="list-disc pl-5">
                        <li>User ID: <?php echo $student_id; ?></li>
                        <li>Student ID: <?php echo $student['id']; ?></li>
                        <li>Name: <?php echo htmlspecialchars($student['name']); ?></li>
                        <li>School ID: <?php echo $student['school_id']; ?></li>
                        <li>Class ID: <?php echo $student['class_id']; ?></li>
                        <li>Class: <?php echo htmlspecialchars($student['class_name'] ?? 'Not Assigned'); ?></li>
                        <li>School: <?php echo htmlspecialchars($student['school_name']); ?></li>
                    </ul>
                </div>
                <div>
                    <h4 class="font-semibold">Exams Information:</h4>
                    <ul class="list-disc pl-5">
                        <li>Total exams in database: <?php echo $exam_count; ?></li>
                        <li>Exams found for this school: <?php echo count($exams); ?></li>
                        <li>Upcoming exams: <?php echo count($upcoming_exams); ?></li>
                        <li>Ongoing exams: <?php echo count($ongoing_exams); ?></li>
                        <li>Past exams: <?php echo count($past_exams); ?></li>
                    </ul>
                </div>
            </div>
            
            <?php if (isset($exam_table_schema) && !empty($exam_table_schema)): ?>
                <div class="mt-4">
                    <h4 class="font-semibold">Exams Table Schema:</h4>
                <div class="overflow-x-auto">
                        <table class="min-w-full bg-white border border-gray-300 mt-2">
                            <thead>
                                <tr>
                                    <th class="py-2 px-4 border-b">Field</th>
                                    <th class="py-2 px-4 border-b">Type</th>
                                    <th class="py-2 px-4 border-b">Null</th>
                                    <th class="py-2 px-4 border-b">Key</th>
                                    <th class="py-2 px-4 border-b">Default</th>
                                    <th class="py-2 px-4 border-b">Extra</th>
                            </tr>
                        </thead>
                            <tbody>
                                <?php 
                                $has_subject_id = false;
                                foreach ($exam_table_schema as $column): 
                                    if ($column['Field'] === 'subject_id') {
                                        $has_subject_id = true;
                                    }
                                ?>
                                    <tr>
                                        <td class="py-2 px-4 border-b"><?php echo $column['Field']; ?></td>
                                        <td class="py-2 px-4 border-b"><?php echo $column['Type']; ?></td>
                                        <td class="py-2 px-4 border-b"><?php echo $column['Null']; ?></td>
                                        <td class="py-2 px-4 border-b"><?php echo $column['Key']; ?></td>
                                        <td class="py-2 px-4 border-b"><?php echo $column['Default'] ?? 'NULL'; ?></td>
                                        <td class="py-2 px-4 border-b"><?php echo $column['Extra']; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <div class="mt-2 p-2 <?php echo $has_subject_id ? 'bg-green-100' : 'bg-red-100'; ?> rounded">
                            <p class="text-sm">
                                <?php echo $has_subject_id ? 
                                    'The exams table has a subject_id column.' : 
                                    'The exams table does not have a subject_id column. This is why we\'re using a different approach to get subject information.'; ?>
                            </p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if (isset($all_exams) && !empty($all_exams)): ?>
                <div class="mt-4">
                    <h4 class="font-semibold">Sample exams from database:</h4>
                    <div class="overflow-x-auto">
                        <table class="min-w-full bg-white border border-gray-300 mt-2">
                            <thead>
                                <tr>
                                    <th class="py-2 px-4 border-b">ID</th>
                                    <th class="py-2 px-4 border-b">Name</th>
                                    <th class="py-2 px-4 border-b">School ID</th>
                                    <th class="py-2 px-4 border-b">Start Date</th>
                                    <th class="py-2 px-4 border-b">End Date</th>
                                    <th class="py-2 px-4 border-b">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($all_exams as $ex): ?>
                                    <tr>
                                        <td class="py-2 px-4 border-b"><?php echo $ex['id']; ?></td>
                                        <td class="py-2 px-4 border-b"><?php echo htmlspecialchars($ex['name']); ?></td>
                                        <td class="py-2 px-4 border-b"><?php echo $ex['school_id']; ?></td>
                                        <td class="py-2 px-4 border-b"><?php echo $ex['start_date']; ?></td>
                                        <td class="py-2 px-4 border-b"><?php echo $ex['end_date'] ?? 'N/A'; ?></td>
                                        <td class="py-2 px-4 border-b"><?php echo $ex['status'] ?? 'N/A'; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                                        </div>
                                        </div>
            <?php elseif (count($exams) > 0): ?>
                <div class="mt-4">
                    <h4 class="font-semibold">First 3 exams found for this school:</h4>
                    <div class="overflow-x-auto">
                        <table class="min-w-full bg-white border border-gray-300 mt-2">
                            <thead>
                                <tr>
                                    <th class="py-2 px-4 border-b">ID</th>
                                    <th class="py-2 px-4 border-b">Name</th>
                                    <th class="py-2 px-4 border-b">School ID</th>
                                    <th class="py-2 px-4 border-b">Start Date</th>
                                    <th class="py-2 px-4 border-b">End Date</th>
                                    <th class="py-2 px-4 border-b">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach (array_slice($exams, 0, 3) as $ex): ?>
                                    <tr>
                                        <td class="py-2 px-4 border-b"><?php echo $ex['id']; ?></td>
                                        <td class="py-2 px-4 border-b"><?php echo htmlspecialchars($ex['name']); ?></td>
                                        <td class="py-2 px-4 border-b"><?php echo $ex['school_id']; ?></td>
                                        <td class="py-2 px-4 border-b"><?php echo $ex['start_date']; ?></td>
                                        <td class="py-2 px-4 border-b"><?php echo $ex['end_date'] ?? 'N/A'; ?></td>
                                        <td class="py-2 px-4 border-b"><?php echo $ex['status'] ?? 'N/A'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
            
            <div class="mt-4">
                <button onclick="window.location.href='exams.php'" class="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600">
                    Hide Debug Info
                </button>
            </div>
        </div>
    <?php endif; ?>
    
    <!-- Tabs -->
    <div class="mb-6">
        <div class="border-b border-gray-200">
            <nav class="-mb-px flex space-x-8">
                <a href="#" onclick="showTab('upcoming')" id="tab-upcoming" class="border-blue-500 text-blue-600 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                    Upcoming
                    <span class="ml-2 py-0.5 px-2.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        <?php echo count($upcoming_exams); ?>
                    </span>
                </a>
                <a href="#" onclick="showTab('ongoing')" id="tab-ongoing" class="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                    Ongoing
                    <span class="ml-2 py-0.5 px-2.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        <?php echo count($ongoing_exams); ?>
                    </span>
                </a>
                <a href="#" onclick="showTab('past')" id="tab-past" class="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                    Past
                    <span class="ml-2 py-0.5 px-2.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                        <?php echo count($past_exams); ?>
                    </span>
                </a>
            </nav>
        </div>
    </div>
    
    <!-- Upcoming Exams -->
    <div id="content-upcoming" class="tab-content">
        <?php if (empty($upcoming_exams)): ?>
            <div class="bg-white rounded-lg shadow p-6 text-center">
                <p class="text-gray-500">No upcoming exams scheduled.</p>
            </div>
        <?php else: ?>
            <div class="bg-white shadow overflow-hidden sm:rounded-md">
                <ul class="divide-y divide-gray-200">
                    <?php foreach ($upcoming_exams as $exam): ?>
                        <li>
                            <div class="px-4 py-4 sm:px-6">
                                <div class="flex items-center justify-between">
                                    <h3 class="text-lg leading-6 font-medium text-gray-900">
                                        <?php echo htmlspecialchars($exam['name']); ?>
                                    </h3>
                                    <div class="ml-2 flex-shrink-0 flex">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                            Upcoming
                                        </span>
                                    </div>
                                </div>
                                <div class="mt-2 sm:flex sm:justify-between">
                                    <div class="sm:flex">
                                        <p class="flex items-center text-sm text-gray-500">
                                            <svg class="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                                                <path fill-rule="evenodd" d="M10 2a8 8 0 100 16A8 8 0 100 10 8 8 0 010 10a8 8 0 1012 0A8 8 0 0010 2zM4.59 4.59A8 8 0 0110 2a8 8 0 16-6.41 13.41A8 8 0 014.59 4.59z" clip-rule="evenodd" />
                                            </svg>
                                            <?php echo htmlspecialchars($exam['subject_name'] ?? 'General'); ?>
                                        </p>
                                        </div>
                                    <div class="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
                                        <svg class="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                            <path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd" />
                                        </svg>
                                        <p>
                                            From <?php echo date('M d, Y', strtotime($exam['start_date'])); ?>
                                            <?php if (!empty($exam['end_date']) && $exam['end_date'] != $exam['start_date']): ?>
                                                to <?php echo date('M d, Y', strtotime($exam['end_date'])); ?>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Ongoing Exams -->
    <div id="content-ongoing" class="tab-content hidden">
        <?php if (empty($ongoing_exams)): ?>
            <div class="bg-white rounded-lg shadow p-6 text-center">
                <p class="text-gray-500">No ongoing exams.</p>
                                        </div>
        <?php else: ?>
            <div class="bg-white shadow overflow-hidden sm:rounded-md">
                <ul class="divide-y divide-gray-200">
                    <?php foreach ($ongoing_exams as $exam): ?>
                        <li>
                            <div class="px-4 py-4 sm:px-6">
                                <div class="flex items-center justify-between">
                                    <h3 class="text-lg leading-6 font-medium text-gray-900">
                                        <?php echo htmlspecialchars($exam['name']); ?>
                                    </h3>
                                    <div class="ml-2 flex-shrink-0 flex">
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                            Ongoing
                                                </span>
                                    </div>
                                </div>
                                <div class="mt-2 sm:flex sm:justify-between">
                                    <div class="sm:flex">
                                        <p class="flex items-center text-sm text-gray-500">
                                            <svg class="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                                                <path fill-rule="evenodd" d="M10 2a8 8 0 100 16A8 8 0 100 10 8 8 0 010 10a8 8 0 1012 0A8 8 0 0010 2zM4.59 4.59A8 8 0 0110 2a8 8 0 16-6.41 13.41A8 8 0 014.59 4.59z" clip-rule="evenodd" />
                                            </svg>
                                            <?php echo htmlspecialchars($exam['subject_name'] ?? 'General'); ?>
                                        </p>
                                    </div>
                                    <div class="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
                                        <svg class="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                            <path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd" />
                                        </svg>
                                        <p>
                                            From <?php echo date('M d, Y', strtotime($exam['start_date'])); ?>
                                            <?php if (!empty($exam['end_date']) && $exam['end_date'] != $exam['start_date']): ?>
                                                to <?php echo date('M d, Y', strtotime($exam['end_date'])); ?>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Past Exams -->
    <div id="content-past" class="tab-content hidden">
        <?php if (empty($past_exams)): ?>
            <div class="bg-white rounded-lg shadow p-6 text-center">
                <p class="text-gray-500">No past exams.</p>
            </div>
                                        <?php else: ?>
            <div class="bg-white shadow overflow-hidden sm:rounded-md">
                <ul class="divide-y divide-gray-200">
                    <?php foreach ($past_exams as $exam): ?>
                        <li>
                            <div class="px-4 py-4 sm:px-6">
                                <div class="flex items-center justify-between">
                                    <h3 class="text-lg leading-6 font-medium text-gray-900">
                                        <?php echo htmlspecialchars($exam['name']); ?>
                                    </h3>
                                    <div class="ml-2 flex-shrink-0 flex">
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                                            Past
                                            </span>
                                    </div>
                                </div>
                                <div class="mt-2 sm:flex sm:justify-between">
                                    <div class="sm:flex">
                                        <p class="flex items-center text-sm text-gray-500">
                                            <svg class="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                                                <path fill-rule="evenodd" d="M10 2a8 8 0 100 16A8 8 0 100 10 8 8 0 010 10a8 8 0 1012 0A8 8 0 0010 2zM4.59 4.59A8 8 0 0110 2a8 8 0 16-6.41 13.41A8 8 0 014.59 4.59z" clip-rule="evenodd" />
                                            </svg>
                                            <?php echo htmlspecialchars($exam['subject_name'] ?? 'General'); ?>
                                        </p>
                                    </div>
                                    <div class="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
                                        <svg class="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                            <path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd" />
                                        </svg>
                                        <p>
                                            From <?php echo date('M d, Y', strtotime($exam['start_date'])); ?>
                                            <?php if (!empty($exam['end_date']) && $exam['end_date'] != $exam['start_date']): ?>
                                                to <?php echo date('M d, Y', strtotime($exam['end_date'])); ?>
                                        <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </li>
                            <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>

    <!-- Footer Action -->
    <?php if (!$debug_mode): ?>
    <div class="mt-8 text-center">
        <a href="?debug=1" class="text-xs text-gray-500 hover:text-gray-700">
            <i class="fas fa-bug mr-1"></i> Enable Debug Mode
        </a>
    </div>
    <?php endif; ?>
</div>

<script>
function showTab(tab) {
    // Hide all tab contents
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.add('hidden');
    });
    
    // Remove active class from all tabs
    document.querySelectorAll('nav a').forEach(link => {
        link.classList.remove('border-blue-500', 'text-blue-600');
        link.classList.add('border-transparent', 'text-gray-500', 'hover:text-gray-700', 'hover:border-gray-300');
    });
    
    // Show the selected tab content
    document.getElementById('content-' + tab).classList.remove('hidden');
    
    // Add active class to the selected tab
    const tabElement = document.getElementById('tab-' + tab);
    tabElement.classList.remove('border-transparent', 'text-gray-500', 'hover:text-gray-700', 'hover:border-gray-300');
    tabElement.classList.add('border-blue-500', 'text-blue-600');
}
</script>

<?php require_once '../../components/footer.php'; ?> 