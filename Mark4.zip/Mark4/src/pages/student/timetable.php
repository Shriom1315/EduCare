<?php
ob_start();
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is student
if ($_SESSION['role'] !== 'student') {
    header('Location: /src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get student information
$query = "SELECT s.*, c.id as class_id, c.class_name 
          FROM students s 
          JOIN classes c ON s.class_id = c.id 
          WHERE s.user_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    header('Location: /src/pages/login.php');
    exit();
}

// Fetch timetable entries for the student's class
try {
    $query = "SELECT t.*, s.name as subject_name, u.username as teacher_name 
              FROM timetables t 
              JOIN subjects s ON t.subject_id = s.id 
              JOIN users u ON t.teacher_id = u.id 
              WHERE t.class_id = :class_id 
              ORDER BY t.day_of_week, t.start_time";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':class_id', $student['class_id']);
    $stmt->execute();
    $timetable_entries = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $timetable_entries = [];
    $_SESSION['error_message'] = "Error loading timetable entries: " . $e->getMessage();
}

// Group timetable entries by day
$timetable_by_day = [];
foreach ($timetable_entries as $entry) {
    if (!isset($timetable_by_day[$entry['day_of_week']])) {
        $timetable_by_day[$entry['day_of_week']] = [];
    }
    $timetable_by_day[$entry['day_of_week']][] = $entry;
}

// Check if the file exists and make necessary changes if it does

?>

<!-- Page Content -->
<div class="container mx-auto px-4 py-6">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Class Timetable</h1>
        <div class="text-gray-600">
            Class: <?php echo htmlspecialchars($student['class_name']); ?>
        </div>
    </div>
    
    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
            <p><?php echo $_SESSION['error_message']; ?></p>
        </div>
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>
    
    <!-- Timetable Display -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Time</th>
                        <?php
                        $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                        foreach ($days as $day):
                        ?>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo $day; ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php
                    $time_slots = [];
                    foreach ($timetable_entries as $entry) {
                        $time_slots[$entry['start_time']] = true;
                    }
                    ksort($time_slots);
                    
                    foreach ($time_slots as $time => $dummy):
                        $start_time = date('h:i A', strtotime($time));
                        $end_time = date('h:i A', strtotime($time) + 3600); // Assuming 1-hour slots
                    ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <?php echo $start_time . ' - ' . $end_time; ?>
                            </td>
                            <?php foreach ($days as $day): ?>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php
                                    if (isset($timetable_by_day[$day])) {
                                        foreach ($timetable_by_day[$day] as $entry) {
                                            if ($entry['start_time'] === $time) {
                                                echo '<div class="text-sm">';
                                                echo '<div class="font-medium text-gray-900">' . htmlspecialchars($entry['subject_name']) . '</div>';
                                                echo '<div class="text-gray-500">' . htmlspecialchars($entry['teacher_name']) . '</div>';
                                                echo '</div>';
                                            }
                                        }
                                    }
                                    ?>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../../components/footer.php'; ?>

<?php ob_end_flush(); ?> 