<?php
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is student
if ($_SESSION['role'] !== 'student') {
    header('Location: /src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get student information
$student_id = $_SESSION['user_id'];
$query = "SELECT s.*, c.class_name, sc.name as school_name, u.username 
          FROM students s 
          LEFT JOIN classes c ON s.class_id = c.id 
          LEFT JOIN schools sc ON s.school_id = sc.id 
          LEFT JOIN users u ON s.user_id = u.id 
          WHERE s.user_id = :student_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':student_id', $student_id);
$stmt->execute();
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    header('Location: /src/pages/login.php');
    exit();
}

// Get upcoming exams
try {
    // Use school_id instead of class_id since exams table doesn't have class_id
    $query = "SELECT e.id, e.name, e.start_date, e.end_date, e.status
              FROM exams e
              WHERE e.school_id = :school_id 
              ORDER BY e.start_date ASC";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':school_id', $student['school_id']);
    $stmt->execute();
    $all_exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // If no exams found, try with a join to exam_subjects
    if (empty($all_exams)) {
        try {
            $query = "SELECT DISTINCT e.id, e.name, e.start_date, e.end_date, e.status
                     FROM exams e
                     LEFT JOIN exam_subjects es ON e.id = es.exam_id
                     WHERE e.school_id = :school_id
                     ORDER BY e.start_date ASC";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':school_id', $student['school_id']);
            $stmt->execute();
            $all_exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $ex) {
            error_log("Error fetching exams with join: " . $ex->getMessage());
            $all_exams = [];
        }
    }
    
    // Categorize exams
    $past_exams = [];
    $ongoing_exams = [];
    $upcoming_exams = [];
    $today = date('Y-m-d');
    
    foreach ($all_exams as $exam) {
        $start_date = $exam['start_date'];
        $end_date = isset($exam['end_date']) ? $exam['end_date'] : $start_date;
        
        if ($end_date < $today) {
            $past_exams[] = $exam;
        } elseif ($start_date <= $today && $end_date >= $today) {
            $ongoing_exams[] = $exam;
        } else {
            $upcoming_exams[] = $exam;
        }
    }
    
    // Sort upcoming exams by start date (earliest first)
    usort($upcoming_exams, function($a, $b) {
        return strtotime($a['start_date']) - strtotime($b['start_date']);
    });
    
    // Only keep the first 5 for display
    $upcoming_exams_display = array_slice($upcoming_exams, 0, 5);
    
} catch (PDOException $e) {
    error_log("Error fetching upcoming exams: " . $e->getMessage());
    $all_exams = [];
    $past_exams = [];
    $ongoing_exams = [];
    $upcoming_exams = [];
    $upcoming_exams_display = [];
}

// Get recent notices relevant to students
$query = "SELECT n.*, u.username as created_by_name 
          FROM notices n 
          JOIN users u ON n.created_by = u.id 
          WHERE n.school_id = :school_id 
          AND (n.target_audience = 'all' OR n.target_audience = 'students') 
          ORDER BY n.created_at DESC LIMIT 5";
$stmt = $db->prepare($query);
$stmt->bindParam(':school_id', $student['school_id']);
$stmt->execute();
$recent_notices = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get recent attendance records
$query = "SELECT a.*, c.class_name 
          FROM attendance a 
          JOIN classes c ON a.class_id = c.id 
          WHERE a.student_id = :student_id 
          ORDER BY a.date DESC LIMIT 10";
$stmt = $db->prepare($query);
$stmt->bindParam(':student_id', $student['id']);
$stmt->execute();
$attendance_records = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate attendance percentage
$present_count = 0;
foreach ($attendance_records as $record) {
    if ($record['status'] === 'present') {
        $present_count++;
    }
}
$attendance_percentage = count($attendance_records) > 0 
    ? round(($present_count / count($attendance_records)) * 100) 
    : 0;

// Get assignments for the student's class
try {
    // First check if the assignments table exists
    $check_table = "SHOW TABLES LIKE 'assignments'";
    $table_exists = $db->query($check_table)->rowCount() > 0;
    
    if ($table_exists) {
        $query = "SELECT a.*, u.username as teacher_name 
                  FROM assignments a 
                  JOIN users u ON a.teacher_id = u.id 
                  WHERE a.class_id = :class_id 
                  AND a.due_date >= CURDATE() 
                  ORDER BY a.due_date ASC LIMIT 5";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':class_id', $student['class_id']);
        $stmt->execute();
        $assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $assignments = [];
    }
} catch (PDOException $e) {
    // If there's an error, set empty array for assignments
    $assignments = [];
}
?>

<div class="container mx-auto px-4 py-6">
    <!-- Welcome Section -->
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-800">Welcome, <?php echo htmlspecialchars($student['username']); ?>!</h1>
        <p class="text-gray-600">
            Student at <?php echo htmlspecialchars($student['school_name']); ?> 
            | Class: <?php echo htmlspecialchars($student['class_name'] ?? 'Not Assigned'); ?>
        </p>
        <div class="mt-2 flex flex-wrap">
            <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800 mr-2 mb-2">
                <i class="fas fa-id-card mr-1"></i> Roll #: <?php echo htmlspecialchars($student['roll_number']); ?>
            </span>
        </div>
    </div>

    <!-- Main Dashboard Content -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <!-- Attendance Card -->
        <div class="bg-white rounded-lg shadow p-6 flex items-center">
            <div class="mr-4 bg-blue-100 p-3 rounded-full">
                <i class="fas fa-calendar-check text-blue-500 text-2xl"></i>
            </div>
            <div>
                <h3 class="text-gray-500 text-sm font-semibold">Attendance</h3>
                <div class="text-2xl font-bold"><?php echo $attendance_percentage; ?>%</div>
            </div>
            <div class="ml-auto">
                <a href="attendance.php" class="text-blue-500 hover:underline text-sm">View</a>
            </div>
        </div>

        <!-- Upcoming Exams Card -->
        <div class="bg-white rounded-lg shadow p-6 flex items-center">
            <div class="mr-4 bg-red-100 p-3 rounded-full">
                <i class="fas fa-file-alt text-red-500 text-2xl"></i>
            </div>
            <div>
                <h3 class="text-gray-500 text-sm font-semibold">Exams</h3>
                <div class="text-2xl font-bold"><?php echo count($all_exams); ?></div>
                <?php if (!empty($upcoming_exams)): ?>
                    <div class="mt-1 text-sm text-gray-600">
                        Upcoming: <?php echo count($upcoming_exams); ?>
                    </div>
                <?php endif; ?>
            </div>
            <div class="ml-auto">
                <a href="exams.php" class="text-blue-500 hover:underline text-sm">View All</a>
            </div>
        </div>

        <!-- Pending Assignments Card -->
        <div class="bg-white rounded-lg shadow p-6 flex items-center">
            <div class="mr-4 bg-green-100 p-3 rounded-full">
                <i class="fas fa-tasks text-green-500 text-2xl"></i>
            </div>
            <div>
                <h3 class="text-gray-500 text-sm font-semibold">Pending Assignments</h3>
                <div class="text-2xl font-bold"><?php echo count($assignments); ?></div>
            </div>
            <div class="ml-auto">
                <a href="#" class="text-blue-500 hover:underline text-sm">View All</a>
            </div>
        </div>
    </div>

    <!-- Content Sections -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <!-- Recent Attendance Section -->
        <div>
            <div class="bg-white rounded-lg shadow-md overflow-hidden mb-6">
                <div class="border-b border-gray-200 bg-gray-50 px-6 py-3">
                    <h2 class="text-lg font-semibold text-gray-800">Recent Attendance</h2>
                </div>
                <div class="p-6">
                    <?php if (empty($attendance_records)): ?>
                        <p class="text-gray-500 text-center">No attendance records available.</p>
                    <?php else: ?>
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Class</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php foreach ($attendance_records as $record): ?>
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            <?php echo date('M d, Y', strtotime($record['date'])); ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            <?php echo htmlspecialchars($record['class_name']); ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <?php if ($record['status'] === 'present'): ?>
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                    Present
                                                </span>
                                            <?php elseif ($record['status'] === 'absent'): ?>
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                                    Absent
                                                </span>
                                            <?php elseif ($record['status'] === 'late'): ?>
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                                    Late
                                                </span>
                                            <?php else: ?>
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                                                    <?php echo ucfirst($record['status']); ?>
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Upcoming Exams Section -->
        <div>
            <div class="bg-white rounded-lg shadow-md overflow-hidden mb-6">
                <div class="border-b border-gray-200 bg-gray-50 px-6 py-3 flex justify-between items-center">
                    <h2 class="text-lg font-semibold text-gray-800">Upcoming Exams</h2>
                    <a href="exams.php" class="text-blue-600 hover:text-blue-800 text-sm font-medium">View All</a>
                </div>
                <div class="p-6">
                    <?php if (empty($upcoming_exams_display)): ?>
                        <p class="text-gray-500 text-center">No upcoming exams scheduled.</p>
                    <?php else: ?>
                        <ul class="divide-y divide-gray-200">
                            <?php foreach ($upcoming_exams_display as $exam): ?>
                                <li class="py-3">
                                    <div class="flex items-center">
                                        <div class="flex-1">
                                            <a href="exams.php" class="text-blue-600 hover:text-blue-800 font-medium">
                                                <?php echo htmlspecialchars($exam['name']); ?>
                                            </a>
                                            <p class="text-sm text-gray-600 mt-1">
                                                <i class="far fa-calendar-alt mr-1"></i>
                                                <?php echo date('M d, Y', strtotime($exam['start_date'])); ?>
                                            </p>
                                        </div>
                                        <span class="px-3 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                            Upcoming
                                        </span>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Pending Assignments Section -->
            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                <div class="border-b border-gray-200 bg-gray-50 px-6 py-3">
                    <h2 class="text-lg font-semibold text-gray-800">Pending Assignments</h2>
                </div>
                <div class="p-6">
                    <?php if (empty($assignments)): ?>
                        <p class="text-gray-500 text-center">No pending assignments.</p>
                    <?php else: ?>
                        <ul class="divide-y divide-gray-200">
                            <?php foreach ($assignments as $assignment): ?>
                                <li class="py-3">
                                    <div class="flex items-center">
                                        <div class="flex-1">
                                            <p class="font-medium text-gray-800"><?php echo htmlspecialchars($assignment['title']); ?></p>
                                            <p class="text-sm text-gray-600 mt-1">
                                                <i class="far fa-calendar-alt mr-1"></i>
                                                Due: <?php echo date('M d, Y', strtotime($assignment['due_date'])); ?>
                                            </p>
                                        </div>
                                        <span class="px-3 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                                            Due Soon
                                        </span>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Notices -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="border-b border-gray-200 bg-gray-50 px-6 py-3 flex justify-between items-center">
            <h2 class="text-lg font-semibold text-gray-800">Recent Notices</h2>
            <a href="notices.php" class="text-blue-600 hover:text-blue-800 text-sm font-medium">View All</a>
        </div>
        <div class="p-6">
            <?php if (empty($recent_notices)): ?>
                <p class="text-gray-500 text-center">No recent notices available.</p>
            <?php else: ?>
                <ul class="divide-y divide-gray-200">
                    <?php foreach ($recent_notices as $notice): ?>
                        <li class="py-4">
                            <div class="border-l-4 border-blue-500 pl-4">
                                <h3 class="font-semibold text-gray-800"><?php echo htmlspecialchars($notice['title']); ?></h3>
                                <p class="text-gray-700 mt-1"><?php echo htmlspecialchars($notice['content']); ?></p>
                                <div class="flex items-center mt-2 text-sm text-gray-500">
                                    <span class="mr-3">
                                        <i class="far fa-calendar-alt mr-1"></i>
                                        <?php echo date('M d, Y', strtotime($notice['created_at'])); ?>
                                    </span>
                                    <span>
                                        <i class="fas fa-user mr-1"></i>
                                        <?php echo htmlspecialchars($notice['created_by_name']); ?>
                                    </span>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Links -->
    <div class="mt-8">
        <h2 class="text-xl font-semibold text-gray-800 mb-4">Quick Links</h2>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
            <a href="timetable.php" class="flex items-center p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors duration-200">
                <i class="fas fa-calendar-alt text-blue-600 text-xl mr-3"></i>
                <span class="text-gray-700">Timetable</span>
            </a>
            <a href="assignments.php" class="flex items-center p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors duration-200">
                <i class="fas fa-tasks text-green-600 text-xl mr-3"></i>
                <span class="text-gray-700">Assignments</span>
            </a>
            <a href="exams.php" class="flex items-center p-4 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors duration-200">
                <i class="fas fa-file-alt text-purple-600 text-xl mr-3"></i>
                <span class="text-gray-700">Exams</span>
            </a>
            <a href="profile.php" class="flex items-center p-4 bg-yellow-50 rounded-lg hover:bg-yellow-100 transition-colors duration-200">
                <i class="fas fa-user text-yellow-600 text-xl mr-3"></i>
                <span class="text-gray-700">My Profile</span>
            </a>
        </div>
    </div>
</div>

<?php require_once '../../components/footer.php'; ?> 