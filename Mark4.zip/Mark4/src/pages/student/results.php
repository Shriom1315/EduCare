<?php
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('Location: /src/pages/login.php');
    exit();
}

$db = new Database();
$conn = $db->getConnection();
$student_id = $_SESSION['user_id'];

// Get student's classes
$classes_query = "SELECT c.* FROM classes c 
                 INNER JOIN students s ON c.id = s.class_id 
                 WHERE s.user_id = ?";
$stmt = $conn->prepare($classes_query);
$stmt->execute([$student_id]);
$classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get results for selected class or default to first class
$selected_class_id = isset($_GET['class_id']) ? $_GET['class_id'] : ($classes[0]['id'] ?? null);
$selected_exam_type = isset($_GET['exam_type']) ? $_GET['exam_type'] : 'all';

$results = [];
$class_subjects = [];
$overall_summary = [
    'total_marks' => 0,
    'obtained_marks' => 0,
    'subjects_count' => 0
];

if ($selected_class_id) {
    // Get student ID
    $student_query = "SELECT id FROM students WHERE user_id = ?";
    $stmt = $conn->prepare($student_query);
    $stmt->execute([$student_id]);
    $student_db_id = $stmt->fetchColumn();
    
    if ($student_db_id) {
        try {
            // Get marks (only approved ones)
            $marks_query = "SELECT m.*, s.name as subject_name, e.name as exam_name 
                          FROM marks m
                          JOIN subjects s ON m.subject_id = s.id
                          LEFT JOIN exams e ON m.exam_id = e.id
                          WHERE m.student_id = ?
                          AND m.class_id = ?
                          AND m.status = 'approved'";
                          
            if ($selected_exam_type !== 'all') {
                $marks_query .= " AND m.exam_type = ?";
                $stmt = $conn->prepare($marks_query);
                $stmt->execute([$student_db_id, $selected_class_id, $selected_exam_type]);
            } else {
                $stmt = $conn->prepare($marks_query);
                $stmt->execute([$student_db_id, $selected_class_id]);
            }
            
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $error = "Error fetching results: " . $e->getMessage();
            $results = [];
        }
    }

    // Calculate overall summary
    foreach ($results as $result) {
        $overall_summary['total_marks'] += $result['max_marks'];
        $overall_summary['obtained_marks'] += $result['marks'];
        $overall_summary['subjects_count']++;
    }

    // Get subjects for the class
    $subjects_query = "SELECT DISTINCT s.id, s.name 
                      FROM subjects s
                      JOIN class_subjects cs ON s.id = cs.subject_id
                      WHERE cs.class_id = ?";
    $stmt = $conn->prepare($subjects_query);
    $stmt->execute([$selected_class_id]);
    $class_subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get class name
$selected_class_name = '';
if ($selected_class_id) {
    $class_query = "SELECT class_name FROM classes WHERE id = ?";
    $stmt = $conn->prepare($class_query);
    $stmt->execute([$selected_class_id]);
    $selected_class_name = $stmt->fetchColumn();
}
?>

<div class="container mx-auto px-4 py-6">
    <div class="bg-white rounded-lg shadow-lg p-6">
        <h2 class="text-2xl font-bold mb-6">My Results</h2>
        
        <!-- Filters -->
        <form method="GET" class="mb-8 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Select Class</label>
                <select name="class_id" class="form-select w-full rounded-md border-gray-300">
                    <?php foreach ($classes as $class): ?>
                        <option value="<?php echo $class['id']; ?>" 
                                <?php echo $selected_class_id == $class['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($class['class_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Exam Type</label>
                <select name="exam_type" class="form-select w-full rounded-md border-gray-300">
                    <option value="all" <?php echo $selected_exam_type === 'all' ? 'selected' : ''; ?>>
                        All Exams
                    </option>
                    <option value="midterm" <?php echo $selected_exam_type === 'midterm' ? 'selected' : ''; ?>>
                        Midterm
                    </option>
                    <option value="final" <?php echo $selected_exam_type === 'final' ? 'selected' : ''; ?>>
                        Final
                    </option>
                    <option value="assignment" <?php echo $selected_exam_type === 'assignment' ? 'selected' : ''; ?>>
                        Assignment
                    </option>
                </select>
            </div>
            
            <div class="flex items-end">
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
                    Filter
                </button>
            </div>
        </form>
        
        <?php if ($selected_class_id && !empty($results)): ?>
            <!-- Results Summary -->
            <div class="bg-blue-50 rounded-lg p-6 border border-blue-200 mb-8">
                <h3 class="text-lg font-semibold text-blue-800 mb-4">Overall Summary</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <p class="text-sm text-blue-600">Total Marks</p>
                        <p class="text-2xl font-bold text-blue-800">
                            <?php echo $overall_summary['obtained_marks']; ?> / <?php echo $overall_summary['total_marks']; ?>
                        </p>
                    </div>
                    <div>
                        <p class="text-sm text-blue-600">Average Percentage</p>
                        <p class="text-2xl font-bold text-blue-800">
                            <?php echo $overall_summary['total_marks'] ? 
                                  round(($overall_summary['obtained_marks'] / $overall_summary['total_marks']) * 100, 2) : 0; ?>%
                        </p>
                    </div>
                    <div>
                        <p class="text-sm text-blue-600">Subjects</p>
                        <p class="text-2xl font-bold text-blue-800">
                            <?php echo count($results); ?>
                        </p>
                    </div>
                </div>
            </div>
            
            <!-- Results Table -->
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Subject
                            </th>
                            <?php if ($selected_exam_type === 'all'): ?>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Midterm
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Final
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Assignment
                                </th>
                            <?php else: ?>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Marks
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Percentage
                                </th>
                            <?php endif; ?>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Remarks
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($results as $result): ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap font-medium">
                                    <?php echo htmlspecialchars($result['subject_name']); ?>
                                </td>
                                <?php if ($selected_exam_type === 'all'): ?>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if (isset($result['marks']) && isset($result['max_marks'])): ?>
                                            <?php echo $result['marks']; ?> / <?php echo $result['max_marks']; ?>
                                            <span class="text-sm text-gray-500">
                                                (<?php echo round(($result['marks'] / $result['max_marks']) * 100); ?>%)
                                            </span>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if (isset($result['marks']) && isset($result['max_marks'])): ?>
                                            <?php echo $result['marks']; ?> / <?php echo $result['max_marks']; ?>
                                            <span class="text-sm text-gray-500">
                                                (<?php echo round(($result['marks'] / $result['max_marks']) * 100); ?>%)
                                            </span>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if (isset($result['marks']) && isset($result['max_marks'])): ?>
                                            <?php echo $result['marks']; ?> / <?php echo $result['max_marks']; ?>
                                            <span class="text-sm text-gray-500">
                                                (<?php echo round(($result['marks'] / $result['max_marks']) * 100); ?>%)
                                            </span>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                <?php else: ?>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if (isset($result['marks']) && isset($result['max_marks'])): ?>
                                            <?php echo $result['marks']; ?> / <?php echo $result['max_marks']; ?>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if (isset($result['marks']) && isset($result['max_marks'])): ?>
                                            <?php echo round(($result['marks'] / $result['max_marks']) * 100); ?>%
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                <?php endif; ?>
                                <td class="px-6 py-4">
                                    <?php echo htmlspecialchars($result['remarks']); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="text-center text-gray-500">
                No results found
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../../components/footer.php'; ?> 