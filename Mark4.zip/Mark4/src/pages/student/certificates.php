<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/config.php';
require_once '../../utils/notification_utils.php';

// Check if user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    $_SESSION['error_message'] = "Unauthorized access. Please login as a student.";
    header('Location: ' . LOGIN_URL);
    exit();
}

// Initialize database connection
try {
    $db = new Database();
    $conn = $db->getConnection();
} catch (PDOException $e) {
    $_SESSION['error_message'] = "Database connection failed: " . $e->getMessage();
    header('Location: ' . getDashboardUrl('student'));
    exit();
}

$student_id = $_SESSION['user_id'];

// Get student information
try {
    $student_query = "SELECT s.id, s.roll_number, s.school_id, c.id as class_id, c.class_name, sc.name as school_name
                     FROM students s
                     JOIN classes c ON s.class_id = c.id
                     JOIN schools sc ON s.school_id = sc.id
                     WHERE s.user_id = ?";
    $stmt = $conn->prepare($student_query);
    $stmt->execute([$student_id]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$student) {
        $_SESSION['error_message'] = "Student record not found.";
        header('Location: ' . getDashboardUrl('student'));
        exit();
    }
} catch (PDOException $e) {
    $_SESSION['error_message'] = "Error fetching student information: " . $e->getMessage();
    header('Location: ' . getDashboardUrl('student'));
    exit();
}

// Handle certificate request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_certificate'])) {
    $certificate_type = $_POST['certificate_type'];
    $reason = $_POST['reason'] ?? '';
    
    try {
        // Check if a similar pending request already exists
        $check_query = "SELECT id FROM certificates 
                       WHERE student_id = ? AND type = ? AND status = 'pending'";
        $stmt = $conn->prepare($check_query);
        $stmt->execute([$student['id'], $certificate_type]);
        
        if ($stmt->fetch()) {
            $_SESSION['error_message'] = "You already have a pending " . ucfirst($certificate_type) . " certificate request.";
        } else {
            // Insert new certificate request
            $insert_query = "INSERT INTO certificates (student_id, type, status, reason, school_id) 
                            VALUES (?, ?, 'pending', ?, ?)";
            $stmt = $conn->prepare($insert_query);
            $stmt->execute([$student['id'], $certificate_type, $reason, $student['school_id']]);
            
            // Send notification to principal
            $notification_sent = notifyCertificateRequest(
                $student['id'],
                $student['school_id'],
                $certificate_type,
                $conn
            );
            
            if ($notification_sent) {
                error_log("Certificate request notification sent to principal for school ID: " . $student['school_id']);
            } else {
                error_log("Failed to send certificate request notification");
            }
            
            $_SESSION['success_message'] = "Your " . ucfirst($certificate_type) . " certificate request has been submitted.";
        }
        
        // Redirect to prevent form resubmission
        header('Location: ' . getPageUrl('student', 'certificates'));
        exit();
    } catch (PDOException $e) {
        $_SESSION['error_message'] = "Error submitting certificate request: " . $e->getMessage();
    }
}

// Get all certificate requests for the student
try {
    $certificates_query = "SELECT id, type, status, requested_at, processed_at, remarks 
                          FROM certificates 
                          WHERE student_id = ?
                          ORDER BY requested_at DESC";
    $stmt = $conn->prepare($certificates_query);
    $stmt->execute([$student['id']]);
    $certificates = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $_SESSION['error_message'] = "Error fetching certificates: " . $e->getMessage();
    $certificates = [];
}

// Include header
require_once '../../components/header.php';
?>

<div class="container mx-auto px-4 py-6">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-900">My Certificates</h1>
        <button id="requestCertificateBtn" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition">
            <i class="fas fa-plus-circle mr-2"></i> Request Certificate
        </button>
    </div>
    
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4">
            <?php 
            echo htmlspecialchars($_SESSION['success_message']);
            unset($_SESSION['success_message']);
            ?>
        </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4">
            <?php 
            echo htmlspecialchars($_SESSION['error_message']);
            unset($_SESSION['error_message']);
            ?>
        </div>
    <?php endif; ?>
    
    <!-- Student Information Card -->
    <div class="bg-white rounded-lg shadow-md p-6 mb-6">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
                <h3 class="text-sm font-medium text-gray-500">Student Name</h3>
                <p class="mt-1 text-base font-semibold"><?php echo htmlspecialchars($_SESSION['username']); ?></p>
            </div>
            <div>
                <h3 class="text-sm font-medium text-gray-500">Roll Number</h3>
                <p class="mt-1 text-base font-semibold"><?php echo htmlspecialchars($student['roll_number']); ?></p>
            </div>
            <div>
                <h3 class="text-sm font-medium text-gray-500">Class</h3>
                <p class="mt-1 text-base font-semibold"><?php echo htmlspecialchars($student['class_name']); ?></p>
            </div>
        </div>
    </div>

    <!-- Certificates List -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-200">
            <h2 class="text-lg font-medium text-gray-900">Certificate Requests</h2>
        </div>
        
        <?php if (!empty($certificates)): ?>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Requested Date</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Processed Date</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($certificates as $cert): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    <?php echo ucfirst(htmlspecialchars($cert['type'])); ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full 
                                        <?php 
                                        switch($cert['status']) {
                                            case 'approved':
                                                echo 'bg-green-100 text-green-800';
                                                break;
                                            case 'rejected':
                                                echo 'bg-red-100 text-red-800';
                                                break;
                                            default:
                                                echo 'bg-yellow-100 text-yellow-800';
                                        }
                                        ?>">
                                        <?php echo ucfirst(htmlspecialchars($cert['status'])); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    <?php echo date('M d, Y', strtotime($cert['requested_at'])); ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    <?php echo $cert['processed_at'] ? date('M d, Y', strtotime($cert['processed_at'])) : '-'; ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm">
                                    <?php if ($cert['status'] === 'approved'): ?>
                                        <a href="<?php echo getPageUrl('student', 'view_certificate') . '?id=' . $cert['id']; ?>" 
                                           class="text-green-600 hover:text-green-900">
                                            <i class="fas fa-print mr-1"></i> Print Certificate
                                        </a>
                                    <?php elseif ($cert['status'] === 'rejected'): ?>
                                        <?php if (!empty($cert['remarks'])): ?>
                                            <button onclick="showRemarks('<?php echo addslashes($cert['remarks']); ?>')" class="text-red-600 hover:text-red-900">
                                                <i class="fas fa-info-circle mr-1"></i> View Reason
                                            </button>
                                        <?php else: ?>
                                            <span class="text-gray-500">No remarks</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-yellow-600">
                                            <i class="fas fa-clock mr-1"></i> Pending
                                        </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="text-center py-8">
                <div class="mb-4">
                    <i class="fas fa-certificate text-gray-400 text-5xl"></i>
                </div>
                <h3 class="text-lg font-medium text-gray-900 mb-2">No Certificate Requests</h3>
                <p class="text-gray-500">You haven't requested any certificates yet.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Certificate Request Modal -->
<div id="requestModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-medium">Request Certificate</h3>
            <button onclick="closeModal()" class="text-gray-400 hover:text-gray-500">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <form method="POST" action="">
            <input type="hidden" name="request_certificate" value="1">
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="certificate_type">
                    Certificate Type
                </label>
                <select name="certificate_type" id="certificate_type" required
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    <option value="bonafide">Bonafide Certificate</option>
                    <option value="leaving">Leaving Certificate</option>
                </select>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="reason">
                    Reason for Request
                </label>
                <textarea name="reason" id="reason"
                          class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                          rows="3" placeholder="Please provide a reason for your certificate request"></textarea>
            </div>
            <div class="flex justify-end">
                <button type="button" onclick="closeModal()"
                        class="mr-2 px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-300 rounded-md hover:bg-gray-200">
                    Cancel
                </button>
                <button type="submit" 
                        class="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700">
                    Submit Request
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Remarks Modal -->
<div id="remarksModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-medium">Rejection Reason</h3>
            <button onclick="closeRemarksModal()" class="text-gray-400 hover:text-gray-500">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="p-4 bg-red-50 rounded-md mb-4">
            <p id="remarksContent" class="text-gray-700"></p>
        </div>
        <div class="flex justify-end">
            <button onclick="closeRemarksModal()"
                    class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-300 rounded-md hover:bg-gray-200">
                Close
            </button>
        </div>
    </div>
</div>

<script>
// Show certificate request modal
document.getElementById('requestCertificateBtn').addEventListener('click', function() {
    document.getElementById('requestModal').classList.remove('hidden');
});

// Close certificate request modal
function closeModal() {
    document.getElementById('requestModal').classList.add('hidden');
}

// Show remarks modal
function showRemarks(remarks) {
    document.getElementById('remarksContent').textContent = remarks;
    document.getElementById('remarksModal').classList.remove('hidden');
}

// Close remarks modal
function closeRemarksModal() {
    document.getElementById('remarksModal').classList.add('hidden');
}

// Close modals when clicking outside
window.onclick = function(event) {
    let requestModal = document.getElementById('requestModal');
    let remarksModal = document.getElementById('remarksModal');
    
    if (event.target === requestModal) {
        closeModal();
    }
    
    if (event.target === remarksModal) {
        closeRemarksModal();
    }
}
</script>

<?php require_once '../../components/footer.php'; ?> 