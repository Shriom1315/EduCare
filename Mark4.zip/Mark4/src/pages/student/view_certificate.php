<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/config.php';
require_once '../../utils/certificate_utils.php';

// Check if user is logged in and is a student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    $_SESSION['error_message'] = "Unauthorized access. Please login as a student.";
    header('Location: ' . LOGIN_URL);
    exit();
}

// Initialize database connection
try {
    $db = new Database();
    $conn = $db->getConnection();
} catch (PDOException $e) {
    $_SESSION['error_message'] = "Database connection failed: " . $e->getMessage();
    header('Location: ' . getDashboardUrl('student'));
    exit();
}

$student_id = $_SESSION['user_id'];
$certificate_id = $_GET['id'] ?? null;

if (!$certificate_id) {
    $_SESSION['error_message'] = "Certificate ID is required.";
    header('Location: ' . getPageUrl('student', 'certificates'));
    exit();
}

// Get the certificate details using our utility function
$certificate = getCertificateData($conn, $certificate_id, [
    'role' => 'student',
    'user_id' => $student_id
]);

if (!$certificate) {
    $_SESSION['error_message'] = "Certificate not found or not approved.";
    header('Location: ' . getPageUrl('student', 'certificates'));
    exit();
}

// Render the certificate with the back URL pointing to the certificates page
renderCertificate($certificate, true, getPageUrl('student', 'certificates')); 