<?php
// Include necessary files
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../components/header.php';

// Check if user is logged in as student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('Location: ' . LOGIN_URL);
    exit();
}

// Get student info
$user_id = $_SESSION['user_id'];
$db = new Database();
$conn = $db->getConnection();

// Get student's school_id
$query = "SELECT s.school_id FROM students s WHERE s.user_id = ?";
$stmt = $conn->prepare($query);
$stmt->execute([$user_id]);
$school_id = $stmt->fetchColumn();

// Fetch notices for this school (sorted by newest first)
$query = "SELECT n.*, u.username as created_by_name
          FROM notices n
          JOIN users u ON n.created_by = u.id
          WHERE n.school_id = ? 
          AND (n.target_audience = 'all' OR n.target_audience = 'students')
          ORDER BY n.created_at DESC";
$stmt = $conn->prepare($query);
$stmt->execute([$school_id]);
$notices = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- Page Content -->
<div class="container mx-auto px-4 py-8">
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="border-b border-gray-200 bg-gray-50 px-6 py-4 flex justify-between items-center">
            <h1 class="text-xl font-semibold text-gray-800">School Notices</h1>
        </div>
        
        <div class="p-6">
            <?php if (empty($notices)): ?>
                <div class="bg-blue-50 text-blue-700 p-4 rounded-md mb-4">
                    <p>No notices available at this time.</p>
                </div>
            <?php else: ?>
                <div class="space-y-6">
                    <?php foreach ($notices as $notice): ?>
                        <div class="border border-gray-200 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                            <div class="bg-gradient-to-r from-blue-50 to-indigo-50 px-6 py-4 border-b border-gray-200">
                                <div class="flex justify-between items-center">
                                    <h2 class="text-lg font-semibold text-gray-800"><?php echo htmlspecialchars($notice['title']); ?></h2>
                                    <div class="flex items-center text-sm text-gray-600">
                                        <span class="mr-2">
                                            <i class="fas fa-user mr-1"></i>
                                            <?php echo htmlspecialchars($notice['created_by_name']); ?>
                                        </span>
                                        <span>
                                            <i class="far fa-calendar-alt mr-1"></i>
                                            <?php echo date('M d, Y', strtotime($notice['created_at'])); ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="px-6 py-4 bg-white">
                                <div class="prose max-w-none text-gray-600">
                                    <?php echo nl2br(htmlspecialchars($notice['content'])); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../components/footer.php'; ?>
