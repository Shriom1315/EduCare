<?php
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is super admin
if ($_SESSION['role'] !== 'super_admin') {
    header('Location: /src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'upload':
                $school_id = $_POST['school_id'] ?? '';
                $caption = $_POST['caption'] ?? '';
                $display_order = $_POST['display_order'] ?? 0;

                if (!empty($school_id) && !empty($_FILES['image'])) {
                    try {
                        // Create uploads directory if it doesn't exist
                        $upload_dir = __DIR__ . '/../../../uploads/school_images/';
                        if (!file_exists($upload_dir)) {
                            mkdir($upload_dir, 0777, true);
                        }

                        // Process file upload
                        $file = $_FILES['image'];
                        $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];

                        if (!in_array($file_ext, $allowed_types)) {
                            throw new Exception('Invalid file type. Only JPG, JPEG, PNG, and GIF files are allowed.');
                        }

                        // Generate unique filename
                        $new_filename = uniqid('school_') . '.' . $file_ext;
                        $file_path = $upload_dir . $new_filename;
                        
                        // Move uploaded file
                        if (move_uploaded_file($file['tmp_name'], $file_path)) {
                            // Save to database
                            $query = "INSERT INTO school_images (school_id, image_path, caption, display_order, created_by) 
                                     VALUES (:school_id, :image_path, :caption, :display_order, :created_by)";
                            $stmt = $db->prepare($query);
                            $relative_path = '/uploads/school_images/' . $new_filename;
                            $stmt->bindParam(':school_id', $school_id);
                            $stmt->bindParam(':image_path', $relative_path);
                            $stmt->bindParam(':caption', $caption);
                            $stmt->bindParam(':display_order', $display_order);
                            $stmt->bindParam(':created_by', $_SESSION['user_id']);
                            $stmt->execute();

                            $success = "Image uploaded successfully!";
                        } else {
                            throw new Exception('Error uploading file.');
                        }
                    } catch (Exception $e) {
                        $error = "Error uploading image: " . $e->getMessage();
                    }
                }
                break;

            case 'delete':
                $image_id = $_POST['image_id'] ?? '';
                if (!empty($image_id)) {
                    try {
                        // Get image path before deleting
                        $query = "SELECT image_path FROM school_images WHERE id = :id";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':id', $image_id);
                        $stmt->execute();
                        $image = $stmt->fetch(PDO::FETCH_ASSOC);

                        if ($image) {
                            // Delete file
                            $file_path = __DIR__ . '/../../../' . $image['image_path'];
                            if (file_exists($file_path)) {
                                unlink($file_path);
                            }

                            // Delete from database
                            $query = "DELETE FROM school_images WHERE id = :id";
                            $stmt = $db->prepare($query);
                            $stmt->bindParam(':id', $image_id);
                            $stmt->execute();

                            $success = "Image deleted successfully!";
                        }
                    } catch (Exception $e) {
                        $error = "Error deleting image: " . $e->getMessage();
                    }
                }
                break;
        }
    }
}

// Get all schools
$query = "SELECT id, name FROM schools ORDER BY name";
$stmt = $db->prepare($query);
$stmt->execute();
$schools = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all images grouped by school
$query = "SELECT si.*, s.name as school_name, u.username as uploaded_by 
          FROM school_images si 
          JOIN schools s ON si.school_id = s.id 
          JOIN users u ON si.created_by = u.id 
          ORDER BY s.name, si.display_order, si.created_at DESC";
$stmt = $db->prepare($query);
$stmt->execute();
$images = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Group images by school
$images_by_school = [];
foreach ($images as $image) {
    $school_id = $image['school_id'];
    if (!isset($images_by_school[$school_id])) {
        $images_by_school[$school_id] = [
            'school_name' => $image['school_name'],
            'images' => []
        ];
    }
    $images_by_school[$school_id]['images'][] = $image;
}
?>

<!-- Page Content -->
<div class="container mx-auto px-4 py-6">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">School Images Management</h1>
        <button onclick="showUploadModal()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200">
            <i class="fas fa-upload mr-2"></i>Upload New Image
        </button>
    </div>

    <?php if (isset($success)): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline"><?php echo $success; ?></span>
        </div>
    <?php endif; ?>

    <?php if (isset($error)): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline"><?php echo $error; ?></span>
        </div>
    <?php endif; ?>

    <!-- Images by School -->
    <?php foreach ($images_by_school as $school_id => $school_data): ?>
        <div class="bg-white rounded-lg shadow-md overflow-hidden mb-6">
            <div class="px-6 py-4 bg-gray-50 border-b border-gray-200">
                <h2 class="text-xl font-semibold text-gray-800"><?php echo htmlspecialchars($school_data['school_name']); ?></h2>
            </div>
            <div class="p-6">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <?php foreach ($school_data['images'] as $image): ?>
                        <div class="relative group">
                            <img src="/Mark4<?php echo htmlspecialchars($image['image_path']); ?>" 
                                 alt="School Image" 
                                 class="w-full h-48 object-cover rounded-lg">
                            
                            <div class="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-200 rounded-lg flex items-center justify-center">
                                <div class="text-white text-center p-4">
                                    <?php if ($image['caption']): ?>
                                        <p class="mb-4"><?php echo htmlspecialchars($image['caption']); ?></p>
                                    <?php endif; ?>
                                    <p class="text-sm mb-2">Order: <?php echo $image['display_order']; ?></p>
                                    <p class="text-sm mb-4">Uploaded by: <?php echo htmlspecialchars($image['uploaded_by']); ?></p>
                                    <form method="POST" class="inline">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="image_id" value="<?php echo $image['id']; ?>">
                                        <button type="submit" onclick="return confirm('Are you sure you want to delete this image?')"
                                                class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition-colors duration-200">
                                            <i class="fas fa-trash mr-2"></i>Delete
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<!-- Upload Modal -->
<div id="uploadModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Upload New Image</h3>
            <form method="POST" enctype="multipart/form-data" class="space-y-4">
                <input type="hidden" name="action" value="upload">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700">School</label>
                    <select name="school_id" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Select a school</option>
                        <?php foreach ($schools as $school): ?>
                            <option value="<?php echo $school['id']; ?>">
                                <?php echo htmlspecialchars($school['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Image</label>
                    <input type="file" name="image" accept="image/*" required
                           class="mt-1 block w-full text-sm text-gray-500
                                  file:mr-4 file:py-2 file:px-4
                                  file:rounded-full file:border-0
                                  file:text-sm file:font-semibold
                                  file:bg-blue-50 file:text-blue-700
                                  hover:file:bg-blue-100">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Caption (Optional)</label>
                    <input type="text" name="caption"
                           class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Display Order</label>
                    <input type="number" name="display_order" value="0" min="0"
                           class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="hideUploadModal()"
                            class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 transition-colors duration-200">
                        Cancel
                    </button>
                    <button type="submit"
                            class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors duration-200">
                        Upload
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function showUploadModal() {
    document.getElementById('uploadModal').classList.remove('hidden');
}

function hideUploadModal() {
    document.getElementById('uploadModal').classList.add('hidden');
}
</script>

<?php require_once '../../components/footer.php'; ?> 