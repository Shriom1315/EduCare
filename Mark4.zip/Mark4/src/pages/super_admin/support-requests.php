<?php
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is super admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'super_admin') {
    $_SESSION['error_message'] = "Unauthorized access. Please login as administrator.";
    header('Location: ' . LOGIN_URL);
    exit();
}

// Initialize database connection
try {
    $db = new Database();
    $conn = $db->getConnection();
} catch (PDOException $e) {
    $_SESSION['error_message'] = "Database connection failed: " . $e->getMessage();
    header('Location: ' . getDashboardUrl('super_admin'));
    exit();
}

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    try {
        $request_id = $_POST['request_id'] ?? 0;
        $status = $_POST['status'] ?? '';
        $remarks = $_POST['remarks'] ?? '';
        
        if (!empty($request_id) && !empty($status)) {
            $query = "UPDATE support_requests SET status = :status, updated_at = NOW() WHERE id = :id";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':status', $status);
            $stmt->bindParam(':id', $request_id);
            $stmt->execute();
            
            // If there are remarks, add them to a separate table or update the existing record
            if (!empty($remarks)) {
                // Check if support_request_notes table exists
                $table_exists = false;
                try {
                    $check_table = $conn->query("SHOW TABLES LIKE 'support_request_notes'");
                    $table_exists = $check_table->rowCount() > 0;
                } catch (PDOException $e) {
                    // Table doesn't exist
                }
                
                // Create notes table if it doesn't exist
                if (!$table_exists) {
                    $create_table_sql = "CREATE TABLE IF NOT EXISTS support_request_notes (
                        id INT PRIMARY KEY AUTO_INCREMENT,
                        request_id INT NOT NULL,
                        note TEXT NOT NULL,
                        added_by INT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (request_id) REFERENCES support_requests(id) ON DELETE CASCADE
                    )";
                    $conn->exec($create_table_sql);
                }
                
                // Insert note
                $note_query = "INSERT INTO support_request_notes (request_id, note, added_by) VALUES (:request_id, :note, :added_by)";
                $note_stmt = $conn->prepare($note_query);
                $note_stmt->bindParam(':request_id', $request_id);
                $note_stmt->bindParam(':note', $remarks);
                $note_stmt->bindParam(':added_by', $_SESSION['user_id']);
                $note_stmt->execute();
            }
            
            $_SESSION['success_message'] = "Support request status updated successfully.";
        }
    } catch (PDOException $e) {
        $_SESSION['error_message'] = "Error updating status: " . $e->getMessage();
    }
    
    // Prevent form resubmission
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit();
}

// Get status filter
$status_filter = $_GET['status'] ?? 'all';
$valid_statuses = ['all', 'new', 'in_progress', 'resolved'];
if (!in_array($status_filter, $valid_statuses)) {
    $status_filter = 'all';
}

// Fetch support requests
try {
    $query = "SELECT sr.*, 
              DATE_FORMAT(sr.created_at, '%d %b %Y, %H:%i') as formatted_date,
              DATE_FORMAT(sr.updated_at, '%d %b %Y, %H:%i') as formatted_updated
              FROM support_requests sr";
    
    if ($status_filter !== 'all') {
        $query .= " WHERE sr.status = :status";
    }
    
    $query .= " ORDER BY sr.created_at DESC";
    
    $stmt = $conn->prepare($query);
    
    if ($status_filter !== 'all') {
        $stmt->bindParam(':status', $status_filter);
    }
    
    $stmt->execute();
    $support_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $_SESSION['error_message'] = "Error fetching support requests: " . $e->getMessage();
    $support_requests = [];
}

// Fetch notes for each request
$request_notes = [];
if (!empty($support_requests)) {
    try {
        // Check if notes table exists first
        $check_table = $conn->query("SHOW TABLES LIKE 'support_request_notes'");
        if ($check_table->rowCount() > 0) {
            $request_ids = array_column($support_requests, 'id');
            $placeholders = implode(',', array_fill(0, count($request_ids), '?'));
            
            $notes_query = "SELECT srn.*, 
                          DATE_FORMAT(srn.created_at, '%d %b %Y, %H:%i') as formatted_date,
                          u.username as added_by_name 
                          FROM support_request_notes srn
                          LEFT JOIN users u ON srn.added_by = u.id
                          WHERE srn.request_id IN ($placeholders)
                          ORDER BY srn.created_at ASC";
            $notes_stmt = $conn->prepare($notes_query);
            
            // Bind all request IDs
            foreach ($request_ids as $index => $id) {
                $notes_stmt->bindValue($index + 1, $id);
            }
            
            $notes_stmt->execute();
            $notes = $notes_stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Group notes by request ID
            foreach ($notes as $note) {
                if (!isset($request_notes[$note['request_id']])) {
                    $request_notes[$note['request_id']] = [];
                }
                $request_notes[$note['request_id']][] = $note;
            }
        }
    } catch (PDOException $e) {
        error_log("Error fetching notes: " . $e->getMessage());
    }
}

// Count requests by status
$status_counts = [
    'all' => count($support_requests),
    'new' => 0,
    'in_progress' => 0,
    'resolved' => 0
];

foreach ($support_requests as $request) {
    $status_counts[$request['status']]++;
}
?>

<div class="container mx-auto px-4 py-6">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Support Requests</h1>
    </div>
    
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
            <p><?php echo $_SESSION['success_message']; ?></p>
        </div>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
            <p><?php echo $_SESSION['error_message']; ?></p>
        </div>
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>
    
    <!-- Status Filter Tabs -->
    <div class="mb-6 border-b border-gray-200">
        <ul class="flex flex-wrap -mb-px">
            <?php foreach ($valid_statuses as $status): ?>
                <li class="mr-2">
                    <a href="?status=<?php echo $status; ?>" 
                       class="inline-block p-4 <?php echo $status_filter === $status ? 'text-blue-600 border-b-2 border-blue-600 font-medium' : 'text-gray-500 hover:text-gray-700 hover:border-gray-300 border-transparent border-b-2'; ?>">
                        <?php echo ucfirst(str_replace('_', ' ', $status)); ?> 
                        <span class="inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none <?php echo $status_filter === $status ? 'text-white bg-blue-600' : 'text-gray-500 bg-gray-200'; ?> rounded-full ml-2">
                            <?php echo $status_counts[$status]; ?>
                        </span>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
    
    <!-- Support Requests List -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <?php if (empty($support_requests)): ?>
            <div class="p-8 text-center">
                <i class="fas fa-inbox text-gray-300 text-5xl mb-4"></i>
                <p class="text-gray-500 text-lg">No support requests found</p>
                <?php if ($status_filter !== 'all'): ?>
                    <p class="text-gray-400 mt-2">Try changing your filter to see more results</p>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Request ID</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($support_requests as $request): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900">#<?php echo str_pad($request['id'], 5, '0', STR_PAD_LEFT); ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($request['name']); ?></div>
                                    <div class="text-sm text-gray-500"><?php echo htmlspecialchars($request['email']); ?></div>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="text-sm text-gray-900"><?php echo htmlspecialchars($request['subject']); ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-500"><?php echo $request['formatted_date']; ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                          <?php 
                                          switch($request['status']) {
                                              case 'new':
                                                  echo 'bg-red-100 text-red-800';
                                                  break;
                                              case 'in_progress':
                                                  echo 'bg-blue-100 text-blue-800';
                                                  break;
                                              case 'resolved':
                                                  echo 'bg-green-100 text-green-800';
                                                  break;
                                              default:
                                                  echo 'bg-gray-100 text-gray-800';
                                          }
                                          ?>">
                                        <?php echo ucfirst(str_replace('_', ' ', $request['status'])); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                    <button onclick="showRequestDetails(<?php echo htmlspecialchars(json_encode($request)); ?>, <?php echo isset($request_notes[$request['id']]) ? htmlspecialchars(json_encode($request_notes[$request['id']])) : '[]'; ?>)" class="text-blue-600 hover:text-blue-900 mx-2">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button onclick="showUpdateStatusModal(<?php echo $request['id']; ?>, '<?php echo $request['status']; ?>')" class="text-green-600 hover:text-green-900 mx-2">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Request Details Modal -->
<div id="requestDetailsModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full z-50">
    <div class="relative top-20 mx-auto p-5 border w-11/12 md:w-3/4 lg:w-1/2 shadow-lg rounded-md bg-white max-h-[80vh] overflow-y-auto">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-medium text-gray-900" id="modalTitle">Support Request Details</h3>
            <button onclick="hideRequestDetailsModal()" class="text-gray-400 hover:text-gray-500">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div id="requestDetails" class="space-y-4">
            <!-- Will be populated by JavaScript -->
        </div>
    </div>
</div>

<!-- Update Status Modal -->
<div id="updateStatusModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full z-50">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-medium text-gray-900">Update Request Status</h3>
            <button onclick="hideUpdateStatusModal()" class="text-gray-400 hover:text-gray-500">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <form method="POST" class="space-y-4">
            <input type="hidden" name="update_status" value="1">
            <input type="hidden" name="request_id" id="status_request_id" value="">
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Status</label>
                <select name="status" id="status_select" class="w-full px-3 py-2 border border-gray-300 rounded text-gray-700" 
                        style="border: 1px solid #ccc; border-radius: 4px; padding: 8px 12px; width: 100%;">
                    <option value="new">New</option>
                    <option value="in_progress">In Progress</option>
                    <option value="resolved">Resolved</option>
                </select>
            </div>
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Remarks (Optional)</label>
                <textarea name="remarks" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded text-gray-700"
                          style="border: 1px solid #ccc; border-radius: 4px; padding: 8px 12px; width: 100%;"></textarea>
            </div>
            
            <div class="flex justify-end space-x-3">
                <button type="button" onclick="hideUpdateStatusModal()" class="px-4 py-2 bg-gray-200 text-gray-800 rounded">
                    Cancel
                </button>
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded">
                    Update Status
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function showRequestDetails(request, notes) {
        const modal = document.getElementById('requestDetailsModal');
        const detailsContainer = document.getElementById('requestDetails');
        
        // Format message with line breaks preserved
        const formattedMessage = request.message.replace(/\n/g, '<br>');
        
        // Build the details HTML
        let detailsHTML = `
            <div class="border-b pb-4">
                <div class="flex justify-between items-center">
                    <h4 class="text-xl font-semibold">${request.subject}</h4>
                    <span class="px-2 py-1 text-xs font-bold rounded-full ${
                        request.status === 'new' ? 'bg-red-100 text-red-800' : 
                        request.status === 'in_progress' ? 'bg-blue-100 text-blue-800' : 
                        'bg-green-100 text-green-800'
                    }">
                        ${request.status.replace('_', ' ').toUpperCase()}
                    </span>
                </div>
                <div class="text-sm text-gray-500 mt-1">
                    Request #${String(request.id).padStart(5, '0')} - Submitted on ${request.formatted_date}
                </div>
            </div>
            
            <div class="border-b pb-4">
                <h5 class="text-sm font-medium text-gray-700 mb-2">Requester Information</h5>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <p class="text-xs text-gray-500">Name</p>
                        <p class="text-sm">${request.name}</p>
                    </div>
                    <div>
                        <p class="text-xs text-gray-500">Email</p>
                        <p class="text-sm">${request.email}</p>
                    </div>
                    <div>
                        <p class="text-xs text-gray-500">User Role</p>
                        <p class="text-sm">${request.user_role || 'Guest'}</p>
                    </div>
                    <div>
                        <p class="text-xs text-gray-500">User ID</p>
                        <p class="text-sm">${request.user_id || 'Not logged in'}</p>
                    </div>
                </div>
            </div>
            
            <div class="pb-4">
                <h5 class="text-sm font-medium text-gray-700 mb-2">Message</h5>
                <div class="bg-gray-50 p-3 rounded text-sm">
                    ${formattedMessage}
                </div>
            </div>`;
            
        // Add notes section if there are any
        if (notes && notes.length > 0) {
            detailsHTML += `
                <div class="border-t pt-4">
                    <h5 class="text-sm font-medium text-gray-700 mb-2">Admin Notes</h5>
                    <div class="space-y-3">`;
                    
            notes.forEach(note => {
                detailsHTML += `
                    <div class="bg-blue-50 p-3 rounded text-sm">
                        <div class="text-xs text-gray-500 mb-1">
                            Added by ${note.added_by_name || 'Admin'} on ${note.formatted_date}
                        </div>
                        <div>${note.note}</div>
                    </div>`;
            });
            
            detailsHTML += `
                    </div>
                </div>`;
        }
        
        // Add quick actions
        detailsHTML += `
            <div class="border-t pt-4 mt-4">
                <div class="flex justify-end">
                    <button onclick="showUpdateStatusModal(${request.id}, '${request.status}')" 
                            class="px-4 py-2 bg-blue-600 text-white rounded text-sm">
                        Update Status
                    </button>
                </div>
            </div>`;
        
        detailsContainer.innerHTML = detailsHTML;
        modal.classList.remove('hidden');
    }
    
    function hideRequestDetailsModal() {
        document.getElementById('requestDetailsModal').classList.add('hidden');
    }
    
    function showUpdateStatusModal(requestId, currentStatus) {
        document.getElementById('status_request_id').value = requestId;
        document.getElementById('status_select').value = currentStatus;
        document.getElementById('updateStatusModal').classList.remove('hidden');
    }
    
    function hideUpdateStatusModal() {
        document.getElementById('updateStatusModal').classList.add('hidden');
    }
    
    // Close modals when clicking outside
    window.addEventListener('click', function(event) {
        const requestModal = document.getElementById('requestDetailsModal');
        const statusModal = document.getElementById('updateStatusModal');
        
        if (event.target === requestModal) {
            hideRequestDetailsModal();
        }
        
        if (event.target === statusModal) {
            hideUpdateStatusModal();
        }
    });
</script>

<?php require_once '../../components/footer.php'; ?> 