<?php
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is super admin
if ($_SESSION['role'] !== 'super_admin') {
    header('Location: /src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Fetch statistics
$stats = [
    'schools' => 0,
    'principals' => 0,
    'teachers' => 0
];

// Get total schools
$query = "SELECT COUNT(*) as count FROM schools";
$stmt = $db->query($query);
$stats['schools'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

// Get total principals
$query = "SELECT COUNT(*) as count FROM users WHERE role = 'principal'";
$stmt = $db->query($query);
$stats['principals'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

// Get total teachers
$query = "SELECT COUNT(*) as count FROM users WHERE role = 'teacher'";
$stmt = $db->query($query);
$stats['teachers'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

// Get recently added schools
$query = "SELECT s.*, u.username as principal_name 
          FROM schools s 
          LEFT JOIN users u ON s.principal_id = u.id 
          ORDER BY s.created_at DESC LIMIT 5";
$stmt = $db->query($query);
$recent_schools = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- Dashboard Content -->
<div class="container mx-auto px-4">
    <!-- Welcome Section -->
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-800">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
        <p class="text-gray-600">Here's what's happening in your schools today.</p>
    </div>

    <!-- Statistics Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <!-- Schools Card -->
        <div class="bg-white rounded-lg shadow-md p-6 transform hover:scale-105 transition-transform duration-200">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-blue-100 text-blue-600">
                    <i class="fas fa-school text-2xl"></i>
                </div>
                <div class="ml-4">
                    <h2 class="text-gray-600 text-sm">Total Schools</h2>
                    <p class="text-2xl font-semibold text-gray-800"><?php echo $stats['schools']; ?></p>
                </div>
            </div>
        </div>

        <!-- Principals Card -->
        <div class="bg-white rounded-lg shadow-md p-6 transform hover:scale-105 transition-transform duration-200">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-green-100 text-green-600">
                    <i class="fas fa-user-tie text-2xl"></i>
                </div>
                <div class="ml-4">
                    <h2 class="text-gray-600 text-sm">Total Principals</h2>
                    <p class="text-2xl font-semibold text-gray-800"><?php echo $stats['principals']; ?></p>
                </div>
            </div>
        </div>

        <!-- Teachers Card -->
        <div class="bg-white rounded-lg shadow-md p-6 transform hover:scale-105 transition-transform duration-200">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-purple-100 text-purple-600">
                    <i class="fas fa-chalkboard-teacher text-2xl"></i>
                </div>
                <div class="ml-4">
                    <h2 class="text-gray-600 text-sm">Total Teachers</h2>
                    <p class="text-2xl font-semibold text-gray-800"><?php echo $stats['teachers']; ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Schools and Quick Actions -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Recent Schools -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">Recently Added Schools</h2>
            <div class="space-y-4">
                <?php foreach ($recent_schools as $school): ?>
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                            <h3 class="font-medium text-gray-800"><?php echo htmlspecialchars($school['name']); ?></h3>
                            <p class="text-sm text-gray-600">Principal: <?php echo htmlspecialchars($school['principal_name'] ?? 'Not Assigned'); ?></p>
                        </div>
                        <a href="schools.php?id=<?php echo $school['id']; ?>" class="text-blue-600 hover:text-blue-800">
                            <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">Quick Actions</h2>
            <div class="grid grid-cols-2 gap-4">
                <a href="schools.php?action=add" class="flex items-center p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors duration-200">
                    <i class="fas fa-plus-circle text-blue-600 text-xl mr-3"></i>
                    <span class="text-gray-700">Add New School</span>
                </a>
                <a href="users.php?action=add&role=principal" class="flex items-center p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors duration-200">
                    <i class="fas fa-user-plus text-green-600 text-xl mr-3"></i>
                    <span class="text-gray-700">Add Principal</span>
                </a>
                <a href="school_images.php" class="flex items-center p-4 bg-indigo-50 rounded-lg hover:bg-indigo-100 transition-colors duration-200">
                    <i class="fas fa-images text-indigo-600 text-xl mr-3"></i>
                    <span class="text-gray-700">School Images</span>
                </a>
                <a href="reports.php" class="flex items-center p-4 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors duration-200">
                    <i class="fas fa-chart-bar text-purple-600 text-xl mr-3"></i>
                    <span class="text-gray-700">View Reports</span>
                </a>
                <a href="settings.php" class="flex items-center p-4 bg-yellow-50 rounded-lg hover:bg-yellow-100 transition-colors duration-200">
                    <i class="fas fa-cog text-yellow-600 text-xl mr-3"></i>
                    <span class="text-gray-700">System Settings</span>
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Add Chart.js for any charts we might want to add -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<?php require_once '../../components/footer.php'; ?> 