<?php
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is super admin
if ($_SESSION['role'] !== 'super_admin') {
    header('Location: /src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $name = $_POST['name'] ?? '';
                $address = $_POST['address'] ?? '';
                $contact = $_POST['contact'] ?? '';
                $email = $_POST['email'] ?? '';
                $principal_id = !empty($_POST['principal_id']) ? $_POST['principal_id'] : null;

                if (!empty($name) && !empty($address)) {
                    try {
                        $query = "INSERT INTO schools (name, address, contact_number, email, principal_id) 
                                 VALUES (:name, :address, :contact, :email, :principal_id)";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':name', $name);
                        $stmt->bindParam(':address', $address);
                        $stmt->bindParam(':contact', $contact);
                        $stmt->bindParam(':email', $email);
                        
                        if ($principal_id === null) {
                            $stmt->bindValue(':principal_id', null, PDO::PARAM_NULL);
                        } else {
                            $stmt->bindParam(':principal_id', $principal_id);
                        }
                        
                        $stmt->execute();
                        $success = "School added successfully!";
                    } catch (Exception $e) {
                        $error = "Error adding school: " . $e->getMessage();
                    }
                }
                break;

            case 'edit':
                $id = $_POST['id'] ?? '';
                $name = $_POST['name'] ?? '';
                $address = $_POST['address'] ?? '';
                $contact = $_POST['contact'] ?? '';
                $email = $_POST['email'] ?? '';
                $principal_id = !empty($_POST['principal_id']) ? $_POST['principal_id'] : null;

                if (!empty($id) && !empty($name) && !empty($address)) {
                    try {
                        $query = "UPDATE schools SET name = :name, address = :address, 
                                 contact_number = :contact, email = :email, principal_id = :principal_id 
                                 WHERE id = :id";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':id', $id);
                        $stmt->bindParam(':name', $name);
                        $stmt->bindParam(':address', $address);
                        $stmt->bindParam(':contact', $contact);
                        $stmt->bindParam(':email', $email);
                        
                        if ($principal_id === null) {
                            $stmt->bindValue(':principal_id', null, PDO::PARAM_NULL);
                        } else {
                            $stmt->bindParam(':principal_id', $principal_id);
                        }
                        
                        $stmt->execute();
                        $success = "School updated successfully!";
                    } catch (Exception $e) {
                        $error = "Error updating school: " . $e->getMessage();
                    }
                }
                break;

            case 'delete':
                $id = $_POST['id'] ?? '';
                if (!empty($id)) {
                    try {
                        // Start transaction
                        $db->beginTransaction();

                        // Delete related records first
                        $query = "DELETE FROM teachers WHERE school_id = :id";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':id', $id);
                        $stmt->execute();

                        $query = "DELETE FROM classes WHERE school_id = :id";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':id', $id);
                        $stmt->execute();

                        // Finally delete the school
                        $query = "DELETE FROM schools WHERE id = :id";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':id', $id);
                        $stmt->execute();

                        $db->commit();
                        $success = "School deleted successfully!";
                    } catch (Exception $e) {
                        $db->rollBack();
                        $error = "Error deleting school: " . $e->getMessage();
                    }
                }
                break;
        }
    }
}

// Fetch all schools with principal information
$query = "SELECT s.*, u.username as principal_name 
          FROM schools s 
          LEFT JOIN users u ON s.principal_id = u.id 
          ORDER BY s.name";
$stmt = $db->query($query);
$schools = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch all principals for dropdown
$query = "SELECT id, username FROM users WHERE role = 'principal' ORDER BY username";
$stmt = $db->query($query);
$principals = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- Page Content -->
<div class="container mx-auto px-4">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Schools Management</h1>
        <button onclick="showAddModal()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200">
            <i class="fas fa-plus mr-2"></i>Add New School
        </button>
    </div>

    <?php if (isset($success)): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline"><?php echo $success; ?></span>
        </div>
    <?php endif; ?>

    <?php if (isset($error)): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline"><?php echo $error; ?></span>
        </div>
    <?php endif; ?>

    <!-- Schools Table -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">School Name</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Address</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contact</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Principal</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php foreach ($schools as $school): ?>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($school['name']); ?></div>
                            <div class="text-sm text-gray-500"><?php echo htmlspecialchars($school['email']); ?></div>
                        </td>
                        <td class="px-6 py-4">
                            <div class="text-sm text-gray-900"><?php echo htmlspecialchars($school['address']); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900"><?php echo htmlspecialchars($school['contact_number']); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900"><?php echo htmlspecialchars($school['principal_name'] ?? 'Not Assigned'); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <button onclick="showEditModal(<?php echo htmlspecialchars(json_encode($school)); ?>)" 
                                    class="text-blue-600 hover:text-blue-900 mr-3">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button onclick="confirmDelete(<?php echo $school['id']; ?>)" 
                                    class="text-red-600 hover:text-red-900">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add School Modal -->
<div id="addModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Add New School</h3>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="add">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700">School Name</label>
                    <input type="text" name="name" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Address</label>
                    <textarea name="address" required rows="3"
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"></textarea>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Contact Number</label>
                    <input type="tel" name="contact"
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Email</label>
                    <input type="email" name="email"
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Principal</label>
                    <select name="principal_id"
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Select Principal</option>
                        <?php foreach ($principals as $principal): ?>
                            <option value="<?php echo $principal['id']; ?>">
                                <?php echo htmlspecialchars($principal['username']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="hideAddModal()"
                        class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                        Cancel
                    </button>
                    <button type="submit"
                        class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">
                        Add School
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit School Modal -->
<div id="editModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Edit School</h3>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="edit_id">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700">School Name</label>
                    <input type="text" name="name" id="edit_name" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Address</label>
                    <textarea name="address" id="edit_address" required rows="3"
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"></textarea>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Contact Number</label>
                    <input type="tel" name="contact" id="edit_contact"
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Email</label>
                    <input type="email" name="email" id="edit_email"
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Principal</label>
                    <select name="principal_id" id="edit_principal_id"
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Select Principal</option>
                        <?php foreach ($principals as $principal): ?>
                            <option value="<?php echo $principal['id']; ?>">
                                <?php echo htmlspecialchars($principal['username']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="hideEditModal()"
                        class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                        Cancel
                    </button>
                    <button type="submit"
                        class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">
                        Update School
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div id="deleteModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Confirm Delete</h3>
            <p class="text-sm text-gray-500">Are you sure you want to delete this school? This action cannot be undone.</p>
            
            <form method="POST" class="mt-4">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" id="delete_id">
                
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="hideDeleteModal()"
                        class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                        Cancel
                    </button>
                    <button type="submit"
                        class="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700">
                        Delete
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Modal functions
    function showAddModal() {
        document.getElementById('addModal').classList.remove('hidden');
    }

    function hideAddModal() {
        document.getElementById('addModal').classList.add('hidden');
    }

    function showEditModal(school) {
        document.getElementById('edit_id').value = school.id;
        document.getElementById('edit_name').value = school.name;
        document.getElementById('edit_address').value = school.address;
        document.getElementById('edit_contact').value = school.contact_number;
        document.getElementById('edit_email').value = school.email;
        document.getElementById('edit_principal_id').value = school.principal_id;
        
        document.getElementById('editModal').classList.remove('hidden');
    }

    function hideEditModal() {
        document.getElementById('editModal').classList.add('hidden');
    }

    function confirmDelete(id) {
        document.getElementById('delete_id').value = id;
        document.getElementById('deleteModal').classList.remove('hidden');
    }

    function hideDeleteModal() {
        document.getElementById('deleteModal').classList.add('hidden');
    }

    // Close modals when clicking outside
    window.onclick = function(event) {
        if (event.target.classList.contains('fixed')) {
            event.target.classList.add('hidden');
        }
    }
</script>

<?php require_once '../../components/footer.php'; ?> 