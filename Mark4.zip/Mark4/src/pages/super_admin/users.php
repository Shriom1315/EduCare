<?php
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is super admin
if ($_SESSION['role'] !== 'super_admin') {
    header('Location: /src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $username = $_POST['username'] ?? '';
                $email = $_POST['email'] ?? '';
                $password = $_POST['password'] ?? '';
                $role = $_POST['role'] ?? '';
                $school_id = $_POST['school_id'] ?? null;

                if (!empty($username) && !empty($email) && !empty($password) && !empty($role)) {
                    // Hash password
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                    // Start transaction
                    $db->beginTransaction();

                    try {
                        // Insert into users table
                        $query = "INSERT INTO users (username, email, password, role) 
                                 VALUES (:username, :email, :password, :role)";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':username', $username);
                        $stmt->bindParam(':email', $email);
                        $stmt->bindParam(':password', $hashed_password);
                        $stmt->bindParam(':role', $role);
                        $stmt->execute();

                        $user_id = $db->lastInsertId();

                        // If role is principal, update school's principal_id
                        if ($role === 'principal' && !empty($school_id)) {
                            $query = "UPDATE schools SET principal_id = :user_id WHERE id = :school_id";
                            $stmt = $db->prepare($query);
                            $stmt->bindParam(':user_id', $user_id);
                            $stmt->bindParam(':school_id', $school_id);
                            $stmt->execute();
                        }

                        // If role is teacher, insert into teachers table
                        if ($role === 'teacher' && !empty($school_id)) {
                            $query = "INSERT INTO teachers (user_id, school_id, qualification, specialization, joining_date) 
                                     VALUES (:user_id, :school_id, :qualification, :specialization, :joining_date)";
                            $stmt = $db->prepare($query);
                            $stmt->bindParam(':user_id', $user_id);
                            $stmt->bindParam(':school_id', $school_id);
                            $stmt->bindParam(':qualification', $_POST['qualification']);
                            $stmt->bindParam(':specialization', $_POST['specialization']);
                            $stmt->bindParam(':joining_date', $_POST['joining_date']);
                            $stmt->execute();
                        }

                        $db->commit();
                        $success = "User added successfully!";
                    } catch (Exception $e) {
                        $db->rollBack();
                        $error = "Error adding user: " . $e->getMessage();
                    }
                }
                break;

            case 'edit':
                $id = $_POST['id'] ?? '';
                $username = $_POST['username'] ?? '';
                $email = $_POST['email'] ?? '';
                $role = $_POST['role'] ?? '';
                $school_id = $_POST['school_id'] ?? null;

                if (!empty($id) && !empty($username) && !empty($email) && !empty($role)) {
                    // Start transaction
                    $db->beginTransaction();

                    try {
                        // Update users table
                        $query = "UPDATE users SET username = :username, email = :email, role = :role WHERE id = :id";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':id', $id);
                        $stmt->bindParam(':username', $username);
                        $stmt->bindParam(':email', $email);
                        $stmt->bindParam(':role', $role);
                        $stmt->execute();

                        // If password is provided, update it
                        if (!empty($_POST['password'])) {
                            $hashed_password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                            $query = "UPDATE users SET password = :password WHERE id = :id";
                            $stmt = $db->prepare($query);
                            $stmt->bindParam(':id', $id);
                            $stmt->bindParam(':password', $hashed_password);
                            $stmt->execute();
                        }

                        // Update school's principal_id if role is principal
                        if ($role === 'principal' && !empty($school_id)) {
                            $query = "UPDATE schools SET principal_id = :user_id WHERE id = :school_id";
                            $stmt = $db->prepare($query);
                            $stmt->bindParam(':user_id', $id);
                            $stmt->bindParam(':school_id', $school_id);
                            $stmt->execute();
                        }

                        // Update teacher information if role is teacher
                        if ($role === 'teacher' && !empty($school_id)) {
                            $query = "UPDATE teachers SET school_id = :school_id, qualification = :qualification, 
                                     specialization = :specialization, joining_date = :joining_date 
                                     WHERE user_id = :user_id";
                            $stmt = $db->prepare($query);
                            $stmt->bindParam(':user_id', $id);
                            $stmt->bindParam(':school_id', $school_id);
                            $stmt->bindParam(':qualification', $_POST['qualification']);
                            $stmt->bindParam(':specialization', $_POST['specialization']);
                            $stmt->bindParam(':joining_date', $_POST['joining_date']);
                            $stmt->execute();
                        }

                        $db->commit();
                        $success = "User updated successfully!";
                    } catch (Exception $e) {
                        $db->rollBack();
                        $error = "Error updating user: " . $e->getMessage();
                    }
                }
                break;

            case 'delete':
                $id = $_POST['id'] ?? '';
                if (!empty($id)) {
                    // Start transaction
                    $db->beginTransaction();

                    try {
                        // Delete from role-specific tables first
                        $query = "DELETE FROM teachers WHERE user_id = :id";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':id', $id);
                        $stmt->execute();

                        // Remove principal_id from schools
                        $query = "UPDATE schools SET principal_id = NULL WHERE principal_id = :id";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':id', $id);
                        $stmt->execute();

                        // Finally, delete from users table
                        $query = "DELETE FROM users WHERE id = :id";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':id', $id);
                        $stmt->execute();

                        $db->commit();
                        $success = "User deleted successfully!";
                    } catch (Exception $e) {
                        $db->rollBack();
                        $error = "Error deleting user: " . $e->getMessage();
                    }
                }
                break;
        }
    }
}

// Fetch all users with their roles and school information
$query = "SELECT u.*, s.name as school_name, t.qualification, t.specialization, t.joining_date 
          FROM users u 
          LEFT JOIN schools s ON u.id = s.principal_id 
          LEFT JOIN teachers t ON u.id = t.user_id 
          WHERE u.role IN ('principal', 'teacher') 
          ORDER BY u.role, u.username";
$stmt = $db->query($query);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch all schools for dropdown
$query = "SELECT id, name FROM schools ORDER BY name";
$stmt = $db->query($query);
$schools = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- Page Content -->
<div class="container mx-auto px-4">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Users Management</h1>
        <button onclick="showAddModal()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200">
            <i class="fas fa-plus mr-2"></i>Add New User
        </button>
    </div>

    <?php if (isset($success)): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline"><?php echo $success; ?></span>
        </div>
    <?php endif; ?>

    <?php if (isset($error)): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline"><?php echo $error; ?></span>
        </div>
    <?php endif; ?>

    <!-- Users Table -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Role</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">School</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Details</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($user['username']); ?></div>
                            <div class="text-sm text-gray-500"><?php echo htmlspecialchars($user['email']); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                       <?php echo $user['role'] === 'principal' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'; ?>">
                                <?php echo ucfirst($user['role']); ?>
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900"><?php echo htmlspecialchars($user['school_name'] ?? 'Not Assigned'); ?></div>
                        </td>
                        <td class="px-6 py-4">
                            <?php if ($user['role'] === 'teacher'): ?>
                                <div class="text-sm text-gray-900">Qualification: <?php echo htmlspecialchars($user['qualification'] ?? 'N/A'); ?></div>
                                <div class="text-sm text-gray-500">Specialization: <?php echo htmlspecialchars($user['specialization'] ?? 'N/A'); ?></div>
                                <div class="text-sm text-gray-500">Joined: <?php echo $user['joining_date'] ? date('M d, Y', strtotime($user['joining_date'])) : 'N/A'; ?></div>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <button onclick="showEditModal(<?php echo htmlspecialchars(json_encode($user)); ?>)" 
                                    class="text-blue-600 hover:text-blue-900 mr-3">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button onclick="confirmDelete(<?php echo $user['id']; ?>)" 
                                    class="text-red-600 hover:text-red-900">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add User Modal -->
<div id="addModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Add New User</h3>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="add">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700">Username</label>
                    <input type="text" name="username" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Email</label>
                    <input type="email" name="email" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Password</label>
                    <input type="password" name="password" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Role</label>
                    <select name="role" required onchange="toggleTeacherFields(this.value)"
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Select Role</option>
                        <option value="principal">Principal</option>
                        <option value="teacher">Teacher</option>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">School</label>
                    <select name="school_id" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Select School</option>
                        <?php foreach ($schools as $school): ?>
                            <option value="<?php echo $school['id']; ?>">
                                <?php echo htmlspecialchars($school['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Teacher-specific fields -->
                <div id="teacherFields" class="hidden space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Qualification</label>
                        <input type="text" name="qualification"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Specialization</label>
                        <input type="text" name="specialization"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Joining Date</label>
                        <input type="date" name="joining_date"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                    </div>
                </div>

                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="hideAddModal()"
                        class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                        Cancel
                    </button>
                    <button type="submit"
                        class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">
                        Add User
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit User Modal -->
<div id="editModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Edit User</h3>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="edit_id">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700">Username</label>
                    <input type="text" name="username" id="edit_username" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Email</label>
                    <input type="email" name="email" id="edit_email" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">New Password (leave blank to keep current)</label>
                    <input type="password" name="password"
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Role</label>
                    <select name="role" id="edit_role" required onchange="toggleTeacherFields(this.value)"
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Select Role</option>
                        <option value="principal">Principal</option>
                        <option value="teacher">Teacher</option>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">School</label>
                    <select name="school_id" id="edit_school_id" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Select School</option>
                        <?php foreach ($schools as $school): ?>
                            <option value="<?php echo $school['id']; ?>">
                                <?php echo htmlspecialchars($school['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Teacher-specific fields -->
                <div id="editTeacherFields" class="hidden space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Qualification</label>
                        <input type="text" name="qualification" id="edit_qualification"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Specialization</label>
                        <input type="text" name="specialization" id="edit_specialization"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Joining Date</label>
                        <input type="date" name="joining_date" id="edit_joining_date"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                    </div>
                </div>

                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="hideEditModal()"
                        class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                        Cancel
                    </button>
                    <button type="submit"
                        class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">
                        Update User
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div id="deleteModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Confirm Delete</h3>
            <p class="text-sm text-gray-500">Are you sure you want to delete this user? This action cannot be undone.</p>
            
            <form method="POST" class="mt-4">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" id="delete_id">
                
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="hideDeleteModal()"
                        class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                        Cancel
                    </button>
                    <button type="submit"
                        class="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700">
                        Delete
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Modal functions
    function showAddModal() {
        document.getElementById('addModal').classList.remove('hidden');
    }

    function hideAddModal() {
        document.getElementById('addModal').classList.add('hidden');
    }

    function showEditModal(user) {
        document.getElementById('edit_id').value = user.id;
        document.getElementById('edit_username').value = user.username;
        document.getElementById('edit_email').value = user.email;
        document.getElementById('edit_role').value = user.role;
        document.getElementById('edit_school_id').value = user.school_id;
        
        if (user.role === 'teacher') {
            document.getElementById('edit_qualification').value = user.qualification || '';
            document.getElementById('edit_specialization').value = user.specialization || '';
            document.getElementById('edit_joining_date').value = user.joining_date || '';
            document.getElementById('editTeacherFields').classList.remove('hidden');
        } else {
            document.getElementById('editTeacherFields').classList.add('hidden');
        }
        
        document.getElementById('editModal').classList.remove('hidden');
    }

    function hideEditModal() {
        document.getElementById('editModal').classList.add('hidden');
    }

    function confirmDelete(id) {
        document.getElementById('delete_id').value = id;
        document.getElementById('deleteModal').classList.remove('hidden');
    }

    function hideDeleteModal() {
        document.getElementById('deleteModal').classList.add('hidden');
    }

    function toggleTeacherFields(role) {
        const teacherFields = document.getElementById('teacherFields');
        const editTeacherFields = document.getElementById('editTeacherFields');
        
        if (role === 'teacher') {
            teacherFields.classList.remove('hidden');
            editTeacherFields.classList.remove('hidden');
        } else {
            teacherFields.classList.add('hidden');
            editTeacherFields.classList.add('hidden');
        }
    }

    // Close modals when clicking outside
    window.onclick = function(event) {
        if (event.target.classList.contains('fixed')) {
            event.target.classList.add('hidden');
        }
    }
</script>

<?php require_once '../../components/footer.php'; ?> 