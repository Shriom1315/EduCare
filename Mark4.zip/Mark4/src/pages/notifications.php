<?php
require_once '../config/database.php';
require_once '../models/Notification.php';
require_once '../components/header.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: /Mark4/src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();
$notification = new Notification($db);

// Handle mark as read action
if (isset($_POST['mark_read'])) {
    $notification_id = $_POST['notification_id'];
    $notification->markAsRead($notification_id, $_SESSION['user_id']);
}

// Handle mark all as read action
if (isset($_POST['mark_all_read'])) {
    $notification->markAllAsRead($_SESSION['user_id']);
}

// Get notifications for the current user
$notifications = $notification->getNotifications($_SESSION['user_id'], 50); // Show last 50 notifications
$unread_count = $notification->getUnreadCount($_SESSION['user_id']);
?>

<!-- Page Content -->
<div class="container mx-auto px-4 py-6">
    <div class="max-w-4xl mx-auto">
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div class="p-6">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-2xl font-bold text-gray-900">
                        Notifications
                        <?php if ($unread_count > 0): ?>
                            <span class="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                                <?php echo $unread_count; ?> new
                            </span>
                        <?php endif; ?>
                    </h2>
                    <?php if ($unread_count > 0): ?>
                        <form method="POST" class="inline">
                            <button type="submit" name="mark_all_read" 
                                class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-indigo-600 bg-indigo-100 hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                <i class="fas fa-check-double mr-2"></i>
                                Mark all as read
                            </button>
                        </form>
                    <?php endif; ?>
                </div>

                <?php if (empty($notifications)): ?>
                    <div class="text-center py-8">
                        <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 mb-4">
                            <i class="fas fa-bell text-gray-400 text-2xl"></i>
                        </div>
                        <p class="text-gray-500">No notifications yet</p>
                    </div>
                <?php else: ?>
                    <div class="space-y-4">
                        <?php foreach ($notifications as $notif): ?>
                            <div class="<?php echo $notif['is_read'] ? 'bg-white' : 'bg-blue-50'; ?> p-4 rounded-lg border <?php echo $notif['is_read'] ? 'border-gray-200' : 'border-blue-200'; ?>">
                                <div class="flex items-start">
                                    <div class="flex-shrink-0">
                                        <?php if (!$notif['is_read']): ?>
                                            <span class="inline-block w-2 h-2 bg-blue-600 rounded-full"></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="ml-3 flex-1">
                                        <div class="flex items-center justify-between">
                                            <p class="text-sm font-medium text-gray-900">
                                                <?php echo htmlspecialchars($notif['title']); ?>
                                            </p>
                                            <div class="ml-2 flex-shrink-0 flex">
                                                <?php if (!$notif['is_read']): ?>
                                                    <form method="POST" class="inline">
                                                        <input type="hidden" name="notification_id" value="<?php echo $notif['id']; ?>">
                                                        <button type="submit" name="mark_read" 
                                                            class="inline-flex items-center px-2 py-1 border border-transparent text-xs font-medium rounded text-indigo-600 hover:text-indigo-500 focus:outline-none">
                                                            <i class="fas fa-check mr-1"></i>
                                                            Mark as read
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <p class="mt-1 text-sm text-gray-600">
                                            <?php echo htmlspecialchars($notif['message']); ?>
                                        </p>
                                        <p class="mt-2 text-xs text-gray-400">
                                            <?php echo date('F j, Y, g:i a', strtotime($notif['created_at'])); ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once '../components/footer.php'; ?> 