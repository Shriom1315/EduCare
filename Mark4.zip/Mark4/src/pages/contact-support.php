<?php
require_once '../config/database.php';
require_once '../components/header.php';

// Initialize variables
$name = $email = $subject = $message = '';
$success_message = $error_message = '';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form inputs
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $subject = $_POST['subject'] ?? '';
    $message = $_POST['message'] ?? '';
    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
    $role = isset($_SESSION['role']) ? $_SESSION['role'] : 'guest';
    
    // Simple validation
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $error_message = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Please enter a valid email address.";
    } else {
        try {
            // Connect to database
            $db = new Database();
            $conn = $db->getConnection();
            
            // Check if support_requests table exists
            $table_exists = false;
            try {
                $check_table = $conn->query("SHOW TABLES LIKE 'support_requests'");
                $table_exists = $check_table->rowCount() > 0;
            } catch (PDOException $e) {
                // Table doesn't exist
            }
            
            // Create table if it doesn't exist
            if (!$table_exists) {
                $create_table_sql = "CREATE TABLE IF NOT EXISTS support_requests (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    user_id INT,
                    user_role VARCHAR(20),
                    name VARCHAR(100) NOT NULL,
                    email VARCHAR(100) NOT NULL,
                    subject VARCHAR(200) NOT NULL,
                    message TEXT NOT NULL,
                    status ENUM('new', 'in_progress', 'resolved') DEFAULT 'new',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                )";
                $conn->exec($create_table_sql);
            }
            
            // Insert support request to database
            $query = "INSERT INTO support_requests (user_id, user_role, name, email, subject, message, status) 
                     VALUES (:user_id, :role, :name, :email, :subject, :message, 'new')";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':role', $role);
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':subject', $subject);
            $stmt->bindParam(':message', $message);
            $stmt->execute();
            
            // For logging purposes
            error_log("Support request submitted by {$email}");
            
            $success_message = "Thank you for contacting us! We'll respond to your inquiry as soon as possible.";
            
            // Clear form fields after submission
            $name = $email = $subject = $message = '';
        } catch (PDOException $e) {
            $error_message = "Error submitting your request: " . $e->getMessage();
            error_log("Support request error: " . $e->getMessage());
        }
    }
}
?>

<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto">
        <h1 class="text-3xl font-bold text-gray-800 mb-6">Contact Support</h1>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <!-- Contact Information -->
            <div class="md:col-span-1">
                <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                    <h2 class="text-xl font-semibold text-gray-800 mb-4">Contact Information</h2>
                    
                    <div class="space-y-4">
                        <div class="flex items-start">
                            <div class="flex-shrink-0 mt-1">
                                <i class="fas fa-envelope text-blue-600"></i>
                            </div>
                            <div class="ml-3">
                                <p class="text-sm font-medium text-gray-900">Email</p>
                                <p class="text-sm text-gray-600" style="word-break: break-all;">support@schoolmanagementsystem.com</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start">
                            <div class="flex-shrink-0 mt-1">
                                <i class="fas fa-phone text-blue-600"></i>
                            </div>
                            <div class="ml-3">
                                <p class="text-sm font-medium text-gray-900">Phone</p>
                                <p class="text-sm text-gray-600">+1-234-567-8900</p>
                                <p class="text-sm text-gray-500">Monday-Friday, 9AM-5PM</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start">
                            <div class="flex-shrink-0 mt-1">
                                <i class="fas fa-map-marker-alt text-blue-600"></i>
                            </div>
                            <div class="ml-3">
                                <p class="text-sm font-medium text-gray-900">Address</p>
                                <p class="text-sm text-gray-600">123 Education Street<br>Learning City, 54321</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-semibold text-gray-800 mb-4">Help Resources</h2>
                    
                    <ul class="space-y-3">
                        <li>
                            <a href="#" class="flex items-center text-blue-600 hover:text-blue-800">
                                <i class="fas fa-book mr-2"></i>
                                <span>Documentation</span>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="flex items-center text-blue-600 hover:text-blue-800">
                                <i class="fas fa-question-circle mr-2"></i>
                                <span>FAQ</span>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="flex items-center text-blue-600 hover:text-blue-800">
                                <i class="fas fa-video mr-2"></i>
                                <span>Video Tutorials</span>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="flex items-center text-blue-600 hover:text-blue-800">
                                <i class="fas fa-comments mr-2"></i>
                                <span>Community Forum</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Contact Form -->
            <div class="md:col-span-2">
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-semibold text-gray-800 mb-4">Send a Message</h2>
                    
                    <?php if (!empty($success_message)): ?>
                        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
                            <p><?php echo $success_message; ?></p>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($error_message)): ?>
                        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
                            <p><?php echo $error_message; ?></p>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" class="space-y-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label for="name" class="block text-sm font-medium text-gray-700 mb-1">Name</label>
                                <input type="text" name="name" id="name" value="<?php echo htmlspecialchars($name); ?>" required
                                    class="w-full px-3 py-2 border border-gray-300 rounded text-gray-700"
                                    style="border: 1px solid #ccc; border-radius: 4px; padding: 8px 12px; width: 100%;">
                            </div>
                            
                            <div>
                                <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                                <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($email); ?>" required
                                    class="w-full px-3 py-2 border border-gray-300 rounded text-gray-700"
                                    style="border: 1px solid #ccc; border-radius: 4px; padding: 8px 12px; width: 100%;">
                            </div>
                        </div>
                        
                        <div>
                            <label for="subject" class="block text-sm font-medium text-gray-700 mb-1">Subject</label>
                            <input type="text" name="subject" id="subject" value="<?php echo htmlspecialchars($subject); ?>" required
                                class="w-full px-3 py-2 border border-gray-300 rounded text-gray-700"
                                style="border: 1px solid #ccc; border-radius: 4px; padding: 8px 12px; width: 100%;">
                        </div>
                        
                        <div>
                            <label for="message" class="block text-sm font-medium text-gray-700 mb-1">Message</label>
                            <textarea name="message" id="message" rows="6" required
                                class="w-full px-3 py-2 border border-gray-300 rounded text-gray-700"
                                style="border: 1px solid #ccc; border-radius: 4px; padding: 8px 12px; width: 100%;"><?php echo htmlspecialchars($message); ?></textarea>
                        </div>
                        
                        <div>
                            <button type="submit" 
                                class="w-full flex justify-center py-2 px-4 border border-transparent rounded text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
                                style="background-color: #2563eb; color: white; padding: 10px 15px; border-radius: 4px; border: none; cursor: pointer; width: 100%; display: flex; justify-content: center; align-items: center;">
                                <i class="fas fa-paper-plane mr-2"></i> Send Message
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../components/footer.php'; ?> 