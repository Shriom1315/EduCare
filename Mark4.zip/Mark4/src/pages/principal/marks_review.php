<?php
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is principal
if ($_SESSION['role'] !== 'principal') {
    header('Location: /Mark4/src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get school information
$query = "SELECT s.* FROM schools s WHERE s.principal_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$school = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$school) {
    header('Location: /Mark4/src/pages/login.php');
    exit();
}

// Initialize variables
$exam_id = $_GET['exam_id'] ?? null;
$subject_id = $_GET['subject_id'] ?? null;
$success_message = $_SESSION['success_message'] ?? '';
$error_message = $_SESSION['error_message'] ?? '';

// Clear session messages
unset($_SESSION['success_message']);
unset($_SESSION['error_message']);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['approve_all'])) {
        try {
            $class_id = $_POST['class_id'];
            
            // Update all pending marks to approved
            $query = "UPDATE marks SET status = 'approved' 
                     WHERE exam_id = :exam_id 
                     AND subject_id = :subject_id 
                     AND class_id = :class_id 
                     AND status = 'pending_principal'";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':exam_id', $exam_id);
            $stmt->bindParam(':subject_id', $subject_id);
            $stmt->bindParam(':class_id', $class_id);
            $stmt->execute();
            
            $_SESSION['success_message'] = "All marks have been approved!";
            header("Location: marks_review.php?exam_id=$exam_id&subject_id=$subject_id");
            exit();
        } catch (PDOException $e) {
            $error_message = "Database error: " . $e->getMessage();
        }
    } else if (isset($_POST['reject_marks'])) {
        try {
            $class_id = $_POST['class_id'];
            $rejection_reason = $_POST['rejection_reason'] ?? '';
            
            if (empty($rejection_reason)) {
                $error_message = "Please provide a reason for rejection.";
            } else {
                // Update marks status to rejected and store reason
                $query = "UPDATE marks SET status = 'rejected', rejection_reason = :rejection_reason 
                         WHERE exam_id = :exam_id 
                         AND subject_id = :subject_id 
                         AND class_id = :class_id 
                         AND status = 'pending_principal'";
                $stmt = $db->prepare($query);
                $stmt->bindParam(':rejection_reason', $rejection_reason);
                $stmt->bindParam(':exam_id', $exam_id);
                $stmt->bindParam(':subject_id', $subject_id);
                $stmt->bindParam(':class_id', $class_id);
                $stmt->execute();
                
                $_SESSION['success_message'] = "Marks have been rejected and sent back for revision.";
                header("Location: marks_review.php?exam_id=$exam_id&subject_id=$subject_id");
                exit();
            }
        } catch (PDOException $e) {
            $error_message = "Database error: " . $e->getMessage();
        }
    }
}

// Get exam and subject details
$exam = null;
$subject = null;
if ($exam_id && $subject_id) {
    try {
        // Get exam details
        $query = "SELECT e.*, c.class_name 
                 FROM exams e 
                 LEFT JOIN classes c ON e.class_id = c.id 
                 WHERE e.id = :exam_id AND e.school_id = :school_id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':exam_id', $exam_id);
        $stmt->bindParam(':school_id', $school['id']);
        $stmt->execute();
        $exam = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Get subject details
        $query = "SELECT * FROM subjects WHERE id = :subject_id AND school_id = :school_id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':subject_id', $subject_id);
        $stmt->bindParam(':school_id', $school['id']);
        $stmt->execute();
        $subject = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $error_message = "Error loading details: " . $e->getMessage();
    }
}

// Get classes for this exam/subject combination
$classes = [];
if ($exam_id && $subject_id) {
    try {
        // Query to get all classes that have marks for this exam/subject combination
        $query = "SELECT DISTINCT c.id, c.class_name, 
                 (SELECT COUNT(*) FROM marks m WHERE m.class_id = c.id AND m.exam_id = :exam_id AND m.subject_id = :subject_id) as marks_count,
                 (SELECT COUNT(*) FROM marks m WHERE m.class_id = c.id AND m.exam_id = :exam_id AND m.subject_id = :subject_id AND m.status = 'pending_principal') as pending_count,
                 (SELECT COUNT(*) FROM marks m WHERE m.class_id = c.id AND m.exam_id = :exam_id AND m.subject_id = :subject_id AND m.status = 'approved') as approved_count,
                 (SELECT COUNT(*) FROM marks m WHERE m.class_id = c.id AND m.exam_id = :exam_id AND m.subject_id = :subject_id AND m.status = 'rejected') as rejected_count,
                 (SELECT u.username FROM users u JOIN teachers t ON u.id = t.user_id WHERE t.user_id = c.class_teacher_id) as class_teacher_name
                 FROM classes c
                 JOIN marks m ON c.id = m.class_id
                 WHERE c.school_id = :school_id
                 AND m.exam_id = :exam_id 
                 AND m.subject_id = :subject_id
                 ORDER BY c.class_name";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':exam_id', $exam_id);
        $stmt->bindParam(':subject_id', $subject_id);
        $stmt->bindParam(':school_id', $school['id']);
        $stmt->execute();
        $classes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $error_message = "Error loading classes: " . $e->getMessage();
    }
}

// Get marks for specific class if selected
$marks = [];
$selected_class = null;
if (isset($_GET['class_id']) && !empty($_GET['class_id'])) {
    $class_id = $_GET['class_id'];
    
    try {
        // Get class details
        $query = "SELECT c.*, u.username as class_teacher_name 
                 FROM classes c 
                 LEFT JOIN users u ON c.class_teacher_id = u.id 
                 WHERE c.id = :class_id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':class_id', $class_id);
        $stmt->execute();
        $selected_class = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Get student marks
        $query = "SELECT m.*, s.roll_number, u.username as student_name, 
                 u2.username as entered_by_name, u3.username as approved_by_name
                 FROM marks m
                 JOIN students s ON m.student_id = s.id
                 JOIN users u ON s.user_id = u.id
                 LEFT JOIN users u2 ON m.entered_by = u2.id
                 LEFT JOIN users u3 ON m.approved_by = u3.id
                 WHERE m.class_id = :class_id
                 AND m.exam_id = :exam_id
                 AND m.subject_id = :subject_id
                 ORDER BY s.roll_number";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':class_id', $class_id);
        $stmt->bindParam(':exam_id', $exam_id);
        $stmt->bindParam(':subject_id', $subject_id);
        $stmt->execute();
        $marks = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $error_message = "Error loading marks: " . $e->getMessage();
    }
}
?>

<!-- Page Content -->
<div class="container mx-auto px-4 py-6">
    <!-- Breadcrumb and Actions -->
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-2xl font-bold text-gray-800">Review Marks</h1>
            <?php if ($exam && $subject): ?>
                <div class="text-sm text-gray-600 mt-1">
                    Exam: <?php echo htmlspecialchars($exam['name']); ?> | 
                    Subject: <?php echo htmlspecialchars($subject['name']); ?>
                </div>
            <?php endif; ?>
        </div>
        
        <a href="exams.php?action=view&id=<?php echo $exam_id; ?>" class="px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700 transition-colors">
            <i class="fas fa-arrow-left mr-1"></i> Back to Exam
        </a>
    </div>
    
    <!-- Messages -->
    <?php if ($success_message): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
            <p><?php echo $success_message; ?></p>
        </div>
    <?php endif; ?>
    
    <?php if ($error_message): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
            <p><?php echo $error_message; ?></p>
        </div>
    <?php endif; ?>
    
    <?php if (!$exam || !$subject): ?>
        <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-4" role="alert">
            <p>Invalid exam or subject selected.</p>
        </div>
    <?php else: ?>
        <!-- Classes List -->
        <?php if (empty($classes)): ?>
            <div class="bg-white rounded-lg shadow-md p-6 text-center">
                <p class="text-gray-500">No marks have been entered for this exam and subject yet.</p>
            </div>
        <?php else: ?>
            <div class="bg-white rounded-lg shadow-md overflow-hidden mb-6">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h2 class="text-lg font-semibold text-gray-800">Classes with Marks</h2>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Class</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Class Teacher</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Marks</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($classes as $class): ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($class['class_name']); ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-500"><?php echo htmlspecialchars($class['class_teacher_name'] ?? 'Not assigned'); ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-500"><?php echo $class['marks_count']; ?> total</div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if ($class['pending_count'] > 0): ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                                <?php echo $class['pending_count']; ?> pending approval
                                            </span>
                                        <?php elseif ($class['approved_count'] == $class['marks_count']): ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                All approved
                                            </span>
                                        <?php elseif ($class['rejected_count'] > 0): ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                                <?php echo $class['rejected_count']; ?> rejected
                                            </span>
                                        <?php else: ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                                                Various statuses
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                        <a href="?exam_id=<?php echo $exam_id; ?>&subject_id=<?php echo $subject_id; ?>&class_id=<?php echo $class['id']; ?>" class="text-blue-600 hover:text-blue-900">
                                            View Marks
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- Marks for Selected Class -->
        <?php if ($selected_class && !empty($marks)): ?>
            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                    <h2 class="text-lg font-semibold text-gray-800">
                        Marks for Class: <?php echo htmlspecialchars($selected_class['class_name']); ?>
                    </h2>
                    
                    <?php 
                    // Check if any marks are pending
                    $pending_exists = false;
                    foreach ($marks as $mark) {
                        if ($mark['status'] === 'pending_principal') {
                            $pending_exists = true;
                            break;
                        }
                    }
                    
                    if ($pending_exists):
                    ?>
                    <div class="flex space-x-2">
                        <form method="POST" class="inline">
                            <input type="hidden" name="class_id" value="<?php echo $selected_class['id']; ?>">
                            <button type="submit" name="approve_all" class="px-3 py-1 bg-green-600 text-white rounded text-sm hover:bg-green-700">
                                Approve All
                            </button>
                        </form>
                        
                        <button type="button" onclick="showRejectForm()" class="px-3 py-1 bg-red-600 text-white rounded text-sm hover:bg-red-700">
                            Reject
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Rejection Form (Hidden by default) -->
                <div id="rejection-form" class="hidden px-6 py-4 bg-gray-50 border-b border-gray-200">
                    <form method="POST">
                        <input type="hidden" name="class_id" value="<?php echo $selected_class['id']; ?>">
                        <div class="mb-4">
                            <label for="rejection_reason" class="block text-sm font-medium text-gray-700">Reason for Rejection</label>
                            <textarea id="rejection_reason" name="rejection_reason" rows="3" required
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"></textarea>
                        </div>
                        <div class="flex justify-end">
                            <button type="button" onclick="hideRejectForm()" class="mr-2 px-3 py-1 bg-gray-500 text-white rounded text-sm hover:bg-gray-600">
                                Cancel
                            </button>
                            <button type="submit" name="reject_marks" class="px-3 py-1 bg-red-600 text-white rounded text-sm hover:bg-red-700">
                                Confirm Rejection
                            </button>
                        </div>
                    </form>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Roll No.</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Student Name</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Marks</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Entered By</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Approved By</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Remarks</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($marks as $mark): ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900"><?php echo htmlspecialchars($mark['roll_number']); ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($mark['student_name']); ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900"><?php echo $mark['marks']; ?> / <?php echo $mark['max_marks']; ?></div>
                                        <div class="text-xs text-gray-500">
                                            <?php echo round(($mark['marks'] / $mark['max_marks']) * 100, 1); ?>%
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if ($mark['status'] === 'pending'): ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                                                Pending Teacher Approval
                                            </span>
                                        <?php elseif ($mark['status'] === 'pending_principal'): ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                                Pending Your Approval
                                            </span>
                                        <?php elseif ($mark['status'] === 'approved'): ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                Approved
                                            </span>
                                        <?php elseif ($mark['status'] === 'rejected'): ?>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                                Rejected
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-500">
                                            <?php echo htmlspecialchars($mark['entered_by_name'] ?? 'N/A'); ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-500">
                                            <?php echo htmlspecialchars($mark['approved_by_name'] ?? 'N/A'); ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="text-sm text-gray-500">
                                            <?php if (!empty($mark['remarks'])): ?>
                                                <?php echo htmlspecialchars($mark['remarks']); ?>
                                            <?php endif; ?>
                                            
                                            <?php if (!empty($mark['rejection_reason'])): ?>
                                                <div class="mt-1 text-xs text-red-600">
                                                    <strong>Rejection reason:</strong> <?php echo htmlspecialchars($mark['rejection_reason']); ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php elseif (isset($_GET['class_id'])): ?>
            <div class="bg-white rounded-lg shadow-md p-6 text-center">
                <p class="text-gray-500">No marks found for the selected class.</p>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<script>
function showRejectForm() {
    document.getElementById('rejection-form').classList.remove('hidden');
}

function hideRejectForm() {
    document.getElementById('rejection-form').classList.add('hidden');
}
</script>

<?php require_once '../../components/footer.php'; ?> 