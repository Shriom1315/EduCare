<?php
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is principal
if ($_SESSION['role'] !== 'principal') {
    header('Location: /src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get school information
$query = "SELECT s.* FROM schools s WHERE s.principal_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$school = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$school) {
    header('Location: /src/pages/login.php');
    exit();
}

// Fetch statistics
$stats = [
    'teachers' => 0,
    'students' => 0,
    'classes' => 0
];

// Get total teachers
$query = "SELECT COUNT(*) as count FROM teachers t 
          JOIN users u ON t.user_id = u.id 
          WHERE t.school_id = :school_id 
          AND u.role = 'teacher'";
$stmt = $db->prepare($query);
$stmt->bindParam(':school_id', $school['id']);
$stmt->execute();
$stats['teachers'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

// Get total students
$query = "SELECT COUNT(*) as count FROM students WHERE school_id = :school_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':school_id', $school['id']);
$stmt->execute();
$stats['students'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

// Get total classes
$query = "SELECT COUNT(*) as count FROM classes WHERE school_id = :school_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':school_id', $school['id']);
$stmt->execute();
$stats['classes'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

// Get recent notices
$query = "SELECT n.*, u.username as created_by_name 
          FROM notices n 
          JOIN users u ON n.created_by = u.id 
          WHERE n.school_id = :school_id 
          ORDER BY n.created_at DESC LIMIT 5";
$stmt = $db->prepare($query);
$stmt->bindParam(':school_id', $school['id']);
$stmt->execute();
$recent_notices = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get upcoming exams
$query = "SELECT * FROM exams 
          WHERE school_id = :school_id 
          AND start_date >= CURDATE() 
          ORDER BY start_date ASC LIMIT 5";
$stmt = $db->prepare($query);
$stmt->bindParam(':school_id', $school['id']);
$stmt->execute();
$upcoming_exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- Dashboard Content -->
<div class="container mx-auto px-4">
    <!-- Welcome Section -->
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-800">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
        <p class="text-gray-600">Principal of <?php echo htmlspecialchars($school['name']); ?></p>
    </div>

    <!-- School Images Carousel -->
    <?php require_once '../../components/image_carousel.php'; ?>

    <!-- Statistics Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <!-- Teachers Card -->
        <div class="bg-white rounded-lg shadow-md p-6 transform hover:scale-105 transition-transform duration-200">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-blue-100 text-blue-600">
                    <i class="fas fa-chalkboard-teacher text-2xl"></i>
                </div>
                <div class="ml-4">
                    <h2 class="text-gray-600 text-sm">Total Teachers</h2>
                    <p class="text-2xl font-semibold text-gray-800"><?php echo $stats['teachers']; ?></p>
                </div>
            </div>
        </div>

        <!-- Students Card -->
        <div class="bg-white rounded-lg shadow-md p-6 transform hover:scale-105 transition-transform duration-200">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-green-100 text-green-600">
                    <i class="fas fa-user-graduate text-2xl"></i>
                </div>
                <div class="ml-4">
                    <h2 class="text-gray-600 text-sm">Total Students</h2>
                    <p class="text-2xl font-semibold text-gray-800"><?php echo $stats['students']; ?></p>
                </div>
            </div>
        </div>

        <!-- Classes Card -->
        <div class="bg-white rounded-lg shadow-md p-6 transform hover:scale-105 transition-transform duration-200">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-purple-100 text-purple-600">
                    <i class="fas fa-chalkboard text-2xl"></i>
                </div>
                <div class="ml-4">
                    <h2 class="text-gray-600 text-sm">Total Classes</h2>
                    <p class="text-2xl font-semibold text-gray-800"><?php echo $stats['classes']; ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Notices and Upcoming Exams -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Recent Notices -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">Recent Notices</h2>
            <div class="space-y-4">
                <?php foreach ($recent_notices as $notice): ?>
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                            <h3 class="font-medium text-gray-800"><?php echo htmlspecialchars($notice['title']); ?></h3>
                            <p class="text-sm text-gray-600">Posted by <?php echo htmlspecialchars($notice['created_by_name']); ?></p>
                            <p class="text-sm text-gray-500"><?php echo date('M d, Y', strtotime($notice['created_at'])); ?></p>
                        </div>
                        <a href="notices.php?id=<?php echo $notice['id']; ?>" class="text-blue-600 hover:text-blue-800">
                            <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Upcoming Exams -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">Upcoming Exams</h2>
            <div class="space-y-4">
                <?php foreach ($upcoming_exams as $exam): ?>
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                            <h3 class="font-medium text-gray-800"><?php echo htmlspecialchars($exam['name']); ?></h3>
                            <p class="text-sm text-gray-600">
                                <?php echo date('M d, Y', strtotime($exam['start_date'])); ?> - 
                                <?php echo date('M d, Y', strtotime($exam['end_date'])); ?>
                            </p>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                <?php echo ucfirst($exam['status']); ?>
                            </span>
                        </div>
                        <a href="exams.php?id=<?php echo $exam['id']; ?>" class="text-blue-600 hover:text-blue-800">
                            <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="mt-8">
        <h2 class="text-xl font-semibold text-gray-800 mb-4">Quick Actions</h2>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
            <a href="teachers.php?action=add" class="flex items-center p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors duration-200">
                <i class="fas fa-user-plus text-blue-600 text-xl mr-3"></i>
                <span class="text-gray-700">Add Teacher</span>
            </a>
            <a href="students.php?action=add" class="flex items-center p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors duration-200">
                <i class="fas fa-user-plus text-green-600 text-xl mr-3"></i>
                <span class="text-gray-700">Add Student</span>
            </a>
            <a href="classes.php?action=add" class="flex items-center p-4 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors duration-200">
                <i class="fas fa-plus-circle text-purple-600 text-xl mr-3"></i>
                <span class="text-gray-700">Add Class</span>
            </a>
            <a href="notices.php?action=add" class="flex items-center p-4 bg-yellow-50 rounded-lg hover:bg-yellow-100 transition-colors duration-200">
                <i class="fas fa-bullhorn text-yellow-600 text-xl mr-3"></i>
                <span class="text-gray-700">Post Notice</span>
            </a>
        </div>
    </div>
</div>

<!-- Add Chart.js if needed for future charts -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<?php require_once '../../components/footer.php'; ?> 