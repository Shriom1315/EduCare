<?php
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is principal
if ($_SESSION['role'] !== 'principal') {
    header('Location: /src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get school information
$query = "SELECT s.* FROM schools s WHERE s.principal_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$school = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$school) {
    header('Location: /src/pages/login.php');
    exit();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $class_level = $_POST['class_level'] ?? '';
                $division = $_POST['division'] ?? '';
                $class_name = $class_level . ' - ' . $division;

                if (!empty($class_level) && !empty($division)) {
                    try {
                        // Check if class with same level and division exists
                        $check_query = "SELECT id FROM classes WHERE class_name = :class_name AND school_id = :school_id";
                        $check_stmt = $db->prepare($check_query);
                        $check_stmt->bindParam(':class_name', $class_name);
                        $check_stmt->bindParam(':school_id', $school['id']);
                        $check_stmt->execute();
                        
                        if ($check_stmt->rowCount() > 0) {
                            $error = "A class with this level and division already exists!";
                        } else {
                            $query = "INSERT INTO classes (class_name, school_id) 
                                     VALUES (:class_name, :school_id)";
                            $stmt = $db->prepare($query);
                            $stmt->bindParam(':class_name', $class_name);
                            $stmt->bindParam(':school_id', $school['id']);
                            $stmt->execute();
                            $success = "Class added successfully!";
                        }
                    } catch (Exception $e) {
                        $error = "Error adding class: " . $e->getMessage();
                    }
                }
                break;

            case 'edit':
                $id = $_POST['id'] ?? '';
                $class_level = $_POST['class_level'] ?? '';
                $division = $_POST['division'] ?? '';
                $class_name = $class_level . ' - ' . $division;

                if (!empty($id) && !empty($class_level) && !empty($division)) {
                    try {
                        // Check if class with same level and division exists (excluding current class)
                        $check_query = "SELECT id FROM classes WHERE class_name = :class_name AND school_id = :school_id AND id != :id";
                        $check_stmt = $db->prepare($check_query);
                        $check_stmt->bindParam(':class_name', $class_name);
                        $check_stmt->bindParam(':school_id', $school['id']);
                        $check_stmt->bindParam(':id', $id);
                        $check_stmt->execute();
                        
                        if ($check_stmt->rowCount() > 0) {
                            $error = "A class with this level and division already exists!";
                        } else {
                            $query = "UPDATE classes SET class_name = :class_name 
                                     WHERE id = :id AND school_id = :school_id";
                            $stmt = $db->prepare($query);
                            $stmt->bindParam(':id', $id);
                            $stmt->bindParam(':class_name', $class_name);
                            $stmt->bindParam(':school_id', $school['id']);
                            $stmt->execute();
                            $success = "Class updated successfully!";
                        }
                    } catch (Exception $e) {
                        $error = "Error updating class: " . $e->getMessage();
                    }
                }
                break;

            case 'delete':
                $id = $_POST['id'] ?? '';
                if (!empty($id)) {
                    // Start transaction
                    $db->beginTransaction();
                    
                    try {
                        // First update students to remove class association
                        $query = "UPDATE students SET class_id = NULL WHERE class_id = :class_id";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':class_id', $id);
                        $stmt->execute();
                        
                        // Now delete the class
                        $query = "DELETE FROM classes WHERE id = :id AND school_id = :school_id";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':id', $id);
                        $stmt->bindParam(':school_id', $school['id']);
                        $stmt->execute();
                        
                        $db->commit();
                        $success = "Class deleted successfully!";
                    } catch (Exception $e) {
                        $db->rollBack();
                        $error = "Error deleting class: " . $e->getMessage();
                    }
                }
                break;
        }
    }
}

// Fetch all classes for this school
$query = "SELECT c.*, 
          (SELECT COUNT(*) FROM students s WHERE s.class_id = c.id) as student_count 
          FROM classes c 
          WHERE c.school_id = :school_id 
          ORDER BY c.class_name";
$stmt = $db->prepare($query);
$stmt->bindParam(':school_id', $school['id']);
$stmt->execute();
$classes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- Page Content -->
<div class="container mx-auto px-4">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Classes Management</h1>
        <button onclick="showAddModal()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200">
            <i class="fas fa-plus mr-2"></i>Add New Class
        </button>
    </div>

    <?php if (isset($success)): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline"><?php echo $success; ?></span>
        </div>
    <?php endif; ?>

    <?php if (isset($error)): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline"><?php echo $error; ?></span>
        </div>
    <?php endif; ?>

    <!-- Classes Grid -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php foreach ($classes as $class): ?>
            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                <div class="bg-gray-50 px-4 py-3 border-b">
                    <div class="flex justify-between items-center">
                        <h2 class="text-lg font-medium text-gray-900"><?php echo htmlspecialchars($class['class_name']); ?></h2>
                        <div class="flex space-x-2">
                            <button onclick="showEditModal(<?php echo htmlspecialchars(json_encode($class)); ?>)" 
                                    class="text-blue-600 hover:text-blue-900">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button onclick="confirmDelete(<?php echo $class['id']; ?>)" 
                                    class="text-red-600 hover:text-red-900">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="p-4">
                    <div class="flex items-center">
                        <i class="fas fa-users text-gray-500 mr-2"></i>
                        <span class="text-sm text-gray-700">Students: <?php echo $class['student_count']; ?></span>
                    </div>
                </div>
                <div class="bg-gray-50 px-4 py-3 border-t">
                    <a href="students.php?class_id=<?php echo $class['id']; ?>" class="text-blue-600 hover:text-blue-800 text-sm">
                        View Students <i class="fas fa-arrow-right ml-1"></i>
                    </a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Add Class Modal -->
<div id="addModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Add New Class</h3>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="add">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700">Class Level</label>
                    <select name="class_level" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Select Class Level</option>
                        <option value="Nursery">Nursery</option>
                        <option value="LKG">LKG</option>
                        <option value="UKG">UKG</option>
                        <?php for($i = 1; $i <= 12; $i++): ?>
                            <option value="Class <?php echo $i; ?>">Class <?php echo $i; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Division</label>
                    <select name="division" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Select Division</option>
                        <?php foreach(range('A', 'F') as $division): ?>
                            <option value="<?php echo $division; ?>">Division <?php echo $division; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="hideAddModal()"
                        class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                        Cancel
                    </button>
                    <button type="submit"
                        class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">
                        Add Class
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Class Modal -->
<div id="editModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Edit Class</h3>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="edit_id">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700">Class Level</label>
                    <select name="class_level" id="edit_class_level" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Select Class Level</option>
                        <option value="Nursery">Nursery</option>
                        <option value="LKG">LKG</option>
                        <option value="UKG">UKG</option>
                        <?php for($i = 1; $i <= 12; $i++): ?>
                            <option value="Class <?php echo $i; ?>">Class <?php echo $i; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Division</label>
                    <select name="division" id="edit_division" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Select Division</option>
                        <?php foreach(range('A', 'F') as $division): ?>
                            <option value="<?php echo $division; ?>">Division <?php echo $division; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="hideEditModal()"
                        class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                        Cancel
                    </button>
                    <button type="submit"
                        class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">
                        Update Class
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div id="deleteModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Confirm Delete</h3>
            <p class="text-sm text-gray-500">Are you sure you want to delete this class? This action cannot be undone.</p>
            
            <form method="POST" class="mt-4">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" id="delete_id">
                
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="hideDeleteModal()"
                        class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                        Cancel
                    </button>
                    <button type="submit"
                        class="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700">
                        Delete
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function showAddModal() {
        document.getElementById('addModal').classList.remove('hidden');
    }

    function hideAddModal() {
        document.getElementById('addModal').classList.add('hidden');
    }

    function showEditModal(classData) {
        document.getElementById('edit_id').value = classData.id;
        
        // Split class name into level and division
        const [level, division] = classData.class_name.split(' - ');
        document.getElementById('edit_class_level').value = level;
        document.getElementById('edit_division').value = division;
        
        document.getElementById('editModal').classList.remove('hidden');
    }

    function hideEditModal() {
        document.getElementById('editModal').classList.add('hidden');
    }

    function confirmDelete(id) {
        document.getElementById('delete_id').value = id;
        document.getElementById('deleteModal').classList.remove('hidden');
    }

    function hideDeleteModal() {
        document.getElementById('deleteModal').classList.add('hidden');
    }

    // Close modals when clicking outside
    window.onclick = function(event) {
        if (event.target.classList.contains('fixed')) {
            event.target.classList.add('hidden');
        }
    }
</script>

<?php require_once '../../components/footer.php'; ?> 