<?php
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is principal
if ($_SESSION['role'] !== 'principal') {
    header('Location: /src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get school information
$query = "SELECT s.* FROM schools s WHERE s.principal_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$school = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$school) {
    header('Location: /src/pages/login.php');
    exit();
}

// Get images for this school
$query = "SELECT * FROM school_images 
          WHERE school_id = :school_id 
          ORDER BY display_order, created_at DESC";
$stmt = $db->prepare($query);
$stmt->bindParam(':school_id', $school['id']);
$stmt->execute();
$images = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container mx-auto px-4 py-6">
    <h1 class="text-2xl font-bold mb-6">Image Debug Information</h1>
    
    <div class="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 class="text-xl font-semibold mb-4">School Information</h2>
        <p><strong>School ID:</strong> <?php echo $school['id']; ?></p>
        <p><strong>School Name:</strong> <?php echo htmlspecialchars($school['name']); ?></p>
    </div>
    
    <div class="bg-white rounded-lg shadow-md p-6">
        <h2 class="text-xl font-semibold mb-4">Images (<?php echo count($images); ?>)</h2>
        
        <?php if (empty($images)): ?>
            <p class="text-gray-500">No images found for this school.</p>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Image Path</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Full URL</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Caption</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Order</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Preview</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($images as $image): ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo $image['id']; ?></td>
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo htmlspecialchars($image['image_path']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap">/Mark4<?php echo htmlspecialchars($image['image_path']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo htmlspecialchars($image['caption'] ?? ''); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo $image['display_order']; ?></td>
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo $image['status']; ?></td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <img src="/Mark4<?php echo htmlspecialchars($image['image_path']); ?>" 
                                         alt="Preview" 
                                         class="h-20 w-auto object-cover">
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="bg-white rounded-lg shadow-md p-6 mt-6">
        <h2 class="text-xl font-semibold mb-4">File System Check</h2>
        
        <?php
        // Check if uploads directory exists
        $upload_dir = $_SERVER['DOCUMENT_ROOT'] . '/Mark4/uploads/school_images/';
        $dir_exists = is_dir($upload_dir);
        ?>
        
        <p><strong>Upload Directory:</strong> <?php echo $upload_dir; ?></p>
        <p><strong>Directory Exists:</strong> <?php echo $dir_exists ? 'Yes' : 'No'; ?></p>
        
        <?php if ($dir_exists): ?>
            <h3 class="text-lg font-medium mt-4 mb-2">Files in Directory:</h3>
            <ul class="list-disc pl-5">
                <?php
                $files = scandir($upload_dir);
                $image_files = array_filter($files, function($file) {
                    return !in_array($file, ['.', '..']) && !is_dir($upload_dir . $file);
                });
                
                if (empty($image_files)): ?>
                    <li class="text-gray-500">No files found in the directory.</li>
                <?php else:
                    foreach ($image_files as $file): ?>
                        <li><?php echo htmlspecialchars($file); ?></li>
                    <?php endforeach;
                endif; ?>
            </ul>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../../components/footer.php'; ?> 