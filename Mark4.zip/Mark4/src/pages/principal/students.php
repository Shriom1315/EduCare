<?php
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is principal
if ($_SESSION['role'] !== 'principal') {
    header('Location: /src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get school information
$query = "SELECT s.* FROM schools s WHERE s.principal_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$school = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$school) {
    header('Location: /src/pages/login.php');
    exit();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $username = $_POST['username'] ?? '';
                $email = $_POST['email'] ?? '';
                $password = $_POST['password'] ?? '';
                $class_id = $_POST['class_id'] ?? null;
                $roll_number = $_POST['roll_number'] ?? '';
                $parent_name = $_POST['parent_name'] ?? '';

                if (!empty($username) && !empty($email) && !empty($password)) {
                    // Start transaction
                    $db->beginTransaction();

                    try {
                        // Hash password
                        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                        // Insert into users table
                        $query = "INSERT INTO users (username, email, password, role) 
                                 VALUES (:username, :email, :password, 'student')";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':username', $username);
                        $stmt->bindParam(':email', $email);
                        $stmt->bindParam(':password', $hashed_password);
                        $stmt->execute();

                        $user_id = $db->lastInsertId();

                        // Insert into students table
                        $query = "INSERT INTO students (user_id, school_id, class_id, roll_number, parent_name) 
                                 VALUES (:user_id, :school_id, :class_id, :roll_number, :parent_name)";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':user_id', $user_id);
                        $stmt->bindParam(':school_id', $school['id']);
                        $stmt->bindParam(':class_id', $class_id);
                        $stmt->bindParam(':roll_number', $roll_number);
                        $stmt->bindParam(':parent_name', $parent_name);
                        $stmt->execute();

                        $db->commit();
                        $success = "Student added successfully!";
                    } catch (Exception $e) {
                        $db->rollBack();
                        $error = "Error adding student: " . $e->getMessage();
                    }
                }
                break;

            case 'edit':
                $id = $_POST['id'] ?? '';
                $username = $_POST['username'] ?? '';
                $email = $_POST['email'] ?? '';
                $class_id = $_POST['class_id'] ?? null;
                $roll_number = $_POST['roll_number'] ?? '';
                $parent_name = $_POST['parent_name'] ?? '';

                if (!empty($id) && !empty($username) && !empty($email)) {
                    // Start transaction
                    $db->beginTransaction();

                    try {
                        // Update users table
                        $query = "UPDATE users SET username = :username, email = :email WHERE id = :id";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':id', $id);
                        $stmt->bindParam(':username', $username);
                        $stmt->bindParam(':email', $email);
                        $stmt->execute();

                        // If password is provided, update it
                        if (!empty($_POST['password'])) {
                            $hashed_password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                            $query = "UPDATE users SET password = :password WHERE id = :id";
                            $stmt = $db->prepare($query);
                            $stmt->bindParam(':id', $id);
                            $stmt->bindParam(':password', $hashed_password);
                            $stmt->execute();
                        }

                        // Update students table
                        $query = "UPDATE students SET class_id = :class_id, roll_number = :roll_number, 
                                 parent_name = :parent_name WHERE user_id = :user_id";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':user_id', $id);
                        $stmt->bindParam(':class_id', $class_id);
                        $stmt->bindParam(':roll_number', $roll_number);
                        $stmt->bindParam(':parent_name', $parent_name);
                        $stmt->execute();

                        $db->commit();
                        $success = "Student updated successfully!";
                    } catch (Exception $e) {
                        $db->rollBack();
                        $error = "Error updating student: " . $e->getMessage();
                    }
                }
                break;

            case 'delete':
                $id = $_POST['id'] ?? '';
                if (!empty($id)) {
                    // Start transaction
                    $db->beginTransaction();

                    try {
                        // Delete from students table first
                        $query = "DELETE FROM students WHERE user_id = :id";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':id', $id);
                        $stmt->execute();

                        // Then delete from users table
                        $query = "DELETE FROM users WHERE id = :id";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':id', $id);
                        $stmt->execute();

                        $db->commit();
                        $success = "Student deleted successfully!";
                    } catch (Exception $e) {
                        $db->rollBack();
                        $error = "Error deleting student: " . $e->getMessage();
                    }
                }
                break;

            case 'bulk_upload':
                $class_id = $_POST['class_id'] ?? null;
                $student_file = $_FILES['student_file'] ?? null;

                if (!empty($class_id) && !empty($student_file['tmp_name'])) {
                    // Start transaction
                    $db->beginTransaction();

                    try {
                        // Handle file upload
                        $file_tmp = $student_file['tmp_name'];
                        $file_name = $student_file['name'];
                        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

                        // Initialize variables to store data
                        $students_data = [];

                        // Only process CSV files
                        if ($file_ext !== 'csv') {
                            throw new Exception("Only CSV files are supported. Please convert your Excel file to CSV format.");
                        }

                        // Handle CSV file
                        if (($handle = fopen($file_tmp, "r")) !== FALSE) {
                            // Skip header row
                            $header = fgetcsv($handle);
                            
                            // Read data rows
                            while (($data = fgetcsv($handle)) !== FALSE) {
                                if (count($data) >= 5) { // Ensure we have all required fields
                                    $students_data[] = array_combine(['username', 'email', 'password', 'roll_number', 'parent_name'], $data);
                                }
                            }
                            fclose($handle);
                        }

                        // Process each student
                        $success_count = 0;
                        $error_messages = [];

                        foreach ($students_data as $student) {
                            try {
                                // Validate required fields
                                if (empty($student['username']) || empty($student['email']) || empty($student['password'])) {
                                    throw new Exception("Missing required fields for student: " . $student['username']);
                                }

                                // Check if username or email already exists
                                $check_query = "SELECT id FROM users WHERE username = :username OR email = :email";
                                $check_stmt = $db->prepare($check_query);
                                $check_stmt->bindParam(':username', $student['username']);
                                $check_stmt->bindParam(':email', $student['email']);
                                $check_stmt->execute();

                                if ($check_stmt->rowCount() > 0) {
                                    throw new Exception("Username or email already exists: " . $student['username']);
                                }

                                // Hash password
                                $hashed_password = password_hash($student['password'], PASSWORD_DEFAULT);

                                // Insert into users table
                                $query = "INSERT INTO users (username, email, password, role) 
                                         VALUES (:username, :email, :password, 'student')";
                                $stmt = $db->prepare($query);
                                $stmt->bindParam(':username', $student['username']);
                                $stmt->bindParam(':email', $student['email']);
                                $stmt->bindParam(':password', $hashed_password);
                                $stmt->execute();

                                $user_id = $db->lastInsertId();

                                // Insert into students table
                                $query = "INSERT INTO students (user_id, school_id, class_id, roll_number, parent_name) 
                                         VALUES (:user_id, :school_id, :class_id, :roll_number, :parent_name)";
                                $stmt = $db->prepare($query);
                                $stmt->bindParam(':user_id', $user_id);
                                $stmt->bindParam(':school_id', $school['id']);
                                $stmt->bindParam(':class_id', $class_id);
                                $stmt->bindParam(':roll_number', $student['roll_number']);
                                $stmt->bindParam(':parent_name', $student['parent_name']);
                                $stmt->execute();

                                $success_count++;
                            } catch (Exception $e) {
                                $error_messages[] = $e->getMessage();
                            }
                        }

                        if ($success_count > 0) {
                            $db->commit();
                            $success = "Successfully added $success_count students.";
                            if (!empty($error_messages)) {
                                $error = "Some students could not be added:\n" . implode("\n", $error_messages);
                            }
                        } else {
                            throw new Exception("No students were added. Errors:\n" . implode("\n", $error_messages));
                        }
                    } catch (Exception $e) {
                        $db->rollBack();
                        $error = "Error uploading students: " . $e->getMessage();
                    }
                }
                break;
        }
    }
}

// Get class filter from URL
$filter_class_id = $_GET['class_id'] ?? null;

// Fetch all classes for this school for dropdown
$query = "SELECT id, class_name as name FROM classes WHERE school_id = :school_id ORDER BY class_name";
$stmt = $db->prepare($query);
$stmt->bindParam(':school_id', $school['id']);
$stmt->execute();
$classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch all students for this school
$query = "SELECT u.*, s.class_id, s.roll_number, s.parent_name,
          c.class_name as class_name 
          FROM users u 
          JOIN students s ON u.id = s.user_id 
          LEFT JOIN classes c ON s.class_id = c.id 
          WHERE s.school_id = :school_id";

if ($filter_class_id) {
    $query .= " AND s.class_id = :class_id";
}

$query .= " ORDER BY c.class_name, s.roll_number, u.username";

$stmt = $db->prepare($query);
$stmt->bindParam(':school_id', $school['id']);
if ($filter_class_id) {
    $stmt->bindParam(':class_id', $filter_class_id);
}
$stmt->execute();
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- Page Content -->
<div class="container mx-auto px-4">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Students Management</h1>
        <div class="flex space-x-4">
            <button onclick="showBulkUploadModal()" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors duration-200">
                <i class="fas fa-file-upload mr-2"></i>Bulk Upload
            </button>
            <button onclick="showAddModal()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200">
                <i class="fas fa-plus mr-2"></i>Add New Student
            </button>
        </div>
    </div>

    <?php if (isset($success)): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline"><?php echo $success; ?></span>
        </div>
    <?php endif; ?>

    <?php if (isset($error)): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline"><?php echo $error; ?></span>
        </div>
    <?php endif; ?>

    <!-- Filter by Class -->
    <div class="mb-6">
        <label class="block text-sm font-medium text-gray-700 mb-2">Filter by Class</label>
        <select onchange="window.location.href='students.php' + (this.value ? '?class_id=' + this.value : '')"
                class="mt-1 block w-full md:w-64 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
            <option value="">All Classes</option>
            <?php foreach ($classes as $class): ?>
                <option value="<?php echo $class['id']; ?>" <?php echo $filter_class_id == $class['id'] ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($class['name']); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <!-- Students Table -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Student</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Class</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Roll Number</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Parent Name</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php foreach ($students as $student): ?>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($student['username']); ?></div>
                            <div class="text-sm text-gray-500"><?php echo htmlspecialchars($student['email']); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900"><?php echo htmlspecialchars($student['class_name'] ?? 'Not Assigned'); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900"><?php echo htmlspecialchars($student['roll_number']); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900"><?php echo htmlspecialchars($student['parent_name']); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <button onclick="showEditModal(<?php echo htmlspecialchars(json_encode($student)); ?>)" 
                                    class="text-blue-600 hover:text-blue-900 mr-3">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button onclick="confirmDelete(<?php echo $student['id']; ?>)" 
                                    class="text-red-600 hover:text-red-900">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add Student Modal -->
<div id="addModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Add New Student</h3>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="add">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700">Username</label>
                    <input type="text" name="username" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Email</label>
                    <input type="email" name="email" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Password</label>
                    <input type="password" name="password" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Class</label>
                    <select name="class_id"
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Select Class</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['id']; ?>">
                                <?php echo htmlspecialchars($class['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Roll Number</label>
                    <input type="text" name="roll_number" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Parent Name</label>
                    <input type="text" name="parent_name" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="hideAddModal()"
                        class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                        Cancel
                    </button>
                    <button type="submit"
                        class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">
                        Add Student
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Student Modal -->
<div id="editModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Edit Student</h3>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="edit_id">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700">Username</label>
                    <input type="text" name="username" id="edit_username" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Email</label>
                    <input type="email" name="email" id="edit_email" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">New Password (leave blank to keep current)</label>
                    <input type="password" name="password"
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Class</label>
                    <select name="class_id" id="edit_class_id"
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Select Class</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['id']; ?>">
                                <?php echo htmlspecialchars($class['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Roll Number</label>
                    <input type="text" name="roll_number" id="edit_roll_number" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Parent Name</label>
                    <input type="text" name="parent_name" id="edit_parent_name" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="hideEditModal()"
                        class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                        Cancel
                    </button>
                    <button type="submit"
                        class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">
                        Update Student
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div id="deleteModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Confirm Delete</h3>
            <p class="text-sm text-gray-500">Are you sure you want to delete this student? This action cannot be undone.</p>
            
            <form method="POST" class="mt-4">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" id="delete_id">
                
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="hideDeleteModal()"
                        class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                        Cancel
                    </button>
                    <button type="submit"
                        class="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700">
                        Delete
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Bulk Upload Modal -->
<div id="bulkUploadModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Bulk Upload Students</h3>
            <form method="POST" enctype="multipart/form-data" class="space-y-4">
                <input type="hidden" name="action" value="bulk_upload">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700">Select Class</label>
                    <select name="class_id" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Select Class</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['id']; ?>">
                                <?php echo htmlspecialchars($class['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Upload Excel/CSV File</label>
                    <input type="file" name="student_file" accept=".xlsx,.xls,.csv" required
                        class="mt-1 block w-full text-sm text-gray-500
                        file:mr-4 file:py-2 file:px-4
                        file:rounded-md file:border-0
                        file:text-sm file:font-medium
                        file:bg-blue-50 file:text-blue-700
                        hover:file:bg-blue-100">
                    <p class="mt-1 text-sm text-gray-500">
                        Download template: 
                        <a href="download_template.php" class="text-blue-600 hover:text-blue-800">Excel</a> | 
                        <a href="download_template.php?type=csv" class="text-blue-600 hover:text-blue-800">CSV</a>
                    </p>
                </div>

                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="hideBulkUploadModal()"
                        class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                        Cancel
                    </button>
                    <button type="submit"
                        class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">
                        Upload
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Modal functions
    function showAddModal() {
        document.getElementById('addModal').classList.remove('hidden');
    }

    function hideAddModal() {
        document.getElementById('addModal').classList.add('hidden');
    }

    function showEditModal(student) {
        document.getElementById('edit_id').value = student.id;
        document.getElementById('edit_username').value = student.username;
        document.getElementById('edit_email').value = student.email;
        document.getElementById('edit_class_id').value = student.class_id || '';
        document.getElementById('edit_roll_number').value = student.roll_number;
        document.getElementById('edit_parent_name').value = student.parent_name;
        
        document.getElementById('editModal').classList.remove('hidden');
    }

    function hideEditModal() {
        document.getElementById('editModal').classList.add('hidden');
    }

    function confirmDelete(id) {
        document.getElementById('delete_id').value = id;
        document.getElementById('deleteModal').classList.remove('hidden');
    }

    function hideDeleteModal() {
        document.getElementById('deleteModal').classList.add('hidden');
    }

    function showBulkUploadModal() {
        document.getElementById('bulkUploadModal').classList.remove('hidden');
    }

    function hideBulkUploadModal() {
        document.getElementById('bulkUploadModal').classList.add('hidden');
    }

    // Close modals when clicking outside
    window.onclick = function(event) {
        if (event.target.classList.contains('fixed')) {
            event.target.classList.add('hidden');
        }
    }
</script>

<?php require_once '../../components/footer.php'; ?> 