<?php
ob_start();
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is principal
if ($_SESSION['role'] !== 'principal') {
    header('Location: /src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get school information
$query = "SELECT s.* FROM schools s WHERE s.principal_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$school = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$school) {
    header('Location: /src/pages/login.php');
    exit();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'assign':
                $teacher_id = $_POST['teacher_id'] ?? '';
                $subject_ids = $_POST['subject_ids'] ?? [];
                
                if (!empty($teacher_id) && !empty($subject_ids)) {
                    try {
                        $db->beginTransaction();
                        
                        // First, remove all existing subject assignments for this teacher
                        $delete_query = "DELETE FROM teacher_subjects WHERE teacher_id = :teacher_id";
                        $delete_stmt = $db->prepare($delete_query);
                        $delete_stmt->bindParam(':teacher_id', $teacher_id);
                        $delete_stmt->execute();
                        
                        // Then, insert new assignments
                        $insert_query = "INSERT INTO teacher_subjects (teacher_id, subject_id) VALUES (:teacher_id, :subject_id)";
                        $insert_stmt = $db->prepare($insert_query);
                        
                        foreach ($subject_ids as $subject_id) {
                            $insert_stmt->bindParam(':teacher_id', $teacher_id);
                            $insert_stmt->bindParam(':subject_id', $subject_id);
                            $insert_stmt->execute();
                        }
                        
                        $db->commit();
                        $_SESSION['success_message'] = "Subjects assigned successfully!";
                    } catch (PDOException $e) {
                        $db->rollBack();
                        $_SESSION['error_message'] = "Error assigning subjects: " . $e->getMessage();
                    }
                }
                break;
        }
        
        header('Location: teacher_subjects.php');
        exit();
    }
}

// Fetch all teachers for the school
try {
    $query = "SELECT t.*, u.username FROM teachers t 
              JOIN users u ON t.user_id = u.id 
              WHERE t.school_id = :school_id 
              ORDER BY u.username";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':school_id', $school['id']);
    $stmt->execute();
    $teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $teachers = [];
    $_SESSION['error_message'] = "Error loading teachers: " . $e->getMessage();
}

// Fetch all subjects
try {
    $query = "SELECT * FROM subjects WHERE school_id = :school_id ORDER BY name";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':school_id', $school['id']);
    $stmt->execute();
    $subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $subjects = [];
    $_SESSION['error_message'] = "Error loading subjects: " . $e->getMessage();
}

// Fetch assigned subjects for each teacher
$teacher_subjects = [];
try {
    $query = "SELECT teacher_id, subject_id FROM teacher_subjects";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $assignments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($assignments as $assignment) {
        if (!isset($teacher_subjects[$assignment['teacher_id']])) {
            $teacher_subjects[$assignment['teacher_id']] = [];
        }
        $teacher_subjects[$assignment['teacher_id']][] = $assignment['subject_id'];
    }
} catch (PDOException $e) {
    $_SESSION['error_message'] = "Error loading subject assignments: " . $e->getMessage();
}
?>

<!-- Page Content -->
<div class="container mx-auto px-4 py-6">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Assign Subjects to Teachers</h1>
        <a href="subjects.php" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors">
            <i class="fas fa-plus mr-1"></i> Manage Subjects
        </a>
    </div>
    
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
            <p><?php echo $_SESSION['success_message']; ?></p>
        </div>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
            <p><?php echo $_SESSION['error_message']; ?></p>
        </div>
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>
    
    <!-- Teacher Subjects Assignment Form -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <form method="POST" class="space-y-6">
            <input type="hidden" name="action" value="assign">
            
            <div>
                <label for="teacher_id" class="block text-sm font-medium text-gray-700">Select Teacher</label>
                <select id="teacher_id" name="teacher_id" required onchange="this.form.submit()"
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                    <option value="">Select a teacher</option>
                    <?php foreach ($teachers as $teacher): ?>
                        <option value="<?php echo $teacher['id']; ?>">
                            <?php echo htmlspecialchars($teacher['username']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <?php if (!empty($_POST['teacher_id'])): ?>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Select Subjects</label>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <?php foreach ($subjects as $subject): ?>
                        <div class="flex items-center">
                            <input type="checkbox" name="subject_ids[]" value="<?php echo $subject['id']; ?>"
                                <?php echo isset($teacher_subjects[$_POST['teacher_id']]) && in_array($subject['id'], $teacher_subjects[$_POST['teacher_id']]) ? 'checked' : ''; ?>
                                class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                            <label class="ml-2 block text-sm text-gray-900">
                                <?php echo htmlspecialchars($subject['name']); ?>
                            </label>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <div class="flex justify-end">
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors">
                    Save Assignments
                </button>
            </div>
            <?php endif; ?>
        </form>
    </div>
</div>

<?php require_once '../../components/footer.php'; ?>

<?php ob_end_flush(); ?> 