<?php
require_once '../../config/database.php';
session_start();

// Check if user is principal
if ($_SESSION['role'] !== 'principal') {
    header('Location: /src/pages/login.php');
    exit();
}

// Determine the file type
$type = $_GET['type'] ?? 'excel';

// Set headers based on file type
if ($type === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="student_template.csv"');
    
    // Create CSV content
    $output = fopen('php://output', 'w');
    
    // Add headers
    fputcsv($output, [
        'Username',
        'Email',
        'Password',
        'Roll Number',
        'Parent Name'
    ]);
    
    // Add sample row
    fputcsv($output, [
        'john.doe',
        'john.doe@example.com',
        'password123',
        '101',
        'Jane Doe'
    ]);
    
    fclose($output);
} else {
    // For Excel, we'll use a simple CSV that Excel can open
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="student_template.xls"');
    
    echo "Username\tEmail\tPassword\tRoll Number\tParent Name\n";
    echo "john.doe\tjohn.doe@example.com\tpassword123\t101\tJane Doe";
} 