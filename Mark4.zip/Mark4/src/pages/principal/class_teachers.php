<?php
ob_start();
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is principal
if ($_SESSION['role'] !== 'principal') {
    header('Location: /Mark4/src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get school information
$query = "SELECT s.* FROM schools s WHERE s.principal_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$school = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$school) {
    header('Location: /Mark4/src/pages/login.php');
    exit();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['assign_class_teachers'])) {
        try {
            $db->beginTransaction();
            
            $class_teachers = $_POST['class_teachers'] ?? [];
            
            foreach ($class_teachers as $class_id => $teacher_id) {
                if (empty($teacher_id)) {
                    // Remove class teacher assignment
                    $query = "UPDATE classes SET class_teacher_id = NULL WHERE id = :class_id AND school_id = :school_id";
                    $stmt = $db->prepare($query);
                    $stmt->bindParam(':class_id', $class_id);
                    $stmt->bindParam(':school_id', $school['id']);
                    $stmt->execute();
                } else {
                    // Assign class teacher
                    $query = "UPDATE classes SET class_teacher_id = :teacher_id WHERE id = :class_id AND school_id = :school_id";
                    $stmt = $db->prepare($query);
                    $stmt->bindParam(':teacher_id', $teacher_id);
                    $stmt->bindParam(':class_id', $class_id);
                    $stmt->bindParam(':school_id', $school['id']);
                    $stmt->execute();
                }
            }
            
            $db->commit();
            $_SESSION['success_message'] = "Class teachers assigned successfully!";
        } catch (PDOException $e) {
            $db->rollBack();
            $_SESSION['error_message'] = "Error assigning class teachers: " . $e->getMessage();
        }
        
        header('Location: class_teachers.php');
        exit();
    }
}

// Get all classes
try {
    $query = "SELECT c.*, u.username as class_teacher_name 
              FROM classes c 
              LEFT JOIN users u ON c.class_teacher_id = u.id 
              WHERE c.school_id = :school_id 
              ORDER BY c.class_name";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':school_id', $school['id']);
    $stmt->execute();
    $classes = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $classes = [];
    $_SESSION['error_message'] = "Error loading classes: " . $e->getMessage();
}

// Get all teachers
try {
    $query = "SELECT t.*, u.username 
              FROM teachers t 
              JOIN users u ON t.user_id = u.id 
              WHERE t.school_id = :school_id 
              ORDER BY u.username";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':school_id', $school['id']);
    $stmt->execute();
    $teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $teachers = [];
    $_SESSION['error_message'] = "Error loading teachers: " . $e->getMessage();
}

// Get success/error messages
$success_message = $_SESSION['success_message'] ?? '';
$error_message = $_SESSION['error_message'] ?? '';

// Clear session messages
unset($_SESSION['success_message']);
unset($_SESSION['error_message']);
?>

<!-- Page Content -->
<div class="container mx-auto px-4 py-6">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Assign Class Teachers</h1>
        <div>
            <a href="classes.php" class="px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700 transition-colors mr-2">
                <i class="fas fa-list mr-1"></i> Manage Classes
            </a>
            <a href="teacher_subjects.php" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors">
                <i class="fas fa-chalkboard-teacher mr-1"></i> Assign Subjects
            </a>
        </div>
    </div>
    
    <!-- Messages -->
    <?php if ($success_message): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
            <p><?php echo $success_message; ?></p>
        </div>
    <?php endif; ?>
    
    <?php if ($error_message): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
            <p><?php echo $error_message; ?></p>
        </div>
    <?php endif; ?>
    
    <!-- Class Teacher Assignment Form -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <?php if (empty($classes)): ?>
            <p class="text-center text-gray-500">No classes found. Please create classes first.</p>
        <?php elseif (empty($teachers)): ?>
            <p class="text-center text-gray-500">No teachers found. Please add teachers first.</p>
        <?php else: ?>
            <form method="POST">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Class</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Current Class Teacher</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">New Class Teacher</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($classes as $class): ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($class['class_name']); ?></div>
                                        <?php if (isset($class['section']) && !empty($class['section'])): ?>
                                            <div class="text-sm text-gray-500">Section: <?php echo htmlspecialchars($class['section']); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900">
                                            <?php echo isset($class['class_teacher_name']) ? htmlspecialchars($class['class_teacher_name']) : 'Not assigned'; ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <select name="class_teachers[<?php echo $class['id']; ?>]" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                            <option value="">-- No Class Teacher --</option>
                                            <?php foreach ($teachers as $teacher): ?>
                                                <option value="<?php echo $teacher['user_id']; ?>" <?php echo ($class['class_teacher_id'] == $teacher['user_id']) ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($teacher['username']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="mt-6 flex justify-end">
                    <button type="submit" name="assign_class_teachers" class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition-colors">
                        Save Assignments
                    </button>
                </div>
            </form>
        <?php endif; ?>
    </div>
    
    <!-- Information Box -->
    <div class="mt-6 bg-blue-50 rounded-lg p-6 border border-blue-200">
        <h2 class="text-lg font-semibold text-blue-800 mb-2">Class Teacher Responsibilities</h2>
        <ul class="list-disc pl-5 space-y-1 text-blue-700">
            <li>Review and approve marks submitted by subject teachers</li>
            <li>Monitor overall academic progress of students in their class</li>
            <li>Generate and distribute report cards to students</li>
            <li>Conduct parent-teacher meetings</li>
            <li>Handle student discipline and attendance issues</li>
        </ul>
    </div>
</div>

<?php require_once '../../components/footer.php'; ?>
<?php ob_end_flush(); ?> 