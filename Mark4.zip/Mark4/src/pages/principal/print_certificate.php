<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/config.php';
require_once '../../utils/certificate_utils.php';

// Check if user is logged in and is a principal
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'principal') {
    $_SESSION['error_message'] = "Unauthorized access. Please login as principal.";
    header('Location: ' . LOGIN_URL);
    exit();
}

// Initialize database connection
try {
    $db = new Database();
    $conn = $db->getConnection();
} catch (PDOException $e) {
    $_SESSION['error_message'] = "Database connection failed: " . $e->getMessage();
    header('Location: ' . getDashboardUrl('principal'));
    exit();
}

$principal_id = $_SESSION['user_id'];
$certificate_id = $_GET['id'] ?? null;

if (!$certificate_id) {
    $_SESSION['error_message'] = "Certificate ID is required.";
    header('Location: ' . getPageUrl('principal', 'certificates'));
    exit();
}

// Get principal's school information
try {
    $school_query = "SELECT s.id as school_id, s.name as school_name 
                    FROM schools s 
                    WHERE s.principal_id = ?";
    $stmt = $conn->prepare($school_query);
    $stmt->execute([$principal_id]);
    $school_info = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // If no direct school association, try via teachers table
    if (!$school_info) {
        $teacher_school_query = "SELECT t.school_id, s.name as school_name 
                              FROM teachers t 
                              JOIN schools s ON t.school_id = s.id 
                              WHERE t.user_id = ?";
        $stmt = $conn->prepare($teacher_school_query);
        $stmt->execute([$principal_id]);
        $school_info = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    if (!$school_info) {
        $_SESSION['error_message'] = "Principal's school information not found.";
        header('Location: ' . getDashboardUrl('principal'));
        exit();
    }
} catch (PDOException $e) {
    $_SESSION['error_message'] = "Error fetching school information: " . $e->getMessage();
    header('Location: ' . getDashboardUrl('principal'));
    exit();
}

// Get the certificate details using our utility function
$certificate = getCertificateData($conn, $certificate_id, [
    'role' => 'principal',
    'user_id' => $principal_id,
    'school_id' => $school_info['school_id']
]);

if (!$certificate) {
    $_SESSION['error_message'] = "Certificate not found, not approved, or does not belong to your school.";
    header('Location: ' . getPageUrl('principal', 'certificates'));
    exit();
}

// Render the certificate with the back URL pointing to the certificates page
renderCertificate($certificate, true, getPageUrl('principal', 'certificates')); 