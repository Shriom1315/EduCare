<?php
// Start output buffering to prevent "headers already sent" errors
ob_start();

require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is principal
if ($_SESSION['role'] !== 'principal') {
    header('Location: /Mark4/src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get school information
$query = "SELECT s.* FROM schools s WHERE s.principal_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$school = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$school) {
    header('Location: /Mark4/src/pages/login.php');
    exit();
}

// Initialize variables
$action = $_GET['action'] ?? 'list';
$exam_id = $_GET['id'] ?? null;
$success_message = $_SESSION['success_message'] ?? '';
$error_message = $_SESSION['error_message'] ?? '';

// Clear session messages
unset($_SESSION['success_message']);
unset($_SESSION['error_message']);

// Check if columns exist in exams table (used in multiple places)
$check_class_id = "SHOW COLUMNS FROM exams LIKE 'class_id'";
$class_id_exists = $db->query($check_class_id)->rowCount() > 0;

$check_description = "SHOW COLUMNS FROM exams LIKE 'description'";
$description_exists = $db->query($check_description)->rowCount() > 0;

// Process form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_exam']) || isset($_POST['update_exam'])) {
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $start_date = $_POST['start_date'] ?? '';
        $end_date = $_POST['end_date'] ?? '';
        $status = $_POST['status'] ?? 'scheduled';
        $class_id = (isset($_POST['class_id']) && $_POST['class_id'] != '') ? $_POST['class_id'] : null;
        
        // Validate input
        $errors = [];
        if (empty($name)) {
            $errors[] = "Exam name is required";
        }
        if (empty($start_date)) {
            $errors[] = "Start date is required";
        }
        if (empty($end_date)) {
            $errors[] = "End date is required";
        }
        if (strtotime($end_date) < strtotime($start_date)) {
            $errors[] = "End date must be after start date";
        }
        
        if (empty($errors)) {
            try {
                if (isset($_POST['add_exam'])) {
                    // Insert new exam
                    $fields = ['school_id', 'name', 'start_date', 'end_date', 'status'];
                    $values = [':school_id', ':name', ':start_date', ':end_date', ':status'];
                    $params = [
                        ':school_id' => $school['id'],
                        ':name' => $name,
                        ':start_date' => $start_date,
                        ':end_date' => $end_date,
                        ':status' => $status
                    ];
                    
                    if ($class_id_exists && $class_id !== null) {
                        $fields[] = 'class_id';
                        $values[] = ':class_id';
                        $params[':class_id'] = $class_id;
                    }
                    
                    if ($description_exists && !empty($description)) {
                        $fields[] = 'description';
                        $values[] = ':description';
                        $params[':description'] = $description;
                    }
                    
                    $query = "INSERT INTO exams (" . implode(", ", $fields) . ") VALUES (" . implode(", ", $values) . ")";
                    $stmt = $db->prepare($query);
                    
                    foreach ($params as $key => $value) {
                        $stmt->bindValue($key, $value);
                    }
                    
                    $stmt->execute();
                    
                    $_SESSION['success_message'] = "Exam added successfully!";
                } else {
                    // Update existing exam
                    $id = $_POST['exam_id'];
                    $sets = ['name = :name', 'start_date = :start_date', 'end_date = :end_date', 'status = :status'];
                    $params = [
                        ':name' => $name,
                        ':start_date' => $start_date,
                        ':end_date' => $end_date,
                        ':status' => $status,
                        ':id' => $id,
                        ':school_id' => $school['id']
                    ];
                    
                    if ($class_id_exists) {
                        $sets[] = 'class_id = :class_id';
                        $params[':class_id'] = $class_id;
                    }
                    
                    if ($description_exists) {
                        $sets[] = 'description = :description';
                        $params[':description'] = $description;
                    }
                    
                    $query = "UPDATE exams SET " . implode(", ", $sets) . " WHERE id = :id AND school_id = :school_id";
                    $stmt = $db->prepare($query);
                    
                    foreach ($params as $key => $value) {
                        $stmt->bindValue($key, $value);
                    }
                    
                    $stmt->execute();
                    
                    $_SESSION['success_message'] = "Exam updated successfully!";
                }
                
                header('Location: exams.php');
                exit();
            } catch (PDOException $e) {
                $error_message = "Database error: " . $e->getMessage();
            }
        } else {
            $error_message = implode("<br>", $errors);
        }
    } else if (isset($_POST['delete_exam'])) {
        $id = $_POST['exam_id'];
        try {
            // Check if there are any results associated with this exam
            $check_query = "SELECT COUNT(*) as count FROM exam_results WHERE exam_id = :exam_id";
            $check_stmt = $db->prepare($check_query);
            $check_stmt->bindParam(':exam_id', $id);
            $check_stmt->execute();
            $has_results = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'] > 0;
            
            if ($has_results) {
                $_SESSION['error_message'] = "Cannot delete exam because it has associated results.";
            } else {
                // Delete the exam
                $query = "DELETE FROM exams WHERE id = :id AND school_id = :school_id";
                $stmt = $db->prepare($query);
                $stmt->bindParam(':id', $id);
                $stmt->bindParam(':school_id', $school['id']);
                $stmt->execute();
                
                $_SESSION['success_message'] = "Exam deleted successfully!";
            }
            
            header('Location: exams.php');
            exit();
        } catch (PDOException $e) {
            $error_message = "Database error: " . $e->getMessage();
        }
    } else if (isset($_POST['action']) && $_POST['action'] === 'add_subject') {
        $subject_id = $_POST['subject_id'] ?? '';
        $teacher_id = $_POST['teacher_id'] ?? '';
        $exam_date = $_POST['exam_date'] ?? '';
        $start_time = $_POST['start_time'] ?? '';
        $end_time = $_POST['end_time'] ?? '';
        $max_marks = $_POST['max_marks'] ?? '';
        $pass_marks = $_POST['pass_marks'] ?? '';
        
        if (!empty($subject_id) && !empty($teacher_id) && !empty($exam_date) && 
            !empty($start_time) && !empty($end_time) && !empty($max_marks) && !empty($pass_marks)) {
            try {
                $query = "INSERT INTO exam_subjects (exam_id, subject_id, teacher_id, exam_date, start_time, end_time, max_marks, pass_marks) 
                         VALUES (:exam_id, :subject_id, :teacher_id, :exam_date, :start_time, :end_time, :max_marks, :pass_marks)";
                $stmt = $db->prepare($query);
                $stmt->bindParam(':exam_id', $exam_id);
                $stmt->bindParam(':subject_id', $subject_id);
                $stmt->bindParam(':teacher_id', $teacher_id);
                $stmt->bindParam(':exam_date', $exam_date);
                $stmt->bindParam(':start_time', $start_time);
                $stmt->bindParam(':end_time', $end_time);
                $stmt->bindParam(':max_marks', $max_marks);
                $stmt->bindParam(':pass_marks', $pass_marks);
                $stmt->execute();
                
                $_SESSION['success_message'] = "Subject added to exam successfully!";
                header("Location: exams.php?action=view&id=" . $exam_id);
                exit();
            } catch (PDOException $e) {
                $_SESSION['error_message'] = "Error adding subject to exam: " . $e->getMessage();
            }
        } else {
            $_SESSION['error_message'] = "All fields are required.";
        }
    }
}

// Get classes for form dropdowns
try {
    $query = "SELECT id, class_name FROM classes WHERE school_id = :school_id ORDER BY class_name";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':school_id', $school['id']);
    $stmt->execute();
    $classes = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $classes = [];
    $error_message = "Error loading classes: " . $e->getMessage();
}

// Get exam details if editing
$exam = null;
if ($exam_id && ($action === 'edit' || $action === 'view')) {
    try {
        // First check if class_id column exists in exams table
        $check_column = "SHOW COLUMNS FROM exams LIKE 'class_id'";
        $column_exists = $db->query($check_column)->rowCount() > 0;
        
        if ($column_exists) {
            // Use the original query with class_id join
            $query = "SELECT e.*, c.class_name 
                     FROM exams e 
                     LEFT JOIN classes c ON e.class_id = c.id 
                     WHERE e.id = :id AND e.school_id = :school_id";
        } else {
            // Use a modified query without class_id join
            $query = "SELECT e.* 
                     FROM exams e 
                     WHERE e.id = :id AND e.school_id = :school_id";
        }
        
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $exam_id);
        $stmt->bindParam(':school_id', $school['id']);
        $stmt->execute();
        $exam = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$exam && $action !== 'add') {
            $_SESSION['error_message'] = "Exam not found.";
            header('Location: exams.php');
            exit();
        }

        // Get exam subjects if viewing
        if ($action === 'view' && $exam) {
            $query = "SELECT es.*, s.name as subject_name, u.username as teacher_name 
                     FROM exam_subjects es 
                     JOIN subjects s ON es.subject_id = s.id 
                     JOIN teachers t ON es.teacher_id = t.user_id 
                     JOIN users u ON t.user_id = u.id 
                     WHERE es.exam_id = :exam_id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':exam_id', $exam_id);
            $stmt->execute();
            $exam_subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    } catch (PDOException $e) {
        $error_message = "Error loading exam details: " . $e->getMessage();
    }
}

// Get subjects for the school
try {
    $query = "SELECT id, name, code FROM subjects WHERE school_id = :school_id ORDER BY name";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':school_id', $school['id']);
    $stmt->execute();
    $subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $subjects = [];
    $error_message = "Error loading subjects: " . $e->getMessage();
}

// Fetch all teachers for the school
try {
    $query = "SELECT t.*, u.username FROM teachers t 
              JOIN users u ON t.user_id = u.id 
              WHERE t.school_id = :school_id 
              ORDER BY u.username";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':school_id', $school['id']);
    $stmt->execute();
    $teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $teachers = [];
    $_SESSION['error_message'] = "Error loading teachers: " . $e->getMessage();
}

// Fetch exams for listing
$exams = [];
if ($action === 'list') {
    try {
        // First check if class_id column exists in exams table
        $check_column = "SHOW COLUMNS FROM exams LIKE 'class_id'";
        $column_exists = $db->query($check_column)->rowCount() > 0;
        
        $currentDate = date('Y-m-d');
        
        if ($column_exists) {
            // Use the original query with class_id join
            $query = "SELECT e.*, c.class_name 
                    FROM exams e 
                    LEFT JOIN classes c ON e.class_id = c.id 
                    WHERE e.school_id = :school_id 
                    ORDER BY 
                        CASE 
                            WHEN e.start_date >= :current_date THEN 1 
                            WHEN e.end_date >= :current_date THEN 2 
                            ELSE 3 
                        END, 
                        e.start_date DESC";
        } else {
            // Use a modified query without class_id join
            $query = "SELECT e.* 
                    FROM exams e 
                    WHERE e.school_id = :school_id 
                    ORDER BY 
                        CASE 
                            WHEN e.start_date >= :current_date THEN 1 
                            WHEN e.end_date >= :current_date THEN 2 
                            ELSE 3 
                        END, 
                        e.start_date DESC";
        }
        
        $stmt = $db->prepare($query);
        $stmt->bindParam(':school_id', $school['id']);
        $stmt->bindParam(':current_date', $currentDate);
        $stmt->execute();
        $exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $error_message = "Error loading exams: " . $e->getMessage();
    }
}
?>

<!-- Page Content -->
<div class="container mx-auto px-4 py-6">
    <!-- Breadcrumb and Actions -->
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">
            <?php if ($action === 'add'): ?>
                Add New Exam
            <?php elseif ($action === 'edit'): ?>
                Edit Exam
            <?php elseif ($action === 'view'): ?>
                Exam Details
            <?php else: ?>
                Manage Exams
            <?php endif; ?>
        </h1>
        
        <?php if ($action === 'list'): ?>
            <a href="?action=add" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors">
                <i class="fas fa-plus mr-1"></i> Add New Exam
            </a>
        <?php else: ?>
            <a href="exams.php" class="px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700 transition-colors">
                <i class="fas fa-arrow-left mr-1"></i> Back to List
            </a>
        <?php endif; ?>
    </div>
    
    <!-- Messages -->
    <?php if ($success_message): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
            <p><?php echo $success_message; ?></p>
        </div>
    <?php endif; ?>
    
    <?php if ($error_message): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
            <p><?php echo $error_message; ?></p>
        </div>
    <?php endif; ?>
    
    <!-- Form for Add/Edit -->
    <?php if ($action === 'add' || $action === 'edit'): ?>
        <div class="bg-white rounded-lg shadow-md p-6">
            <form method="POST">
                <?php if ($action === 'edit'): ?>
                    <input type="hidden" name="exam_id" value="<?php echo $exam['id']; ?>">
                <?php endif; ?>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="mb-4">
                        <label for="name" class="block text-gray-700 font-medium mb-2">Exam Name*</label>
                        <input type="text" id="name" name="name" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" 
                            value="<?php echo isset($exam) ? htmlspecialchars($exam['name']) : ''; ?>" required>
                    </div>
                    
                    <?php if ($class_id_exists): ?>
                    <div class="mb-4">
                        <label for="class_id" class="block text-gray-700 font-medium mb-2">Class (Leave empty for all classes)</label>
                        <select id="class_id" name="class_id" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="">All Classes</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['id']; ?>" <?php echo (isset($exam) && isset($exam['class_id']) && $exam['class_id'] == $class['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($class['class_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php endif; ?>
                    
                    <div class="mb-4">
                        <label for="start_date" class="block text-gray-700 font-medium mb-2">Start Date*</label>
                        <input type="date" id="start_date" name="start_date" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" 
                            value="<?php echo isset($exam) ? $exam['start_date'] : ''; ?>" required>
                    </div>
                    
                    <div class="mb-4">
                        <label for="end_date" class="block text-gray-700 font-medium mb-2">End Date*</label>
                        <input type="date" id="end_date" name="end_date" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" 
                            value="<?php echo isset($exam) ? $exam['end_date'] : ''; ?>" required>
                    </div>
                    
                    <div class="mb-4">
                        <label for="status" class="block text-gray-700 font-medium mb-2">Status*</label>
                        <select id="status" name="status" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                            <option value="scheduled" <?php echo (isset($exam) && $exam['status'] === 'scheduled') ? 'selected' : ''; ?>>Scheduled</option>
                            <option value="ongoing" <?php echo (isset($exam) && $exam['status'] === 'ongoing') ? 'selected' : ''; ?>>Ongoing</option>
                            <option value="completed" <?php echo (isset($exam) && $exam['status'] === 'completed') ? 'selected' : ''; ?>>Completed</option>
                            <option value="cancelled" <?php echo (isset($exam) && $exam['status'] === 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </div>
                    
                    <?php if ($description_exists): ?>
                    <div class="mb-4 md:col-span-2">
                        <label for="description" class="block text-gray-700 font-medium mb-2">Description</label>
                        <textarea id="description" name="description" rows="4" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo isset($exam) ? htmlspecialchars($exam['description'] ?? '') : ''; ?></textarea>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div class="flex justify-end mt-6">
                    <button type="submit" name="<?php echo $action === 'add' ? 'add_exam' : 'update_exam'; ?>" class="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors">
                        <?php echo $action === 'add' ? 'Add Exam' : 'Update Exam'; ?>
                    </button>
                </div>
            </form>
        </div>
    
    <!-- View Exam Details -->
    <?php elseif ($action === 'view' && $exam): ?>
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="mb-4">
                    <h3 class="text-gray-600 font-medium mb-1">Exam Name</h3>
                    <p class="text-gray-800 font-semibold"><?php echo htmlspecialchars($exam['name']); ?></p>
                </div>
                
                <?php if ($class_id_exists): ?>
                <div class="mb-4">
                    <h3 class="text-gray-600 font-medium mb-1">Class</h3>
                    <p class="text-gray-800 font-semibold">
                        <?php echo isset($exam['class_id']) && $exam['class_id'] ? htmlspecialchars($exam['class_name'] ?? 'Unknown Class') : 'All Classes'; ?>
                    </p>
                </div>
                <?php endif; ?>
                
                <div class="mb-4">
                    <h3 class="text-gray-600 font-medium mb-1">Start Date</h3>
                    <p class="text-gray-800 font-semibold"><?php echo date('F j, Y', strtotime($exam['start_date'])); ?></p>
                </div>
                
                <div class="mb-4">
                    <h3 class="text-gray-600 font-medium mb-1">End Date</h3>
                    <p class="text-gray-800 font-semibold"><?php echo date('F j, Y', strtotime($exam['end_date'])); ?></p>
                </div>
                
                <div class="mb-4">
                    <h3 class="text-gray-600 font-medium mb-1">Status</h3>
                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                        <?php 
                        switch($exam['status']) {
                            case 'scheduled': echo 'bg-blue-100 text-blue-800'; break;
                            case 'ongoing': echo 'bg-green-100 text-green-800'; break;
                            case 'completed': echo 'bg-gray-100 text-gray-800'; break;
                            case 'cancelled': echo 'bg-red-100 text-red-800'; break;
                            default: echo 'bg-gray-100 text-gray-800';
                        }
                        ?>">
                        <?php echo ucfirst($exam['status']); ?>
                    </span>
                </div>
                
                <div class="mb-4">
                    <h3 class="text-gray-600 font-medium mb-1">Created At</h3>
                    <p class="text-gray-800 font-semibold"><?php echo date('F j, Y, g:i a', strtotime($exam['created_at'])); ?></p>
                </div>
                
                <?php if ($description_exists && isset($exam['description']) && !empty($exam['description'])): ?>
                <div class="mb-4 md:col-span-2">
                    <h3 class="text-gray-600 font-medium mb-1">Description</h3>
                    <p class="text-gray-800"><?php echo nl2br(htmlspecialchars($exam['description'])); ?></p>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Exam Subjects Section -->
            <div class="mt-8">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Exam Subjects</h2>
                
                <!-- Add Subject Form -->
                <form method="POST" class="mb-6 bg-gray-50 p-4 rounded-lg">
                    <input type="hidden" name="action" value="add_subject">
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="subject_id" class="block text-sm font-medium text-gray-700">Select Subject</label>
                            <select id="subject_id" name="subject_id" required
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                <option value="">Select a subject</option>
                                <?php foreach ($subjects as $subject): ?>
                                    <option value="<?php echo $subject['id']; ?>">
                                        <?php echo htmlspecialchars($subject['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div>
                            <label for="teacher_id" class="block text-sm font-medium text-gray-700">Select Teacher</label>
                            <select id="teacher_id" name="teacher_id" required
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                <option value="">Select a teacher</option>
                                <?php foreach ($teachers as $teacher): ?>
                                    <option value="<?php echo $teacher['user_id']; ?>">
                                        <?php echo htmlspecialchars($teacher['username']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div>
                            <label for="exam_date" class="block text-sm font-medium text-gray-700">Exam Date</label>
                            <input type="date" id="exam_date" name="exam_date" required
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label for="start_time" class="block text-sm font-medium text-gray-700">Start Time</label>
                            <input type="time" id="start_time" name="start_time" required
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label for="end_time" class="block text-sm font-medium text-gray-700">End Time</label>
                            <input type="time" id="end_time" name="end_time" required
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label for="max_marks" class="block text-sm font-medium text-gray-700">Maximum Marks</label>
                            <input type="number" id="max_marks" name="max_marks" required
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label for="pass_marks" class="block text-sm font-medium text-gray-700">Pass Marks</label>
                            <input type="number" id="pass_marks" name="pass_marks" required
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        </div>
                    </div>
                    
                    <div class="mt-4">
                        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors">
                            Add Subject to Exam
                        </button>
                    </div>
                </form>
                
                <!-- Subjects List -->
                <?php if (!empty($exam_subjects)): ?>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Teacher</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date & Time</th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Marks</th>
                                    <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php foreach ($exam_subjects as $subject): ?>
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($subject['subject_name']); ?></div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm text-gray-500"><?php echo htmlspecialchars($subject['teacher_name']); ?></div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm text-gray-500">
                                                <?php echo date('M j, Y', strtotime($subject['exam_date'])); ?><br>
                                                <?php echo date('h:i A', strtotime($subject['start_time'])); ?> - 
                                                <?php echo date('h:i A', strtotime($subject['end_time'])); ?>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm text-gray-500">
                                                Max: <?php echo $subject['max_marks']; ?><br>
                                                Pass: <?php echo $subject['pass_marks']; ?>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                            <a href="marks_review.php?exam_id=<?php echo $exam_id; ?>&subject_id=<?php echo $subject['subject_id']; ?>" 
                                               class="text-blue-600 hover:text-blue-900 mr-3">
                                                <i class="fas fa-eye"></i> Review Marks
                                            </a>
                                            <a href="#" onclick="confirmDeleteSubject(<?php echo $subject['id']; ?>); return false;" 
                                               class="text-red-600 hover:text-red-900">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                            <form id="delete-subject-form-<?php echo $subject['id']; ?>" method="POST" style="display: none;">
                                                <input type="hidden" name="delete_subject" value="1">
                                                <input type="hidden" name="subject_id" value="<?php echo $subject['id']; ?>">
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-gray-500 text-center py-4">No subjects added to this exam yet.</p>
                <?php endif; ?>
            </div>
            
            <div class="flex justify-end space-x-4 mt-6">
                <a href="?action=edit&id=<?php echo $exam['id']; ?>" class="px-4 py-2 bg-yellow-600 text-white rounded hover:bg-yellow-700 transition-colors">
                    <i class="fas fa-edit mr-1"></i> Edit
                </a>
                
                <button type="button" onclick="confirmDelete(<?php echo $exam['id']; ?>)" class="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors">
                    <i class="fas fa-trash mr-1"></i> Delete
                </button>
                
                <form id="delete-form-<?php echo $exam['id']; ?>" method="POST" style="display: none;">
                    <input type="hidden" name="exam_id" value="<?php echo $exam['id']; ?>">
                    <input type="hidden" name="delete_exam" value="1">
                </form>
            </div>
        </div>
    
    <!-- List All Exams -->
    <?php else: ?>
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <?php if (empty($exams)): ?>
                <div class="p-6 text-center">
                    <p class="text-gray-500">No exams found. Create your first exam by clicking the "Add New Exam" button.</p>
                </div>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Exam Name</th>
                                <?php if ($class_id_exists): ?>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Class</th>
                                <?php endif; ?>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date Range</th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($exams as $exam): ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($exam['name']); ?></div>
                                    </td>
                                    <?php if ($class_id_exists): ?>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-500">
                                            <?php echo $exam['class_id'] ? htmlspecialchars($exam['class_name'] ?? 'Unknown Class') : 'All Classes'; ?>
                                        </div>
                                    </td>
                                    <?php endif; ?>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-500">
                                            <?php echo date('M j, Y', strtotime($exam['start_date'])); ?> - 
                                            <?php echo date('M j, Y', strtotime($exam['end_date'])); ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                            <?php 
                                            switch($exam['status']) {
                                                case 'scheduled': echo 'bg-blue-100 text-blue-800'; break;
                                                case 'ongoing': echo 'bg-green-100 text-green-800'; break;
                                                case 'completed': echo 'bg-gray-100 text-gray-800'; break;
                                                case 'cancelled': echo 'bg-red-100 text-red-800'; break;
                                                default: echo 'bg-gray-100 text-gray-800';
                                            }
                                            ?>">
                                            <?php echo ucfirst($exam['status']); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                        <a href="?action=view&id=<?php echo $exam['id']; ?>" class="text-blue-600 hover:text-blue-900 mr-3">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="?action=edit&id=<?php echo $exam['id']; ?>" class="text-yellow-600 hover:text-yellow-900 mr-3">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="#" onclick="confirmDelete(<?php echo $exam['id']; ?>); return false;" class="text-red-600 hover:text-red-900">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                        <form id="delete-form-<?php echo $exam['id']; ?>" method="POST" style="display: none;">
                                            <input type="hidden" name="exam_id" value="<?php echo $exam['id']; ?>">
                                            <input type="hidden" name="delete_exam" value="1">
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<script>
function confirmDelete(examId) {
    if (confirm("Are you sure you want to delete this exam? This action cannot be undone.")) {
        document.getElementById('delete-form-' + examId).submit();
    }
}

function confirmDeleteSubject(subjectId) {
    if (confirm("Are you sure you want to remove this subject from the exam? This action cannot be undone.")) {
        document.getElementById('delete-subject-form-' + subjectId).submit();
    }
}
</script>

<?php require_once '../../components/footer.php'; ?>
<?php
// End output buffering and send all content to browser
ob_end_flush();
?> 