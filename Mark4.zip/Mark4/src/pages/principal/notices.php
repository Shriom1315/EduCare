<?php
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is principal
if ($_SESSION['role'] !== 'principal') {
    header('Location: /src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get school information
$query = "SELECT s.* FROM schools s WHERE s.principal_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$school = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$school) {
    header('Location: /src/pages/login.php');
    exit();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $title = $_POST['title'] ?? '';
                $content = $_POST['content'] ?? '';
                $target_audience = $_POST['target_audience'] ?? 'all';

                if (!empty($title) && !empty($content)) {
                    try {
                        $query = "INSERT INTO notices (title, content, school_id, created_by, target_audience) 
                                 VALUES (:title, :content, :school_id, :created_by, :target_audience)";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':title', $title);
                        $stmt->bindParam(':content', $content);
                        $stmt->bindParam(':school_id', $school['id']);
                        $stmt->bindParam(':created_by', $_SESSION['user_id']);
                        $stmt->bindParam(':target_audience', $target_audience);
                        $stmt->execute();
                        $success = "Notice posted successfully!";
                    } catch (Exception $e) {
                        $error = "Error posting notice: " . $e->getMessage();
                    }
                }
                break;

            case 'edit':
                $id = $_POST['id'] ?? '';
                $title = $_POST['title'] ?? '';
                $content = $_POST['content'] ?? '';
                $target_audience = $_POST['target_audience'] ?? 'all';

                if (!empty($id) && !empty($title) && !empty($content)) {
                    try {
                        $query = "UPDATE notices SET title = :title, content = :content, 
                                 target_audience = :target_audience, updated_at = NOW() 
                                 WHERE id = :id AND school_id = :school_id";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':id', $id);
                        $stmt->bindParam(':title', $title);
                        $stmt->bindParam(':content', $content);
                        $stmt->bindParam(':target_audience', $target_audience);
                        $stmt->bindParam(':school_id', $school['id']);
                        $stmt->execute();
                        $success = "Notice updated successfully!";
                    } catch (Exception $e) {
                        $error = "Error updating notice: " . $e->getMessage();
                    }
                }
                break;

            case 'delete':
                $id = $_POST['id'] ?? '';
                if (!empty($id)) {
                    try {
                        $query = "DELETE FROM notices WHERE id = :id AND school_id = :school_id";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':id', $id);
                        $stmt->bindParam(':school_id', $school['id']);
                        $stmt->execute();
                        $success = "Notice deleted successfully!";
                    } catch (Exception $e) {
                        $error = "Error deleting notice: " . $e->getMessage();
                    }
                }
                break;
        }
    }
}

// Check if we need to show a specific notice
$notice_id = $_GET['id'] ?? null;
$single_notice = null;

if ($notice_id) {
    $query = "SELECT n.*, u.username as created_by_name 
              FROM notices n 
              JOIN users u ON n.created_by = u.id 
              WHERE n.id = :id AND n.school_id = :school_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $notice_id);
    $stmt->bindParam(':school_id', $school['id']);
    $stmt->execute();
    $single_notice = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Fetch all notices for this school
$query = "SELECT n.*, u.username as created_by_name 
          FROM notices n 
          JOIN users u ON n.created_by = u.id 
          WHERE n.school_id = :school_id 
          ORDER BY n.created_at DESC";
$stmt = $db->prepare($query);
$stmt->bindParam(':school_id', $school['id']);
$stmt->execute();
$notices = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- Page Content -->
<div class="container mx-auto px-4">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Notices Management</h1>
        <button onclick="showAddModal()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200">
            <i class="fas fa-plus mr-2"></i>Post New Notice
        </button>
    </div>

    <?php if (isset($success)): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline"><?php echo $success; ?></span>
        </div>
    <?php endif; ?>

    <?php if (isset($error)): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline"><?php echo $error; ?></span>
        </div>
    <?php endif; ?>

    <?php if ($single_notice): ?>
        <!-- Single Notice View -->
        <div class="bg-white rounded-lg shadow-md mb-6">
            <div class="p-6">
                <div class="flex justify-between items-start">
                    <h2 class="text-xl font-bold text-gray-800 mb-2"><?php echo htmlspecialchars($single_notice['title']); ?></h2>
                    <div class="flex space-x-2">
                        <button onclick="showEditModal(<?php echo htmlspecialchars(json_encode($single_notice)); ?>)" 
                                class="text-blue-600 hover:text-blue-900">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button onclick="confirmDelete(<?php echo $single_notice['id']; ?>)" 
                                class="text-red-600 hover:text-red-900">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
                <div class="text-sm text-gray-600 mb-4">
                    <span>Posted by <?php echo htmlspecialchars($single_notice['created_by_name']); ?></span>
                    <span class="mx-2">•</span>
                    <span><?php echo date('M d, Y h:i A', strtotime($single_notice['created_at'])); ?></span>
                    <?php if ($single_notice['updated_at'] && $single_notice['updated_at'] != $single_notice['created_at']): ?>
                        <span class="mx-2">•</span>
                        <span>Updated: <?php echo date('M d, Y h:i A', strtotime($single_notice['updated_at'])); ?></span>
                    <?php endif; ?>
                    <span class="mx-2">•</span>
                    <span>For: <?php echo ucfirst(htmlspecialchars($single_notice['target_audience'])); ?></span>
                </div>
                <div class="prose max-w-none">
                    <?php echo nl2br(htmlspecialchars($single_notice['content'])); ?>
                </div>
            </div>
            <div class="bg-gray-50 px-6 py-3 flex justify-end">
                <a href="notices.php" class="text-gray-600 hover:text-gray-800">
                    <i class="fas fa-arrow-left mr-2"></i>Back to all notices
                </a>
            </div>
        </div>
    <?php else: ?>
        <!-- Notices List -->
        <div class="bg-white rounded-lg shadow-md">
            <?php if (empty($notices)): ?>
                <div class="p-6 text-center text-gray-500">
                    No notices have been posted yet. Create your first notice by clicking the "Post New Notice" button.
                </div>
            <?php else: ?>
                <div class="overflow-hidden">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Title</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Posted By</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">For</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($notices as $notice): ?>
                                <tr>
                                    <td class="px-6 py-4">
                                        <a href="notices.php?id=<?php echo $notice['id']; ?>" class="text-blue-600 hover:text-blue-900 font-medium">
                                            <?php echo htmlspecialchars($notice['title']); ?>
                                        </a>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo date('M d, Y', strtotime($notice['created_at'])); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo htmlspecialchars($notice['created_by_name']); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo ucfirst(htmlspecialchars($notice['target_audience'])); ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <a href="notices.php?id=<?php echo $notice['id']; ?>" class="text-indigo-600 hover:text-indigo-900 mr-3">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <button onclick="showEditModal(<?php echo htmlspecialchars(json_encode($notice)); ?>)" 
                                                class="text-blue-600 hover:text-blue-900 mr-3">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button onclick="confirmDelete(<?php echo $notice['id']; ?>)" 
                                                class="text-red-600 hover:text-red-900">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Add Notice Modal -->
<div id="addModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-3/4 max-w-2xl shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Post New Notice</h3>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="add">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700">Title</label>
                    <input type="text" name="title" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Target Audience</label>
                    <select name="target_audience" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="all">Everyone</option>
                        <option value="teachers">Teachers Only</option>
                        <option value="students">Students Only</option>
                        <option value="parents">Parents Only</option>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Content</label>
                    <textarea name="content" rows="10" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"></textarea>
                </div>

                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="hideAddModal()"
                        class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                        Cancel
                    </button>
                    <button type="submit"
                        class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">
                        Post Notice
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Notice Modal -->
<div id="editModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-3/4 max-w-2xl shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Edit Notice</h3>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="edit_id">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700">Title</label>
                    <input type="text" name="title" id="edit_title" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Target Audience</label>
                    <select name="target_audience" id="edit_target_audience" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="all">Everyone</option>
                        <option value="teachers">Teachers Only</option>
                        <option value="students">Students Only</option>
                        <option value="parents">Parents Only</option>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Content</label>
                    <textarea name="content" id="edit_content" rows="10" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"></textarea>
                </div>

                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="hideEditModal()"
                        class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                        Cancel
                    </button>
                    <button type="submit"
                        class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">
                        Update Notice
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div id="deleteModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Confirm Delete</h3>
            <p class="text-sm text-gray-500">Are you sure you want to delete this notice? This action cannot be undone.</p>
            
            <form method="POST" class="mt-4">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" id="delete_id">
                
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="hideDeleteModal()"
                        class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                        Cancel
                    </button>
                    <button type="submit"
                        class="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700">
                        Delete
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Modal functions
    function showAddModal() {
        document.getElementById('addModal').classList.remove('hidden');
    }

    function hideAddModal() {
        document.getElementById('addModal').classList.add('hidden');
    }

    function showEditModal(notice) {
        document.getElementById('edit_id').value = notice.id;
        document.getElementById('edit_title').value = notice.title;
        document.getElementById('edit_content').value = notice.content;
        document.getElementById('edit_target_audience').value = notice.target_audience;
        
        document.getElementById('editModal').classList.remove('hidden');
    }

    function hideEditModal() {
        document.getElementById('editModal').classList.add('hidden');
    }

    function confirmDelete(id) {
        document.getElementById('delete_id').value = id;
        document.getElementById('deleteModal').classList.remove('hidden');
    }

    function hideDeleteModal() {
        document.getElementById('deleteModal').classList.add('hidden');
    }

    // Close modals when clicking outside
    window.onclick = function(event) {
        if (event.target.classList.contains('fixed')) {
            event.target.classList.add('hidden');
        }
    }
</script>

<?php require_once '../../components/footer.php'; ?> 