<?php
ob_start();
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is principal
if ($_SESSION['role'] !== 'principal') {
    header('Location: /src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get school information
$query = "SELECT s.* FROM schools s WHERE s.principal_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$school = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$school) {
    header('Location: /src/pages/login.php');
    exit();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $name = $_POST['name'] ?? '';
                $code = $_POST['code'] ?? '';
                
                if (!empty($name) && !empty($code)) {
                    try {
                        $query = "INSERT INTO subjects (name, code, school_id) VALUES (:name, :code, :school_id)";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':name', $name);
                        $stmt->bindParam(':code', $code);
                        $stmt->bindParam(':school_id', $school['id']);
                        $stmt->execute();
                        
                        $_SESSION['success_message'] = "Subject added successfully!";
                    } catch (PDOException $e) {
                        $_SESSION['error_message'] = "Error adding subject: " . $e->getMessage();
                    }
                }
                break;
                
            case 'edit':
                $id = $_POST['id'] ?? '';
                $name = $_POST['name'] ?? '';
                $code = $_POST['code'] ?? '';
                
                if (!empty($id) && !empty($name) && !empty($code)) {
                    try {
                        // First verify that the subject belongs to this principal's school
                        $check_query = "SELECT id FROM subjects WHERE id = :id AND school_id = :school_id";
                        $check_stmt = $db->prepare($check_query);
                        $check_stmt->bindParam(':id', $id);
                        $check_stmt->bindParam(':school_id', $school['id']);
                        $check_stmt->execute();
                        
                        if ($check_stmt->fetch()) {
                            $query = "UPDATE subjects SET name = :name, code = :code WHERE id = :id AND school_id = :school_id";
                            $stmt = $db->prepare($query);
                            $stmt->bindParam(':id', $id);
                            $stmt->bindParam(':name', $name);
                            $stmt->bindParam(':code', $code);
                            $stmt->bindParam(':school_id', $school['id']);
                            $stmt->execute();
                            
                            $_SESSION['success_message'] = "Subject updated successfully!";
                        } else {
                            $_SESSION['error_message'] = "You do not have permission to edit this subject.";
                        }
                    } catch (PDOException $e) {
                        $_SESSION['error_message'] = "Error updating subject: " . $e->getMessage();
                    }
                }
                break;
                
            case 'delete':
                $id = $_POST['id'] ?? '';
                if (!empty($id)) {
                    try {
                        // First verify that the subject belongs to this principal's school
                        $check_query = "SELECT id FROM subjects WHERE id = :id AND school_id = :school_id";
                        $check_stmt = $db->prepare($check_query);
                        $check_stmt->bindParam(':id', $id);
                        $check_stmt->bindParam(':school_id', $school['id']);
                        $check_stmt->execute();
                        
                        if ($check_stmt->fetch()) {
                            // Check if subject is assigned to any class
                            $check_assign_query = "SELECT COUNT(*) as count FROM class_subjects WHERE subject_id = :id";
                            $check_assign_stmt = $db->prepare($check_assign_query);
                            $check_assign_stmt->bindParam(':id', $id);
                            $check_assign_stmt->execute();
                            $is_assigned = $check_assign_stmt->fetch(PDO::FETCH_ASSOC)['count'] > 0;
                            
                            if ($is_assigned) {
                                $_SESSION['error_message'] = "Cannot delete subject because it is assigned to one or more classes.";
                            } else {
                                $query = "DELETE FROM subjects WHERE id = :id AND school_id = :school_id";
                                $stmt = $db->prepare($query);
                                $stmt->bindParam(':id', $id);
                                $stmt->bindParam(':school_id', $school['id']);
                                $stmt->execute();
                                
                                $_SESSION['success_message'] = "Subject deleted successfully!";
                            }
                        } else {
                            $_SESSION['error_message'] = "You do not have permission to delete this subject.";
                        }
                    } catch (PDOException $e) {
                        $_SESSION['error_message'] = "Error deleting subject: " . $e->getMessage();
                    }
                }
                break;
        }
        
        header('Location: subjects.php');
        exit();
    }
}

// Fetch all subjects
try {
    $query = "SELECT * FROM subjects WHERE school_id = :school_id ORDER BY name";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':school_id', $school['id']);
    $stmt->execute();
    $subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $subjects = [];
    $_SESSION['error_message'] = "Error loading subjects: " . $e->getMessage();
}
?>

<!-- Page Content -->
<div class="container mx-auto px-4 py-6">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Manage Subjects</h1>
        <button onclick="showAddModal()" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors">
            <i class="fas fa-plus mr-1"></i> Add New Subject
        </button>
    </div>
    
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
            <p><?php echo $_SESSION['success_message']; ?></p>
        </div>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
            <p><?php echo $_SESSION['error_message']; ?></p>
        </div>
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>
    
    <!-- Subjects Table -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject Name</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject Code</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php foreach ($subjects as $subject): ?>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($subject['name']); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-500"><?php echo htmlspecialchars($subject['code']); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <button onclick="showEditModal(<?php echo htmlspecialchars(json_encode($subject)); ?>)" 
                                    class="text-blue-600 hover:text-blue-900 mr-3">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button onclick="confirmDelete(<?php echo $subject['id']; ?>)" 
                                    class="text-red-600 hover:text-red-900">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add Subject Modal -->
<div id="addModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Add New Subject</h3>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="add">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700">Subject Name</label>
                    <input type="text" name="name" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Subject Code</label>
                    <input type="text" name="code" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="hideAddModal()"
                        class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                        Cancel
                    </button>
                    <button type="submit"
                        class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">
                        Add Subject
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Subject Modal -->
<div id="editModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Edit Subject</h3>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="edit_id">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700">Subject Name</label>
                    <input type="text" name="name" id="edit_name" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Subject Code</label>
                    <input type="text" name="code" id="edit_code" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>

                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="hideEditModal()"
                        class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                        Cancel
                    </button>
                    <button type="submit"
                        class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700">
                        Update Subject
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div id="deleteModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Delete Subject</h3>
            <p class="text-sm text-gray-500">Are you sure you want to delete this subject? This action cannot be undone.</p>
            <form method="POST" class="mt-4">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" id="delete_id">
                
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="hideDeleteModal()"
                        class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                        Cancel
                    </button>
                    <button type="submit"
                        class="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700">
                        Delete
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function showAddModal() {
    document.getElementById('addModal').classList.remove('hidden');
}

function hideAddModal() {
    document.getElementById('addModal').classList.add('hidden');
}

function showEditModal(subject) {
    document.getElementById('edit_id').value = subject.id;
    document.getElementById('edit_name').value = subject.name;
    document.getElementById('edit_code').value = subject.code;
    document.getElementById('editModal').classList.remove('hidden');
}

function hideEditModal() {
    document.getElementById('editModal').classList.add('hidden');
}

function confirmDelete(id) {
    document.getElementById('delete_id').value = id;
    document.getElementById('deleteModal').classList.remove('hidden');
}

function hideDeleteModal() {
    document.getElementById('deleteModal').classList.add('hidden');
}
</script>

<?php require_once '../../components/footer.php'; ?>

<?php ob_end_flush(); ?> 