<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once '../../config/database.php';
require_once '../../models/User.php';
require_once '../../config/config.php';
require_once '../../utils/notification_utils.php';

// Debug Session Info
error_log("[Certificates] Session ID: " . session_id());
error_log("[Certificates] User ID: " . ($_SESSION['user_id'] ?? 'not set'));
error_log("[Certificates] Role: " . ($_SESSION['role'] ?? 'not set'));

// Check if user is logged in and is a principal
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'principal') {
    error_log("[Certificates] Authentication failed - redirecting to login");
    $_SESSION['error_message'] = "Unauthorized access. Please login as principal.";
    header('Location: ' . LOGIN_URL);
    exit();
}

// Initialize database connection
try {
    $db = new Database();
    $conn = $db->getConnection();
    error_log("[Certificates] Database connection established");
} catch (PDOException $e) {
    error_log("[Certificates] Primary database connection error: " . $e->getMessage());
    
    // Try backup connection if available
    try {
        if (file_exists('../../config/database_backup.php')) {
            require_once '../../config/database_backup.php';
            $db = new Database();
            $conn = $db->getConnection();
            error_log("[Certificates] Backup database connection established");
        } else {
            throw new PDOException("Backup database connection not available");
        }
    } catch (PDOException $e2) {
        error_log("[Certificates] Both database connections failed: " . $e2->getMessage());
        $_SESSION['error_message'] = "Database connection failed: " . $e->getMessage();
        header('Location: ' . getDashboardUrl('principal'));
        exit();
    }
}

$principal_id = $_SESSION['user_id'];
error_log("[Certificates] Principal ID: " . $principal_id);

// Get principal's school information directly (no teacher record required)
try {
    $school_query = "SELECT s.id as school_id, s.name as school_name 
                    FROM schools s 
                    WHERE s.principal_id = ?";
    error_log("[Certificates] Executing school query for principal_id: " . $principal_id);
    $stmt = $conn->prepare($school_query);
    $stmt->execute([$principal_id]);
    $school_info = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // If no direct school association, try via teachers table
    if (!$school_info) {
        error_log("[Certificates] No direct school association, checking teachers table");
        $teacher_school_query = "SELECT t.school_id, s.name as school_name 
                              FROM teachers t 
                              JOIN schools s ON t.school_id = s.id 
                              WHERE t.user_id = ?";
        $stmt = $conn->prepare($teacher_school_query);
        $stmt->execute([$principal_id]);
        $school_info = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Log the school ID for debugging
    if ($school_info) {
        error_log("[Certificates] Principal's school_id: " . $school_info['school_id'] . ", school_name: " . $school_info['school_name']);
    } else {
        error_log("[Certificates] Principal's school information not found");
        $_SESSION['error_message'] = "Principal's school information not found.";
        header('Location: ' . getDashboardUrl('principal'));
        exit();
    }
} catch (PDOException $e) {
    error_log("[Certificates] Error fetching school information: " . $e->getMessage());
    $_SESSION['error_message'] = "Error fetching school information: " . $e->getMessage();
    header('Location: ' . getDashboardUrl('principal'));
    exit();
}

// Check and fix table structure
try {
    // Check if remarks column exists in certificates table
    $check_remarks_query = "SHOW COLUMNS FROM certificates LIKE 'remarks'";
    $stmt = $conn->prepare($check_remarks_query);
    $stmt->execute();
    $remarks_exists = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$remarks_exists) {
        error_log("[Certificates] Remarks column does not exist, adding it");
        try {
            $add_remarks_query = "ALTER TABLE certificates ADD COLUMN remarks TEXT AFTER processed_by";
            $stmt = $conn->prepare($add_remarks_query);
            $stmt->execute();
            error_log("[Certificates] Added remarks column to certificates table");
        } catch (PDOException $e) {
            error_log("[Certificates] Error adding remarks column: " . $e->getMessage());
            // Continue anyway, we'll handle the missing column in the queries
        }
    }
    
    // Check if school_id column exists in certificates table
    $check_school_id_query = "SHOW COLUMNS FROM certificates LIKE 'school_id'";
    $stmt = $conn->prepare($check_school_id_query);
    $stmt->execute();
    $school_id_exists = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$school_id_exists) {
        error_log("[Certificates] School_id column does not exist in certificates table, adding it");
        try {
            $add_school_id_query = "ALTER TABLE certificates ADD COLUMN school_id INT AFTER student_id";
            $stmt = $conn->prepare($add_school_id_query);
            $stmt->execute();
            
            // Update existing certificates with proper school_id based on student's school
            $update_school_id_query = "UPDATE certificates c 
                                      JOIN students s ON c.student_id = s.id 
                                      SET c.school_id = s.school_id";
            $stmt = $conn->prepare($update_school_id_query);
            $stmt->execute();
            
            error_log("[Certificates] Added and populated school_id column in certificates table");
        } catch (PDOException $e) {
            error_log("[Certificates] Error adding/updating school_id column: " . $e->getMessage());
            // Continue anyway, we'll still join with students table
        }
    } else {
        // Force update existing certificates with proper school_id based on student's school
        // This ensures all certificates have the correct school_id even if they were created before
        try {
            $update_school_id_query = "UPDATE certificates c 
                                      JOIN students s ON c.student_id = s.id 
                                      SET c.school_id = s.school_id 
                                      WHERE c.school_id IS NULL OR c.school_id != s.school_id";
            $stmt = $conn->prepare($update_school_id_query);
            $stmt->execute();
            $updated = $stmt->rowCount();
            if ($updated > 0) {
                error_log("[Certificates] Updated school_id for $updated certificates");
            }
        } catch (PDOException $e) {
            error_log("[Certificates] Error updating school_id column: " . $e->getMessage());
        }
    }
} catch (PDOException $e) {
    error_log("[Certificates] Error checking table columns: " . $e->getMessage());
    // Continue anyway, we'll handle the missing columns in the queries
}

// Handle certificate approval/rejection
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['certificate_id'])) {
    try {
        $certificate_id = $_POST['certificate_id'];
        $action = $_POST['action'];
        $remarks = $_POST['remarks'] ?? '';
        
        error_log("[Certificates] Processing certificate ID: " . $certificate_id . " with action: " . $action);
        
        // Verify the certificate belongs to a student in principal's school
        $verify_query = "SELECT c.id 
                        FROM certificates c
                        JOIN students s ON c.student_id = s.id
                        WHERE c.id = ? AND c.school_id = ? AND s.school_id = ?";
        
        $stmt = $conn->prepare($verify_query);
        $stmt->execute([$certificate_id, $school_info['school_id'], $school_info['school_id']]);
        $certificate_found = $stmt->fetch();
        
        if ($certificate_found) {
            error_log("[Certificates] Certificate verified as belonging to this school");
            
            // Build the update query based on whether remarks column exists
            if ($remarks_exists) {
                $update_query = "UPDATE certificates 
                               SET status = ?, 
                                   processed_by = ?, 
                                   processed_at = NOW(),
                                   remarks = ? 
                               WHERE id = ?";
                $update_params = [$action, $principal_id, $remarks, $certificate_id];
            } else {
                $update_query = "UPDATE certificates 
                               SET status = ?, 
                                   processed_by = ?, 
                                   processed_at = NOW()
                               WHERE id = ?";
                $update_params = [$action, $principal_id, $certificate_id];
            }
            
            $stmt = $conn->prepare($update_query);
            $stmt->execute($update_params);
            
            // Send notification to student
            $notification_sent = notifyCertificateStatusUpdate(
                $certificate_id,
                $action,
                $remarks,
                $conn
            );
            
            if ($notification_sent) {
                error_log("[Certificates] Certificate status notification sent to student");
            } else {
                error_log("[Certificates] Failed to send certificate status notification");
            }
            
            error_log("[Certificates] Certificate successfully updated");
            $_SESSION['success_message'] = "Certificate request has been " . $action;
        } else {
            error_log("[Certificates] Invalid certificate request - not found or not belonging to this school");
            $_SESSION['error_message'] = "Invalid certificate request.";
        }
        
        // Redirect to prevent form resubmission
        header('Location: ' . getPageUrl('principal', 'certificates'));
        exit();
    } catch (PDOException $e) {
        error_log("[Certificates] Error processing certificate: " . $e->getMessage());
        $_SESSION['error_message'] = "Error processing certificate: " . $e->getMessage();
    }
}

// Get all certificate requests for the principal's school
try {
    error_log("[Certificates] Getting certificates for school_id: " . $school_info['school_id']);
    
    // Add a debug query to check certificates in the database
    $debug_query = "SELECT COUNT(*) as total FROM certificates";
    $stmt = $conn->prepare($debug_query);
    $stmt->execute();
    $total_certs = $stmt->fetch(PDO::FETCH_ASSOC);
    error_log("[Certificates] Total certificates in database: " . $total_certs['total']);
    
    // Check if there are certificates with matching school_id
    $check_query = "SELECT COUNT(*) as matching FROM certificates WHERE school_id = ?";
    $stmt = $conn->prepare($check_query);
    $stmt->execute([$school_info['school_id']]);
    $matching_certs = $stmt->fetch(PDO::FETCH_ASSOC);
    error_log("[Certificates] Certificates matching school_id " . $school_info['school_id'] . ": " . $matching_certs['matching']);
    
    // Check if 'remarks' column exists
    $certificates_query = "SELECT 
        c.id,
        c.type,
        c.status,
        c.requested_at,
        c.processed_at,
        c.school_id,
        " . ($remarks_exists ? "c.remarks," : "'' as remarks,") . "
        s.roll_number,
        u.username as student_name,
        cl.class_name,
        COALESCE(
            (SELECT COUNT(*) FROM attendance a 
             WHERE a.student_id = s.id 
             AND a.status = 'present') * 100.0 / 
            NULLIF((SELECT COUNT(*) FROM attendance a 
                   WHERE a.student_id = s.id), 0),
            0
        ) as attendance_percentage,
        pu.username as processed_by_name
    FROM certificates c
    JOIN students s ON c.student_id = s.id
    JOIN users u ON s.user_id = u.id
    JOIN classes cl ON s.class_id = cl.id
    LEFT JOIN users pu ON c.processed_by = pu.id
    WHERE c.school_id = ? AND s.school_id = ?
    ORDER BY 
        CASE 
            WHEN c.status = 'pending' THEN 1
            ELSE 2
        END,
        c.requested_at DESC";
    
    $stmt = $conn->prepare($certificates_query);
    $stmt->execute([$school_info['school_id'], $school_info['school_id']]);
    $certificates = $stmt->fetchAll(PDO::FETCH_ASSOC);
    error_log("[Certificates] Found " . count($certificates) . " certificate(s) after filtering");
    
    // Debug loop through certificates
    foreach ($certificates as $cert) {
        error_log("[Certificates] Certificate ID: " . $cert['id'] . ", School ID: " . $cert['school_id'] . ", Student: " . $cert['student_name']);
    }
} catch (PDOException $e) {
    error_log("[Certificates] Error fetching certificates: " . $e->getMessage());
    $_SESSION['error_message'] = "Error fetching certificates: " . $e->getMessage();
    $certificates = [];
}

// Include header
require_once '../../components/header.php';
?>

<div class="container mx-auto px-4 py-6">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-3xl font-bold text-gray-900">Certificate Requests</h1>
        <div class="text-sm text-gray-600">
            School: <?php echo htmlspecialchars($school_info['school_name']); ?>
        </div>
    </div>

    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4">
            <?php 
            echo htmlspecialchars($_SESSION['success_message']);
            unset($_SESSION['success_message']);
            ?>
        </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4">
            <?php 
            echo htmlspecialchars($_SESSION['error_message']);
            unset($_SESSION['error_message']);
            ?>
        </div>
    <?php endif; ?>

    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
        <?php if (!empty($certificates)): ?>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Student</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Class</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Attendance</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Requested</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($certificates as $cert): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm font-medium text-gray-900">
                                        <?php echo htmlspecialchars($cert['student_name']); ?>
                                    </div>
                                    <div class="text-sm text-gray-500">
                                        Roll #: <?php echo htmlspecialchars($cert['roll_number']); ?>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    <?php echo htmlspecialchars($cert['class_name']); ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    <?php echo ucfirst(htmlspecialchars($cert['type'])); ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full 
                                        <?php 
                                        switch($cert['status']) {
                                            case 'approved':
                                                echo 'bg-green-100 text-green-800';
                                                break;
                                            case 'rejected':
                                                echo 'bg-red-100 text-red-800';
                                                break;
                                            default:
                                                echo 'bg-yellow-100 text-yellow-800';
                                        }
                                        ?>">
                                        <?php echo ucfirst(htmlspecialchars($cert['status'])); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900">
                                        <?php echo number_format($cert['attendance_percentage'], 1); ?>%
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    <?php echo date('M d, Y', strtotime($cert['requested_at'])); ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                    <?php if ($cert['status'] === 'pending'): ?>
                                        <button onclick="showActionModal(<?php echo $cert['id']; ?>)"
                                                class="text-blue-600 hover:text-blue-900">
                                            Process Request
                                        </button>
                                    <?php else: ?>
                                        <div class="flex space-x-3">
                                            <button onclick="showDetailsModal(
                                                <?php echo $cert['id']; ?>, 
                                                '<?php echo addslashes($cert['processed_by_name'] ?? ''); ?>', 
                                                '<?php echo addslashes($cert['remarks'] ?? ''); ?>', 
                                                '<?php echo !empty($cert['processed_at']) ? date('M d, Y', strtotime($cert['processed_at'])) : ''; ?>'
                                            )"
                                                    class="text-gray-600 hover:text-gray-900">
                                                <i class="fas fa-info-circle mr-1"></i> View Details
                                            </button>
                                            <?php if ($cert['status'] === 'approved'): ?>
                                                <a href="<?php echo getPageUrl('principal', 'print_certificate') . '?id=' . $cert['id']; ?>" 
                                                   target="_blank"
                                                   class="text-green-600 hover:text-green-900">
                                                    <i class="fas fa-print mr-1"></i> Print
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="text-center py-8">
                <div class="mb-4">
                    <i class="fas fa-certificate text-gray-400 text-5xl"></i>
                </div>
                <h3 class="text-lg font-medium text-gray-900 mb-2">No Certificate Requests</h3>
                <p class="text-gray-500">There are no certificate requests at this time.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Action Modal -->
<div id="actionModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-medium">Process Certificate Request</h3>
            <button onclick="closeActionModal()" class="text-gray-400 hover:text-gray-500">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <form method="POST" action="<?php echo getPageUrl('principal', 'certificates'); ?>" id="certificateForm">
            <input type="hidden" name="certificate_id" id="certificate_id">
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="action">
                    Action
                </label>
                <select name="action" id="action" required
                        class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    <option value="approved">Approve</option>
                    <option value="rejected">Reject</option>
                </select>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2" for="remarks">
                    Remarks
                </label>
                <textarea name="remarks" id="remarks"
                          class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                          rows="3"></textarea>
            </div>
            <div class="flex justify-end">
                <button type="button" onclick="closeActionModal()"
                        class="mr-2 px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-300 rounded-md hover:bg-gray-200">
                    Cancel
                </button>
                <button type="submit"
                        class="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700">
                    Submit
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Details Modal -->
<div id="detailsModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-medium">Certificate Details</h3>
            <button onclick="closeDetailsModal()" class="text-gray-400 hover:text-gray-500">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="space-y-4">
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-1">Processed By</label>
                <p id="processedBy" class="text-gray-600 border p-2 rounded bg-gray-50"></p>
            </div>
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-1">Processed Date</label>
                <p id="processedDate" class="text-gray-600 border p-2 rounded bg-gray-50"></p>
            </div>
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-1">Remarks</label>
                <p id="viewRemarks" class="text-gray-600 border p-2 rounded bg-gray-50 min-h-[60px]"></p>
            </div>
            <div class="flex justify-end mt-4">
                <button onclick="closeDetailsModal()"
                        class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-300 rounded-md hover:bg-gray-200">
                    Close
                </button>
            </div>
        </div>
    </div>
</div>

<script>
function showActionModal(certificateId) {
    document.getElementById('certificate_id').value = certificateId;
    document.getElementById('actionModal').classList.remove('hidden');
}

function closeActionModal() {
    document.getElementById('certificateForm').reset();
    document.getElementById('actionModal').classList.add('hidden');
}

function showDetailsModal(certificateId, processedBy, remarks, processedDate) {
    // Debug information
    console.log("Opening details modal with:", { certificateId, processedBy, remarks, processedDate });
    
    document.getElementById('processedBy').textContent = processedBy || 'Not available';
    document.getElementById('processedDate').textContent = processedDate || 'Not available';
    document.getElementById('viewRemarks').textContent = remarks || 'No remarks provided';
    document.getElementById('detailsModal').classList.remove('hidden');
}

function closeDetailsModal() {
    document.getElementById('detailsModal').classList.add('hidden');
}

// Close modals when clicking outside
window.onclick = function(event) {
    let actionModal = document.getElementById('actionModal');
    let detailsModal = document.getElementById('detailsModal');
    if (event.target === actionModal) {
        closeActionModal();
    }
    if (event.target === detailsModal) {
        closeDetailsModal();
    }
}
</script>

<?php require_once '../../components/footer.php'; ?> 