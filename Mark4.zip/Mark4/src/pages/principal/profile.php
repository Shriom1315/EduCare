<?php
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is principal
if ($_SESSION['role'] !== 'principal') {
    header('Location: /Mark4/src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get principal information
$query = "SELECT p.*, u.username, u.email, s.name as school_name, s.address as school_address 
          FROM users u 
          JOIN schools s ON s.principal_id = u.id 
          LEFT JOIN principals p ON p.user_id = u.id 
          WHERE u.id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$principal = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$principal) {
    header('Location: /Mark4/src/pages/login.php');
    exit();
}

// Get school statistics
$stats = [];

// Get total number of teachers
$query = "SELECT COUNT(*) as count FROM teachers WHERE school_id = (SELECT id FROM schools WHERE principal_id = :principal_id)";
$stmt = $db->prepare($query);
$stmt->bindParam(':principal_id', $_SESSION['user_id']);
$stmt->execute();
$stats['teachers'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

// Get total number of students
$query = "SELECT COUNT(*) as count FROM students WHERE school_id = (SELECT id FROM schools WHERE principal_id = :principal_id)";
$stmt = $db->prepare($query);
$stmt->bindParam(':principal_id', $_SESSION['user_id']);
$stmt->execute();
$stats['students'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

// Get total number of classes
$query = "SELECT COUNT(*) as count FROM classes WHERE school_id = (SELECT id FROM schools WHERE principal_id = :principal_id)";
$stmt = $db->prepare($query);
$stmt->bindParam(':principal_id', $_SESSION['user_id']);
$stmt->execute();
$stats['classes'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $qualification = $_POST['qualification'] ?? '';
    $experience = $_POST['experience'] ?? '';

    $errors = [];

    // Validate email
    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }

    // Handle password change
    if (!empty($current_password)) {
        // Verify current password
        $query = "SELECT password FROM users WHERE id = :user_id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':user_id', $_SESSION['user_id']);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!password_verify($current_password, $user['password'])) {
            $errors[] = "Current password is incorrect";
        } elseif (empty($new_password) || empty($confirm_password)) {
            $errors[] = "New password and confirmation are required";
        } elseif ($new_password !== $confirm_password) {
            $errors[] = "New passwords do not match";
        } elseif (strlen($new_password) < 8) {
            $errors[] = "New password must be at least 8 characters long";
        }
    }

    if (empty($errors)) {
        try {
            $db->beginTransaction();

            // Update user email if changed
            if (!empty($email) && $email !== $principal['email']) {
                $query = "UPDATE users SET email = :email WHERE id = :user_id";
                $stmt = $db->prepare($query);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':user_id', $_SESSION['user_id']);
                $stmt->execute();
            }

            // Update password if requested
            if (!empty($new_password)) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $query = "UPDATE users SET password = :password WHERE id = :user_id";
                $stmt = $db->prepare($query);
                $stmt->bindParam(':password', $hashed_password);
                $stmt->bindParam(':user_id', $_SESSION['user_id']);
                $stmt->execute();
            }

            // Update or insert principal details
            if ($principal['user_id']) {
                $query = "UPDATE principals SET 
                         phone = :phone,
                         qualification = :qualification,
                         experience = :experience
                         WHERE user_id = :user_id";
            } else {
                $query = "INSERT INTO principals (user_id, phone, qualification, experience) 
                         VALUES (:user_id, :phone, :qualification, :experience)";
            }
            
            $stmt = $db->prepare($query);
            $stmt->bindParam(':user_id', $_SESSION['user_id']);
            $stmt->bindParam(':phone', $phone);
            $stmt->bindParam(':qualification', $qualification);
            $stmt->bindParam(':experience', $experience);
            $stmt->execute();

            $db->commit();
            $success_message = "Profile updated successfully!";
            
            // Refresh principal data
            $stmt = $db->prepare($query);
            $stmt->bindParam(':user_id', $_SESSION['user_id']);
            $stmt->execute();
            $principal = $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            $db->rollBack();
            $error_message = "Error updating profile: " . $e->getMessage();
        }
    } else {
        $error_message = implode("<br>", $errors);
    }
}
?>

<!-- Page Content -->
<div class="container mx-auto px-4 py-6">
    <div class="max-w-4xl mx-auto">
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div class="p-6">
                <h2 class="text-2xl font-bold text-gray-900 mb-6">My Profile</h2>

                <?php if (isset($success_message)): ?>
                    <div class="bg-green-50 border-l-4 border-green-500 p-4 mb-6">
                        <div class="flex">
                            <div class="flex-shrink-0">
                                <i class="fas fa-check-circle text-green-500"></i>
                            </div>
                            <div class="ml-3">
                                <p class="text-sm text-green-700"><?php echo $success_message; ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (isset($error_message)): ?>
                    <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
                        <div class="flex">
                            <div class="flex-shrink-0">
                                <i class="fas fa-exclamation-circle text-red-500"></i>
                            </div>
                            <div class="ml-3">
                                <p class="text-sm text-red-700"><?php echo $error_message; ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- School Information -->
                <div class="bg-gray-50 rounded-lg p-6 mb-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">School Information</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <p class="text-sm font-medium text-gray-500">School Name</p>
                            <p class="mt-1 text-sm text-gray-900"><?php echo htmlspecialchars($principal['school_name']); ?></p>
                        </div>
                        <div>
                            <p class="text-sm font-medium text-gray-500">School Address</p>
                            <p class="mt-1 text-sm text-gray-900"><?php echo htmlspecialchars($principal['school_address']); ?></p>
                        </div>
                    </div>
                </div>

                <!-- School Statistics -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                    <div class="bg-blue-50 rounded-lg p-6">
                        <div class="text-blue-900">
                            <p class="text-sm font-medium">Total Teachers</p>
                            <p class="text-3xl font-bold"><?php echo $stats['teachers']; ?></p>
                        </div>
                    </div>
                    <div class="bg-green-50 rounded-lg p-6">
                        <div class="text-green-900">
                            <p class="text-sm font-medium">Total Students</p>
                            <p class="text-3xl font-bold"><?php echo $stats['students']; ?></p>
                        </div>
                    </div>
                    <div class="bg-purple-50 rounded-lg p-6">
                        <div class="text-purple-900">
                            <p class="text-sm font-medium">Total Classes</p>
                            <p class="text-3xl font-bold"><?php echo $stats['classes']; ?></p>
                        </div>
                    </div>
                </div>

                <!-- Profile Update Form -->
                <form method="POST" class="space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="email" class="block text-sm font-medium text-gray-700">Email</label>
                            <input type="email" name="email" id="email" 
                                value="<?php echo htmlspecialchars($principal['email']); ?>"
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                        </div>
                        <div>
                            <label for="phone" class="block text-sm font-medium text-gray-700">Phone Number</label>
                            <input type="tel" name="phone" id="phone" 
                                value="<?php echo htmlspecialchars($principal['phone'] ?? ''); ?>"
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                        </div>
                        <div>
                            <label for="qualification" class="block text-sm font-medium text-gray-700">Qualification</label>
                            <input type="text" name="qualification" id="qualification" 
                                value="<?php echo htmlspecialchars($principal['qualification'] ?? ''); ?>"
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                        </div>
                        <div>
                            <label for="experience" class="block text-sm font-medium text-gray-700">Years of Experience</label>
                            <input type="number" name="experience" id="experience" 
                                value="<?php echo htmlspecialchars($principal['experience'] ?? ''); ?>"
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                        </div>
                    </div>

                    <!-- Password Change Section -->
                    <div class="border-t border-gray-200 pt-6">
                        <h3 class="text-lg font-medium text-gray-900 mb-4">Change Password</h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label for="current_password" class="block text-sm font-medium text-gray-700">Current Password</label>
                                <input type="password" name="current_password" id="current_password" 
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            </div>
                            <div>
                                <label for="new_password" class="block text-sm font-medium text-gray-700">New Password</label>
                                <input type="password" name="new_password" id="new_password" 
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            </div>
                            <div>
                                <label for="confirm_password" class="block text-sm font-medium text-gray-700">Confirm New Password</label>
                                <input type="password" name="confirm_password" id="confirm_password" 
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            </div>
                        </div>
                    </div>

                    <div class="flex justify-end">
                        <button type="submit" 
                            class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                            <i class="fas fa-save mr-2"></i>
                            Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../components/footer.php'; ?> 