<?php
ob_start();
require_once '../../config/database.php';
require_once '../../components/header.php';

// Check if user is principal
if ($_SESSION['role'] !== 'principal') {
    header('Location: /src/pages/login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Get school information
$query = "SELECT s.* FROM schools s WHERE s.principal_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->execute();
$school = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$school) {
    header('Location: /src/pages/login.php');
    exit();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $class_id = $_POST['class_id'] ?? '';
                $subject_id = $_POST['subject_id'] ?? '';
                $teacher_id = $_POST['teacher_id'] ?? '';
                $day_of_week = $_POST['day_of_week'] ?? '';
                $start_time = $_POST['start_time'] ?? '';
                $end_time = $_POST['end_time'] ?? '';
                
                if (!empty($class_id) && !empty($subject_id) && !empty($teacher_id) && 
                    !empty($day_of_week) && !empty($start_time) && !empty($end_time)) {
                    try {
                        // Check for time slot conflicts
                        $check_query = "SELECT COUNT(*) as count FROM timetables 
                                      WHERE class_id = :class_id 
                                      AND day_of_week = :day_of_week 
                                      AND ((start_time <= :end_time AND end_time >= :start_time))";
                        $check_stmt = $db->prepare($check_query);
                        $check_stmt->bindParam(':class_id', $class_id);
                        $check_stmt->bindParam(':day_of_week', $day_of_week);
                        $check_stmt->bindParam(':start_time', $start_time);
                        $check_stmt->bindParam(':end_time', $end_time);
                        $check_stmt->execute();
                        $has_conflict = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'] > 0;
                        
                        if ($has_conflict) {
                            $_SESSION['error_message'] = "Time slot conflicts with existing schedule.";
                        } else {
                            $query = "INSERT INTO timetables (class_id, subject_id, teacher_id, day_of_week, start_time, end_time, school_id) 
                                     VALUES (:class_id, :subject_id, :teacher_id, :day_of_week, :start_time, :end_time, :school_id)";
                            $stmt = $db->prepare($query);
                            $stmt->bindParam(':class_id', $class_id);
                            $stmt->bindParam(':subject_id', $subject_id);
                            $stmt->bindParam(':teacher_id', $teacher_id);
                            $stmt->bindParam(':day_of_week', $day_of_week);
                            $stmt->bindParam(':start_time', $start_time);
                            $stmt->bindParam(':end_time', $end_time);
                            $stmt->bindParam(':school_id', $school['id']);
                            $stmt->execute();
                            
                            $_SESSION['success_message'] = "Timetable entry added successfully!";
                        }
                    } catch (PDOException $e) {
                        $_SESSION['error_message'] = "Error adding timetable entry: " . $e->getMessage();
                    }
                }
                break;
                
            case 'delete':
                $id = $_POST['id'] ?? '';
                if (!empty($id)) {
                    try {
                        $query = "DELETE FROM timetables WHERE id = :id";
                        $stmt = $db->prepare($query);
                        $stmt->bindParam(':id', $id);
                        $stmt->execute();
                        
                        $_SESSION['success_message'] = "Timetable entry deleted successfully!";
                    } catch (PDOException $e) {
                        $_SESSION['error_message'] = "Error deleting timetable entry: " . $e->getMessage();
                    }
                }
                break;
        }
        
        header('Location: timetable.php');
        exit();
    }
}

// Fetch all classes for the school
try {
    $query = "SELECT * FROM classes WHERE school_id = :school_id ORDER BY class_name";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':school_id', $school['id']);
    $stmt->execute();
    $classes = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $classes = [];
    $_SESSION['error_message'] = "Error loading classes: " . $e->getMessage();
}

// Fetch all subjects
try {
    $query = "SELECT * FROM subjects WHERE school_id = :school_id ORDER BY name";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':school_id', $school['id']);
    $stmt->execute();
    $subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $subjects = [];
    $_SESSION['error_message'] = "Error loading subjects: " . $e->getMessage();
}

// Fetch all teachers for the school
try {
    $query = "SELECT t.*, u.username FROM teachers t 
              JOIN users u ON t.user_id = u.id 
              WHERE t.school_id = :school_id 
              ORDER BY u.username";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':school_id', $school['id']);
    $stmt->execute();
    $teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $teachers = [];
    $_SESSION['error_message'] = "Error loading teachers: " . $e->getMessage();
}

// Fetch timetable entries
try {
    $query = "SELECT t.*, c.class_name, s.name as subject_name, u.username as teacher_name 
              FROM timetables t 
              JOIN classes c ON t.class_id = c.id 
              JOIN subjects s ON t.subject_id = s.id 
              JOIN users u ON t.teacher_id = u.id 
              WHERE c.school_id = :school_id 
              ORDER BY t.day_of_week, t.start_time";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':school_id', $school['id']);
    $stmt->execute();
    $timetable_entries = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $timetable_entries = [];
    $_SESSION['error_message'] = "Error loading timetable entries: " . $e->getMessage();
}

// Group timetable entries by class and day
$timetable_by_class = [];
foreach ($timetable_entries as $entry) {
    if (!isset($timetable_by_class[$entry['class_id']])) {
        $timetable_by_class[$entry['class_id']] = [];
    }
    if (!isset($timetable_by_class[$entry['class_id']][$entry['day_of_week']])) {
        $timetable_by_class[$entry['class_id']][$entry['day_of_week']] = [];
    }
    $timetable_by_class[$entry['class_id']][$entry['day_of_week']][] = $entry;
}
?>

<!-- Page Content -->
<div class="container mx-auto px-4 py-6">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold text-gray-800">Manage Timetable</h1>
    </div>
    
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
            <p><?php echo $_SESSION['success_message']; ?></p>
        </div>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4" role="alert">
            <p><?php echo $_SESSION['error_message']; ?></p>
        </div>
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>
    
    <!-- Add Timetable Entry Form -->
    <div class="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 class="text-xl font-semibold mb-4">Add Timetable Entry</h2>
        <form method="POST" class="space-y-4">
            <input type="hidden" name="action" value="add">
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                    <label for="class_id" class="block text-sm font-medium text-gray-700">Class</label>
                    <select id="class_id" name="class_id" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Select a class</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['id']; ?>">
                                <?php echo htmlspecialchars($class['class_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label for="subject_id" class="block text-sm font-medium text-gray-700">Subject</label>
                    <select id="subject_id" name="subject_id" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Select a subject</option>
                        <?php foreach ($subjects as $subject): ?>
                            <option value="<?php echo $subject['id']; ?>">
                                <?php echo htmlspecialchars($subject['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label for="teacher_id" class="block text-sm font-medium text-gray-700">Teacher</label>
                    <select id="teacher_id" name="teacher_id" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Select a teacher</option>
                        <?php foreach ($teachers as $teacher): ?>
                            <option value="<?php echo $teacher['user_id']; ?>">
                                <?php echo htmlspecialchars($teacher['username']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label for="day_of_week" class="block text-sm font-medium text-gray-700">Day of Week</label>
                    <select id="day_of_week" name="day_of_week" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                        <option value="">Select a day</option>
                        <?php
                        $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                        foreach ($days as $day):
                        ?>
                            <option value="<?php echo $day; ?>"><?php echo $day; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label for="start_time" class="block text-sm font-medium text-gray-700">Start Time</label>
                    <input type="time" id="start_time" name="start_time" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>
                
                <div>
                    <label for="end_time" class="block text-sm font-medium text-gray-700">End Time</label>
                    <input type="time" id="end_time" name="end_time" required
                        class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                </div>
            </div>
            
            <div class="flex justify-end">
                <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors">
                    Add Entry
                </button>
            </div>
        </form>
    </div>
    
    <!-- Timetable Display -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <h2 class="text-xl font-semibold mb-4">Current Timetable</h2>
        
        <?php foreach ($classes as $class): ?>
            <div class="mb-8">
                <h3 class="text-lg font-semibold mb-4"><?php echo htmlspecialchars($class['class_name']); ?></h3>
                
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Time</th>
                                <?php
                                $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                                foreach ($days as $day):
                                ?>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"><?php echo $day; ?></th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php
                            $time_slots = [];
                            foreach ($timetable_entries as $entry) {
                                if ($entry['class_id'] == $class['id']) {
                                    $time_slots[$entry['start_time']] = true;
                                }
                            }
                            ksort($time_slots);
                            
                            foreach ($time_slots as $time => $dummy):
                                $start_time = date('h:i A', strtotime($time));
                                $end_time = date('h:i A', strtotime($time) + 3600); // Assuming 1-hour slots
                            ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo $start_time . ' - ' . $end_time; ?>
                                    </td>
                                    <?php foreach ($days as $day): ?>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <?php
                                            if (isset($timetable_by_class[$class['id']][$day])) {
                                                foreach ($timetable_by_class[$class['id']][$day] as $entry) {
                                                    if ($entry['start_time'] === $time) {
                                                        echo '<div class="text-sm">';
                                                        echo '<div class="font-medium text-gray-900">' . htmlspecialchars($entry['subject_name']) . '</div>';
                                                        echo '<div class="text-gray-500">' . htmlspecialchars($entry['teacher_name']) . '</div>';
                                                        echo '</div>';
                                                        echo '<form method="POST" class="mt-2">';
                                                        echo '<input type="hidden" name="action" value="delete">';
                                                        echo '<input type="hidden" name="id" value="' . $entry['id'] . '">';
                                                        echo '<button type="submit" class="text-red-600 hover:text-red-900 text-sm">Delete</button>';
                                                        echo '</form>';
                                                    }
                                                }
                                            }
                                            ?>
                                        </td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php require_once '../../components/footer.php'; ?>

<?php ob_end_flush(); ?> 