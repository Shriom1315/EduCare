<?php
class Notification {
    private $conn;
    private $table = 'notifications';

    public function __construct($db) {
        $this->conn = $db;
    }

    // Get notifications for a specific user
    public function getNotifications($user_id, $limit = 50) {
        $query = "SELECT * FROM {$this->table} 
                 WHERE user_id = :user_id 
                 ORDER BY created_at DESC 
                 LIMIT :limit";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get count of unread notifications
    public function getUnreadCount($user_id) {
        $query = "SELECT COUNT(*) as count 
                 FROM {$this->table} 
                 WHERE user_id = :user_id AND is_read = 0";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    }

    // Mark a notification as read
    public function markAsRead($notification_id, $user_id) {
        $query = "UPDATE {$this->table} 
                 SET is_read = 1 
                 WHERE id = :notification_id AND user_id = :user_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':notification_id', $notification_id);
        $stmt->bindParam(':user_id', $user_id);

        return $stmt->execute();
    }

    // Mark all notifications as read for a user
    public function markAllAsRead($user_id) {
        $query = "UPDATE {$this->table} 
                 SET is_read = 1 
                 WHERE user_id = :user_id AND is_read = 0";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);

        return $stmt->execute();
    }

    // Create a new notification
    public function create($user_id, $title, $message) {
        $query = "INSERT INTO {$this->table} 
                 (user_id, title, message) 
                 VALUES (:user_id, :title, :message)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':message', $message);

        return $stmt->execute();
    }

    // Create notifications for multiple users
    public function createMultiple($user_ids, $title, $message) {
        $success = true;
        $this->conn->beginTransaction();

        try {
            foreach ($user_ids as $user_id) {
                $query = "INSERT INTO {$this->table} 
                         (user_id, title, message) 
                         VALUES (:user_id, :title, :message)";
                
                $stmt = $this->conn->prepare($query);
                $stmt->bindParam(':user_id', $user_id);
                $stmt->bindParam(':title', $title);
                $stmt->bindParam(':message', $message);
                $stmt->execute();
            }

            $this->conn->commit();
        } catch (Exception $e) {
            $this->conn->rollBack();
            $success = false;
        }

        return $success;
    }

    // Delete a notification
    public function delete($notification_id, $user_id) {
        $query = "DELETE FROM {$this->table} 
                 WHERE id = :notification_id AND user_id = :user_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':notification_id', $notification_id);
        $stmt->bindParam(':user_id', $user_id);

        return $stmt->execute();
    }

    // Delete all read notifications for a user
    public function deleteAllRead($user_id) {
        $query = "DELETE FROM {$this->table} 
                 WHERE user_id = :user_id AND is_read = 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);

        return $stmt->execute();
    }

    // Get notifications by type (if you want to add notification types later)
    public function getNotificationsByType($user_id, $type, $limit = 50) {
        $query = "SELECT * FROM {$this->table} 
                 WHERE user_id = :user_id AND type = :type 
                 ORDER BY created_at DESC 
                 LIMIT :limit";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':type', $type);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?> 