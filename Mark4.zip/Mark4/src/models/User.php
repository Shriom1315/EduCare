<?php
/**
 * User Model Class
 * Handles user-related operations like authentication, profile management
 */
class User {
    private $conn;
    private $table = 'users';
    
    // User properties
    public $id;
    public $username;
    public $email;
    public $password;
    public $role;
    public $created_at;
    public $updated_at;
    
    /**
     * Constructor with DB connection
     * 
     * @param PDO $db Database connection
     */
    public function __construct($db) {
        $this->conn = $db;
    }
    
    /**
     * Get user by ID
     * 
     * @param int $user_id User ID
     * @return bool Success or failure
     */
    public function getById($user_id) {
        $query = "SELECT * FROM {$this->table} WHERE id = ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $user_id);
        $stmt->execute();
        
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($row) {
            $this->id = $row['id'];
            $this->username = $row['username'];
            $this->email = $row['email'];
            $this->password = $row['password'];
            $this->role = $row['role'];
            $this->created_at = $row['created_at'];
            $this->updated_at = $row['updated_at'];
            return true;
        }
        
        return false;
    }
    
    /**
     * Get user by username
     * 
     * @param string $username Username
     * @return bool Success or failure
     */
    public function getByUsername($username) {
        $query = "SELECT * FROM {$this->table} WHERE username = ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $username);
        $stmt->execute();
        
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($row) {
            $this->id = $row['id'];
            $this->username = $row['username'];
            $this->email = $row['email'];
            $this->password = $row['password'];
            $this->role = $row['role'];
            $this->created_at = $row['created_at'];
            $this->updated_at = $row['updated_at'];
            return true;
        }
        
        return false;
    }
    
    /**
     * Authenticate user
     * 
     * @param string $username Username
     * @param string $password Plain text password
     * @return bool True if authenticated, false otherwise
     */
    public function authenticate($username, $password) {
        if ($this->getByUsername($username)) {
            return password_verify($password, $this->password);
        }
        
        return false;
    }
    
    /**
     * Update user profile
     * 
     * @param array $data User data to update
     * @return bool Success or failure
     */
    public function update($data) {
        // Build update query based on provided fields
        $fields = [];
        $values = [];
        
        foreach ($data as $key => $value) {
            if (property_exists($this, $key) && $key !== 'id') {
                $fields[] = "$key = ?";
                $values[] = $value;
            }
        }
        
        if (empty($fields)) {
            return false;
        }
        
        $values[] = $this->id; // Add ID for the WHERE clause
        
        $query = "UPDATE {$this->table} 
                 SET " . implode(', ', $fields) . ", 
                     updated_at = NOW() 
                 WHERE id = ?";
        
        $stmt = $this->conn->prepare($query);
        
        return $stmt->execute($values);
    }
    
    /**
     * Change user password
     * 
     * @param string $current_password Current password
     * @param string $new_password New password
     * @return bool Success or failure
     */
    public function changePassword($current_password, $new_password) {
        if (password_verify($current_password, $this->password)) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            
            $query = "UPDATE {$this->table} 
                     SET password = ?, updated_at = NOW() 
                     WHERE id = ?";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $hashed_password);
            $stmt->bindParam(2, $this->id);
            
            return $stmt->execute();
        }
        
        return false;
    }
    
    /**
     * Create a new user
     * 
     * @param array $data User data
     * @return int|bool New user ID or false on failure
     */
    public function create($data) {
        $username = $data['username'] ?? '';
        $email = $data['email'] ?? '';
        $password = $data['password'] ?? '';
        $role = $data['role'] ?? 'student';
        
        // Validate data
        if (empty($username) || empty($password)) {
            return false;
        }
        
        // Hash password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        $query = "INSERT INTO {$this->table} 
                 (username, email, password, role) 
                 VALUES (?, ?, ?, ?)";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $username);
        $stmt->bindParam(2, $email);
        $stmt->bindParam(3, $hashed_password);
        $stmt->bindParam(4, $role);
        
        if ($stmt->execute()) {
            return $this->conn->lastInsertId();
        }
        
        return false;
    }
}
?> 