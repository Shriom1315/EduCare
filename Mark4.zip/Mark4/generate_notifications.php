<?php
// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "Please login first!";
    exit;
}

// Include database connection
require_once __DIR__ . '/src/config/database.php';

// Create database connection
$database = new Database();
$db = $database->getConnection();

try {
    // Check if notifications table exists, if not create it
    $stmt = $db->prepare("SHOW TABLES LIKE 'notifications'");
    $stmt->execute();
    $tableExists = $stmt->rowCount() > 0;
    
    if (!$tableExists) {
        // Create the notifications table
        $sql = "CREATE TABLE notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            title VARCHAR(255) NOT NULL,
            message TEXT NOT NULL,
            is_read TINYINT(1) NOT NULL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX (user_id)
        )";
        
        $db->exec($sql);
        echo "Notifications table created successfully!<br>";
    } else {
        echo "Notifications table already exists!<br>";
    }
    
    // Get current user ID
    $user_id = $_SESSION['user_id'];
    
    // Clear existing notifications for this user
    $stmt = $db->prepare("DELETE FROM notifications WHERE user_id = :user_id");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->execute();
    
    // Insert sample notifications
    $notifications = [
        [
            'title' => 'Welcome to the System',
            'message' => 'Thank you for using our school management system!'
        ],
        [
            'title' => 'New Feature Available',
            'message' => 'Check out the new notification system in the header.'
        ],
        [
            'title' => 'Profile Update Reminder',
            'message' => 'Please remember to update your profile information.'
        ],
        [
            'title' => 'System Maintenance',
            'message' => 'The system will be down for maintenance this weekend.'
        ],
        [
            'title' => 'Important Notice',
            'message' => 'Please check the notices section for important updates.'
        ]
    ];
    
    // Insert notifications
    $stmt = $db->prepare("INSERT INTO notifications (user_id, title, message) VALUES (:user_id, :title, :message)");
    
    foreach ($notifications as $notification) {
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':title', $notification['title']);
        $stmt->bindParam(':message', $notification['message']);
        $stmt->execute();
    }
    
    echo "Added " . count($notifications) . " test notifications for user ID: " . $user_id . "<br>";
    echo "Current user: " . $_SESSION['username'] . " (" . $_SESSION['role'] . ")<br>";
    echo "<p>Go back to <a href='/Mark4/src/pages/{$_SESSION['role']}/dashboard.php'>dashboard</a> to see your notifications.</p>";
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?> 