# School Management System (SMS)

A modern and interactive school management system with role-based access control for Super Admin, Principal, Teachers, and Students.

## Features

- Role-based access control (Super Admin, Principal, Teachers, Students)
- Interactive dashboards with real-time data visualization
- Attendance tracking and management
- Exam and results management
- Notice board system
- Certificate management
- Dark/Light mode support
- Real-time notifications
- Modern UI with animations

## Tech Stack

- Frontend:
  - HTML5, CSS3, JavaScript
  - React.js
  - TailwindCSS
  - GSAP for animations
  - Chart.js for data visualization

- Backend:
  - PHP
  - MySQL
  - RESTful APIs

## Setup Instructions

1. Clone the repository
2. Set up your local development environment (XAMPP/WAMP)
3. Import the database schema from `database/schema.sql`
4. Configure database connection in `config/database.php`
5. Install dependencies:
   ```bash
   npm install
   ```
6. Start the development server:
   ```bash
   npm run dev
   ```

## Project Structure

```
├── assets/
│   ├── css/
│   ├── js/
│   └── images/
├── config/
├── database/
├── includes/
├── src/
│   ├── components/
│   ├── pages/
│   └── utils/
└── vendor/
```

## Security

- Password encryption using bcrypt
- SQL injection prevention
- XSS protection
- CSRF protection
- Secure session management

## License

MIT License 