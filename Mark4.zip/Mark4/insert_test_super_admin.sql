-- Insert a test record for the super admin user
-- Replace 1 with the actual user ID of the super admin if needed
INSERT INTO super_admins (user_id, phone, last_login) 
VALUES (1, '+1-555-123-4567', NOW())
ON DUPLICATE KEY UPDATE phone = VALUES(phone), last_login = VALUES(last_login); 