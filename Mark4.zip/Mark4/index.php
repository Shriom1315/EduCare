<?php
session_start();
require_once 'config/database.php';

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    // Redirect based on user role
    switch ($_SESSION['role']) {
        case 'super_admin':
            header('Location: src/pages/super_admin/dashboard.php');
            break;
        case 'principal':
            header('Location: src/pages/principal/dashboard.php');
            break;
        case 'teacher':
            header('Location: src/pages/teacher/dashboard.php');
            break;
        case 'student':
            header('Location: src/pages/student/dashboard.php');
            break;
        default:
            header('Location: src/pages/login.php');
    }
    exit();
} else {
    // Redirect to login page if not logged in
    header('Location: src/pages/login.php');
    exit();
}
?> 