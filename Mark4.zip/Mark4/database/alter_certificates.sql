-- Add reason column to certificates table
ALTER TABLE certificates
ADD COLUMN reason TEXT AFTER type; 