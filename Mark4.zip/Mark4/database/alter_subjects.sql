-- Add school_id column to subjects table to associate subjects with schools
ALTER TABLE subjects ADD COLUMN school_id INT;

-- Add foreign key constraint
ALTER TABLE subjects ADD CONSTRAINT fk_subjects_school FOREIGN KEY (school_id) REFERENCES schools(id);

-- Update existing subjects to associate with a default school (use school ID 1 as default)
UPDATE subjects SET school_id = 1 WHERE school_id IS NULL;

-- Drop the existing unique constraint on code
ALTER TABLE subjects DROP INDEX code;

-- Add a new composite unique constraint on code + school_id
ALTER TABLE subjects ADD CONSTRAINT unique_code_per_school UNIQUE(code, school_id);

-- In the future, make school_id NOT NULL
-- After all data is properly migrated, you can run:
-- ALTER TABLE subjects MODIFY COLUMN school_id INT NOT NULL; 